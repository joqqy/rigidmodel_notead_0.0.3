namespace half { void dummy() {} }
