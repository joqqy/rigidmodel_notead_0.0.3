//#include "pch.h"
#include "rmv2_def.h"



/*
texture_type::operator uint32_t()
{
	return m_uiValue;
}

texture_type::operator string()
{
	return getString(m_value);

}
 
texture_type::operator const char*()
{
	
	return getString(m_value);


}
int32_t texture_type::operator=(uint32_t value)
{
	
	m_uiValue = value;

	return value;

}

*/
	//const char * texture_type::getString(uint32_t uiValue)
	//{
	//	switch (uiValue)
	//	{
	//	case values::uiDiffuse:
	//		return "Diffuse";

	//	case values::uiSpecular:
	//		return "Specular";

	//	case values::uiNormal:
	//		return "Normal Map";

	//	case values::uiGlossMap:
	//		return "Gloss Map";

	//	case values::uiAmbientOcclusion:
	//		return "Ambient Acclusion";

	//	case values::uiDecalDirtmap:
	//		return "Decal Dirt Map";

	//	case values::uiDecalDirtmask:
	//		return "Decal Dirt Mask";

	//	case values::uiDecalMask:
	//		return "Decal Mask";

	//	case values::uiDiffuseDamage:
	//		return "Diffuse Damage";

	//	case values::uiDirtAlphaMask:
	//		return "Dirt Alpha Mask";

	//	case values::uiMask:
	//		return "Mask";

	//	case values::uiSkinMask:
	//		return "Skin Mask";

	//	case values::uiTilingDirtUV2:
	//		return "Tilinig Dirt UV2";
	//	
	//	default:
	//		return "***unknown***";
	//	}

	//};


