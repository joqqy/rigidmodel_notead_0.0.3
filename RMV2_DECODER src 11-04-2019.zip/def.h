#pragma once
#include <string>
#include <cstdint>
#include <iostream>
#include <Definitions.h>

//using namespace std;

//#include "pch.h"

//
//Sign bit : 1 bit
//Exponent width : 5 bits
//Significand precision : 11 bits(10 explicitly stored)

//using half_float::half;

//typedef char*			sz;
//typedef const char*		csz;
//
//
//
//typedef std::uint8_t	u8;
//typedef std::uint8_t	ui8;
//typedef std::uint8_t	byte;
//typedef std::uint8_t	uint8;
//	dword;
//typedef std::uint16_t	u16;
//typedef std::uint16_t	ui16;
//typedef std::uint16_t	word;
//typedef std::uint16_t	uint16;
//
//typedef std::uint32_t	u32;
//
//typedef std::uint32_t	dword;
//typedef std::uint32_t	uint32;
//typedef std::uint32_t	uint;
//
//typedef std::uint64_t	u64;
//typedef std::uint64_t	qword;
//typedef std::uint64_t	ddword;
//
//typedef std::int8_t		signed_byte;
//
//typedef uint16_t		half;

//typedef std::uint16_t	i16;
//typedef std::uint16_t	int16;

//typedef std::uint32_t	i32;
//typedef std::uint32_t	int32;
//typedef std::uint64_t	i64;
//typedef std::uint64_t	int64;





#define ENDL "\r\n"

#define OR ||
#define AND &&

#define or |
#define or_assign |= 

#define and &
#define and_assign |& 



#define SPACE " "
#define DEBUG int SPACE ##__FILE__ ##__LINE__  = __COUNTER__;


//
//Sign bit : 1 bit
//Exponent width : 5 bits
//Significand precision : 11 bits(10 explicitly stored)



template <class T>
T bits2(const char* pchBits) {

	size_t bit_length = sizeof(T) * 8;
	size_t length_of_string = strlen(pchBits);
	unsigned long bit_index = 0;


	unsigned long temp = 0;

	size_t char_index = length_of_string + 1;


	if (bit_length < length_of_string)
		char_index = bit_length + 1;
	else
		char_index = length_of_string - 1;


	      
	for (int i = 0; i < length_of_string; i++)
	{
		if (pchBits[length_of_string-1-i] == '1')
		{
			long t = (1 << bit_index);
			temp += t;
			bit_index++;
		}
		else
		if (pchBits[length_of_string-1 - i] == '0')
		{
			bit_index++;
		}
}
			



	//int count = 0;

	//while (char_index > 0)
	//{
	//	count++;
	//	if (pchBits[char_index] == '1')
	//	{
	//		long t = (1 << bit_index);
	//		temp += t;
	//		bit_index++;
	//	}
	//	else
	//	if (pchBits[char_index] == '0')
	//	{
	//			bit_index++;
	//	}
	//	
	//	char_index--;
	//	
	//}
	return (T) temp;
};


extern int exitProgam(std::string message, int exit_code);
extern int writeDebugMessage(std::string message);

extern dword fastcpy(void * dest, const void* src, dword count);

extern float convert16BitFloatTo32Bits(word wInput);
extern float HalfToSingle(word wInput);


/*

	half t_pos;
	byte t_norm;
	XMFLOAT3 piv;
	XMStoreFloat3(&piv, pivot);
file.read(reinterpret_cast<char *>(&t_pos), sizeof(t_pos));
vertex->position.x = t_pos + piv.x;
file.read(reinterpret_cast<char *>(&t_pos), sizeof(t_pos));
vertex->position.y = t_pos + piv.y;
file.read(reinterpret_cast<char *>(&t_pos), sizeof(t_pos));
vertex->position.z = -t_pos + piv.z;
file.seekg(2, ios_base::cur);

file.read(reinterpret_cast<char *>(&t_pos), sizeof(t_pos));
vertex->texCoord.x = t_pos;
file.read(reinterpret_cast<char *>(&t_pos), sizeof(t_pos));
vertex->texCoord.y = 1.0f - t_pos;
file.read(reinterpret_cast<char *>(&t_pos), sizeof(t_pos));
vertex->texCoord2.x = t_pos;
file.read(reinterpret_cast<char *>(&t_pos), sizeof(t_pos));
vertex->texCoord2.y = 1.0f - t_pos;

file.read(reinterpret_cast<char *>(&t_norm), sizeof(t_norm));
vertex->normal.z = -(t_norm / 127.0f - 1.0f);
file.read(reinterpret_cast<char *>(&t_norm), sizeof(t_norm));
vertex->normal.y = t_norm / 127.0f - 1.0f;
file.read(reinterpret_cast<char *>(&t_norm), sizeof(t_norm));
vertex->normal.x = t_norm / 127.0f - 1.0f;
XMStoreFloat3(&vertex->normal, XMVector3Normalize(XMLoadFloat3(&vertex->normal)));
file.seekg(1, ios_base::cur);

file.read(reinterpret_cast<char *>(&t_norm), sizeof(t_norm));
vertex->bitangent.z = -(t_norm / 127.0f - 1.0f);
file.read(reinterpret_cast<char *>(&t_norm), sizeof(t_norm));
vertex->bitangent.y = t_norm / 127.0f - 1.0f;
file.read(reinterpret_cast<char *>(&t_norm), sizeof(t_norm));
vertex->bitangent.x = t_norm / 127.0f - 1.0f;
XMStoreFloat3(&vertex->bitangent, XMVector3Normalize(XMLoadFloat3(&vertex->bitangent)));
file.seekg(1, ios_base::cur);

file.read(reinterpret_cast<char *>(&t_norm), sizeof(t_norm));
vertex->tangent.z = -(t_norm / 127.0f - 1.0f);
file.read(reinterpret_cast<char *>(&t_norm), sizeof(t_norm));
vertex->tangent.y = t_norm / 127.0f - 1.0f;
file.read(reinterpret_cast<char *>(&t_norm), sizeof(t_norm));
vertex->tangent.x = t_norm / 127.0f - 1.0f;
XMStoreFloat3(&vertex->tangent, XMVector3Normalize(XMLoadFloat3(&vertex->tangent)));
file.seekg(5, ios_base::cur);
}*/