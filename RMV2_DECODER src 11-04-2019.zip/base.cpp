
#include "pch.h"
#include "base.h"
//#include "half.h"

//using half_float::half;
//base::base()
//{
//}
//
//
//base::~base()
//{
//}
