#pragma once
#include "def.h"
#include "def.h"

using namespace std;

class str_info
{
private:
	str_info();
public:
	
	str_info(sz pszOriginal, dword dwMaxLen, bool bZeroPadding);
	


	dword	getLength()			const;
	dword   getOffset()			const;
	sz		getStrContent()		const;
			
	operator dword();

	// return the offset
	operator int();


	static string & pathToCString(const string);
	static string & getFileFromString(const string);
	static string & getDirFromString(const string);

	static string & getPathFromDirAndFile(const string strDir, const string strFile);


	// return the string
	operator csz();
	
	 //sets the offset
	dword& operator=(dword index); 

	// sets the text
	const string & operator=(const string & sz);

	void fillZeros();


	static constexpr dword zero_padding = true;
	static constexpr dword no_zero_padding = false;


public:
	// Set the string to be copy to file
	void setString(csz szConent, bool bZeroPadding = true);


	// Set the string to be copy to file
	void setString(string);

	// Sets the offset in the file where the string is supposed to go
	void setOffset(dword dwOffset);		
	
	// Set the maximum length of the string, so that is will fit into the file
	void setMaxLength(dword dwLength);

	// Determines wether the string will have zero padding
	void setZeroPadding(bool bZeroPadding);
	
	// copy the string to the specificied bugger assumed to be file buffer
	


public:
	static string sm_strTemp;
	dword	m_dwOffsset = 0;
	dword	m_dwMaxLength = 0;
	sz		m_szContent = NULL;
	sz		m_szOriginal;

	bool	m_bZeroPadding = true;
	//char*	sm_szEmpty;

	static constexpr char sm_szEmpty[] = "Empty!";

};
/*

template <class T>
class value_info
{
	// TODO: Finish this onee

public:
	// default constructor
	valu_info();

	valu_info();

	// default constructor

	//str_info(csz cszConent);

	// Initialized max length
	str_info(dword ddwaxLen);
	
	dword	getLength()			const;
	dword   getOffset()			const;
	T*		getStrContent()		const;
	
	// return the offset
	operator T();

	// return the string
	operator csz();
	
public:
	// Set the string to be copy to file
	void setValue(T value, u32 number = 1);
	   	
	// Sets the offset in the file where the string is supposed to go
	void setOffset(dword dwOffset);

	// Set the maximum length of the string, so that is will fit into the file
	void setength(dword dwLength);
	
public:
	dword	m_dwOffsset;
	dword	m_dwLength = 0;
	T*		m_pValue = new T[1];
	T*		m_PoriginalValue;
};


*/