#pragma once		


#include "def.h"
#include "str_info.h"
#include "half.h"


//#include <DirectXMath.h>


//using namespace DirectX;
using half_float::half;




	
//lf a;

//int f1()
//{
//	half a;
//
//	dword d = 10;
//
//	memcpy(&a, &d, 2);
//
//	float f = a;
//	return 1;
//}




///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	File header
//	Contains info on the RMV2 file, fx the signature of the file type
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
struct _RMV2_File_Header
{
	union _Signature {
		char szSignature[4];
		uint32_t dwSignature;	// Should always be "RMV2"

	} Signature;
	uint32_t		ModelVersion;	// 6 for Rome2/Atilla/Thrones, 7 for WH2
	uint32_t		LodsCount;		// always 4
	char		Skeleton[128];
};


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	LOD header
// The header data for all the LODs, can be read as one struct/chunk, the number of which is determined by the previous "LodsCount"
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
struct _RMV2_Lod_Header {
	uint32	GroupsCount;
	uint32	VerticesDataLength;
	uint32	IndicesDataLength;
	uint32	Start_offset;
	float	LODZoomFactor; // For 4 LoDs this is normally 100.0, 200.0, 400.0, 500.0.	
};


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	LOD Data header
// The header of the LOD group data (the only part of an Lod group that (osteensibly) is of contant size)
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


struct _RMV2_Lod_Data_Header
{	//0
	uint32 uiMaterialId;		// 4 Bytes[UInt32] - ? // Looks like and ID or a flag, it's always 65 for the moment.
		
	uint32 uiUnkown;			// No idea. It's a very big number normally.
	uint32 uiUnkown1_1;			// No idea. It's a very big number normally.
	uint32 uiVerticesCount;		// 4 Bytes[UInt32] - VerticesCount
	uint32 uiUnkown2_1;			// No idea. It's a very big number normally.
	uint32 uiIndicesCount;		// 	4 Bytes[UInt32] - IndicesCount

	// offset 24

	float GroupMinimumX;
	float fGroupMinimumY;
	float fGroupMinimumZ;
	float fGroupMaximumX;
	float fGroupMaximumY;
	float fGroupMaximumZ;

	// offset 48	

	char  pchShaderName[12];
	str_info ShaderName = str_info(pchShaderName, 12, str_info::no_zero_padding);

	//offset 60

	// unknows 20 long
	char pBlocknown4_20[20];  //offset of the item MAY be determined of the length of the previous string
	 
	//offset 80
	// HERE
	word wVertexFormat;


	char pchGroupName[32];		// 32 Bytes [0-Padded String] - GroupName
	str_info GroupName = str_info(pchGroupName, 32, str_info::no_zero_padding);
	//112
	//file.seekg(514, ios_base::cur);

	
	char pchTextureDirectory[256];		// 256 Bytes[0 - Padded String] - TexturesDirectory
	str_info TextureDirectory = str_info(pchTextureDirectory, 256, str_info::zero_padding);
	
	char Unknown3_422[422];
	//268
	// jump 56 and read this and then jump back                                                                                                                                                                                                                                               
	
	 
	


	//I scale the whole model so it's probably not a single block!
	uint32 uiSupplementarBonesCount; //4 Bytes[UInt32] - SupplementarBonesCount

	uint32 uiTextureCount; //4 Bytes[UInt32] - TexturesCount
	char Unknown140[140];	//140 Bytes - ? // No idea.
	//uint32_t uiUnknow_1_1;
}; 


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	Bone/attachement data
//	The supplmentary data one bones in the each LOD group
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
struct _RMV2_SupplementaryBone_Data
{

	//32 Bytes[0 - Padded String] - SupplementarBoneName
	char pchSupplementaryBoneName[32];

	// 48 Bytes - ? // Probably position, rotation and other things.
	char unkown[48];

	// 4 Bytes[UInt32] - SupplementarBoneID
	uint32 uiSupplementaryID;// 4 Bytes[UInt32] - SupplementarBoneID

}; // END: suppl bone/attachment


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	Bone/attachement data
//	The supplmentary data one bones in the each LOD group
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
struct _RMV2_Texture_Data
{
	//*4 Bytes[UInt32] - TextureType // 0 Diffuse, 1 Normal, 11 Specular, 12 Gloss, Mask 3 or 10
	uint32 uiTextureType;

	//256 Bytes[0 - Padded String] - TexturePath(TexturesDirectory + FileName)
	char pchTextureDirAndFileNam[256];

	str_info TextureDirAndFileName = str_info(pchTextureDirAndFileNam, 256, str_info::zero_padding);
	

}; // END: texture data


// the signature in the beginning of a RMV2 file, the a byte chars spell out "RMV2"
#define SIGNATURE 0x32564D52
#define SIGNATURE_DEC 844516690;


struct string_offse_and_lenghth
{
	dword	dwFileOffset;
	string	strContent;
	dword	dwMaxLength;
};

class RigidMaterial
{
public:
	static constexpr uint32_t bow_wave = 22;
	static constexpr uint32_t non_renderable = 26;
	static constexpr uint32_t texture_combo_vertex_wind = 29;
	static constexpr uint32_t texture_combo = 30;
	static constexpr uint32_t decal_waterfall = 31;
	static constexpr uint32_t standard_simple = 32;
	static constexpr uint32_t campaign_trees = 34;
	static constexpr uint32_t point_light = 38;
	static constexpr uint32_t static_point_light = 45;
	static constexpr uint32_t debug_geometry = 46;
	static constexpr uint32_t custom_terrain = 49;
	static constexpr uint32_t weighted_cloth = 58;
	static constexpr uint32_t cloth = 60;
	static constexpr uint32_t collision = 61;
	static constexpr uint32_t collision_shape = 62;
	static constexpr uint32_t tiled_dirtmap = 63;
	static constexpr uint32_t ship_ambientmap = 64;
	static constexpr uint32_t weighted = 65;
	static constexpr uint32_t projected_decal = 67;
	static constexpr uint32_t default_value = 68;
	static constexpr uint32_t grass = 69;
	static constexpr uint32_t weighted_skin = 70;
	static constexpr uint32_t decal = 71;
	static constexpr uint32_t decal_dirtmap = 72;
	static constexpr uint32_t dirtmap = 73;
	static constexpr uint32_t tree = 74;
	static constexpr uint32_t tree_leaf = 75;
	static constexpr uint32_t weighted_decal = 77;
	static constexpr uint32_t weighted_decal_dirtmap = 78;
	static constexpr uint32_t weighted_dirtmap = 79;
	static constexpr uint32_t weighted_skin_decal = 80;
	static constexpr uint32_t weighted_skin_decal_dirtmap = 81;
	static constexpr uint32_t weighted_skin_dirtmap = 82;
	static constexpr uint32_t water = 83;
	static constexpr uint32_t unlit = 84;
	static constexpr uint32_t weighted_unlit = 85;
	static constexpr uint32_t terrain_blend = 86;
	static constexpr uint32_t projected_decal_v2 = 87;
	static constexpr uint32_t ignore = 88;
	static constexpr uint32_t tree_billboard_material = 89;
	static constexpr uint32_t water_displace_volume = 91;
	static constexpr uint32_t rope = 93;
	static constexpr uint32_t campaign_vegetation = 94;
	static constexpr uint32_t projected_decal_v3 = 95;
	static constexpr uint32_t weighted_texture_blend = 96;
	static constexpr uint32_t projected_decal_v4 = 97;
	static constexpr uint32_t global_terrain = 98;
	static constexpr uint32_t decal_overlay = 99;
	static constexpr uint32_t alpha_blend = 100;
};


// The very file chuck of any RMV2 file, can't be read in one struct/chunk
//
//
//// data of indices, for now, just now the size and position of it and the file and jump over it
//struct _RMV2_Indice_Data
//{
//	//	2 Bytes[UInt16] - Index1
//	char uiIndex1[2];
//
//	// 2 Bytes[UInt16] - Index2 // CA loves to invert indices 2 and 3... this could be the case!
//	char uiIndex2[2];
//
//
//	// 2 Bytes[UInt16] - Index3 // CA loves to invert indices 2 and 3... this could be the case!
//	char uiIndex3[2];
//
//};
//
//// data of indices, for now, just now the size of it (which requires some code to find out) and position of it and the file and jump over it
//struct _RMV2_Vertex_Data_Default
//{
//	//half half;
//	//byte t_norm;
//	//XMFLOAT3 piv;
//	//XMStoreFloat3(&piv, pivot);
//	//file.read(reinterpret_cast<char *>(&t_pos), sizeof(half));
//	//vertex->position.x = t_pos + piv.x;
//	//file.read(reinterpret_cast<char *>(&t_pos), sizeof(half));
//	//vertex->position.y = t_pos + piv.y;
//	//file.read(reinterpret_cast<char *>(&t_pos), sizeof(half));
//	//vertex->position.z = -t_pos + piv.z;
//	//file.seekg(2, ios_base::cur);
//	//// 8
//
//	//file.read(reinterpret_cast<char *>(&t_pos), sizeof(half));
//	//vertex->texCoord.x = t_pos;
//	//file.read(reinterpret_cast<char *>(&t_pos), sizeof(half));
//	//vertex->texCoord.y = 1.0f - t_pos;
//	//file.read(reinterpret_cast<char *>(&t_pos), sizeof(half));
//	//vertex->texCoord2.x = t_pos;
//	//file.read(reinterpret_cast<char *>(&t_pos), sizeof(half));
//	//vertex->texCoord2.y = 1.0f - t_pos;
//	//// 16
//	//
//	//
//	//file.read(reinterpret_cast<char *>(&t_norm), sizeof(byte));
//	//vertex->normal.z = -(t_norm / 127.0f - 1.0f);
//	//file.read(reinterpret_cast<char *>(&t_norm), sizeof(byte));
//	//vertex->normal.y = t_norm / 127.0f - 1.0f;
//	//file.read(reinterpret_cast<char *>(&t_norm), sizeof(byte));
//	//vertex->normal.x = t_norm / 127.0f - 1.0f;
//	//XMStoreFloat3(&vertex->normal, XMVector3Normalize(XMLoadFloat3(&vertex->normal)));
//	//file.seekg(1, ios_base::cur);
//
//	////20
//	//file.read(reinterpret_cast<char *>(&t_norm), sizeof(byte));
//	//vertex->bitangent.z = -(t_norm / 127.0f - 1.0f);
//	//file.read(reinterpret_cast<char *>(&t_norm), sizeof(byte));
//	//vertex->bitangent.y = t_norm / 127.0f - 1.0f;
//	//file.read(reinterpret_cast<char *>(&t_norm), sizeof(byte));
//	//vertex->bitangent.x = t_norm / 127.0f - 1.0f;
//	//XMStoreFloat3(&vertex->bitangent, XMVector3Normalize(XMLoadFloat3(&vertex->bitangent)));
//	//file.seekg(1, ios_base::cur);
//
//	//// 24
//	//file.read(reinterpret_cast<char *>(&t_norm), sizeof(byte));
//	//vertex->tangent.z = -(t_norm / 127.0f - 1.0f);
//	//file.read(reinterpret_cast<char *>(&t_norm), sizeof(byte));
//	//vertex->tangent.y = t_norm / 127.0f - 1.0f;
//	//file.read(reinterpret_cast<char *>(&t_norm), sizeof(byte));
//	//vertex->tangent.x = t_norm / 127.0f - 1.0f;
//	//XMStoreFloat3(&vertex->tangent, XMVector3Normalize(XMLoadFloat3(&vertex->tangent)));
//	//file.seekg(5, ios_base::cur);
//	//// size 32 
//	////size 35
//
//
//};
//
//
//struct _RMV2_Binary_Vertex_Data_Default
//{
//	//half half_floatingpoint;
//	//byte t_norm;
//	//XMFLOAT3 piv;
//	//XMStoreFloat3(&piv, pivot);
//
//	//file.read(reinterpret_cast<char *>(&t_pos), sizeof(half));
//	//vertex->position.x = t_pos + piv.x;
//
//	half position_x;
//
//
//	//file.read(reinterpret_cast<char *>(&t_pos), sizeof(half));
//	//vertex->position.y = t_pos + piv.y;
//
//	word position_y;
//
//	//file.read(reinterpret_cast<char *>(&t_pos), sizeof(half));
//	//vertex->position.z = -t_pos + piv.z;
//
//	half position_Z;
//
//	//file.seekg(2, ios_base::cur);
//	word Uknown1_2;
//
//	//// offset 8
//
//	//file.read(reinterpret_cast<char *>(&t_pos), sizeof(half));
//	//vertex->texCoord.x = t_pos;
//	half texture_u1;
//
//	//file.read(reinterpret_cast<char *>(&t_pos), sizeof(half));
//	//vertex->texCoord.y = 1.0f - t_pos;
//	half texture_v1;
//
//	//file.read(reinterpret_cast<char *>(&t_pos), sizeof(half));
//	//vertex->texCoord2.x = t_pos;
//	half texture_u2;
//
//	//file.read(reinterpret_cast<char *>(&t_pos), sizeof(half));
//	//vertex->texCoord2.y = 1.0f - t_pos;
//	half texture_v2;
//
//	//// offset 16
//	//
//	//
//	//file.read(reinterpret_cast<char *>(&t_norm), sizeof(byte));
//	//vertex->normal.z = -(t_norm / 127.0f - 1.0f);
//	//file.read(reinterpret_cast<char *>(&t_norm), sizeof(byte));
//	//vertex->normal.y = t_norm / 127.0f - 1.0f;
//	//file.read(reinterpret_cast<char *>(&t_norm), sizeof(byte));
//	//vertex->normal.x = t_norm / 127.0f - 1.0f;
//	//XMStoreFloat3(&vertex->normal, XMVector3Normalize(XMLoadFloat3(&vertex->normal)));
//	//file.seekg(1, ios_base::cur);
//
//	////20
//	//file.read(reinterpret_cast<char *>(&t_norm), sizeof(byte));
//	//vertex->bitangent.z = -(t_norm / 127.0f - 1.0f);
//	//file.read(reinterpret_cast<char *>(&t_norm), sizeof(byte));
//	//vertex->bitangent.y = t_norm / 127.0f - 1.0f;
//	//file.read(reinterpret_cast<char *>(&t_norm), sizeof(byte));
//	//vertex->bitangent.x = t_norm / 127.0f - 1.0f;
//	//XMStoreFloat3(&vertex->bitangent, XMVector3Normalize(XMLoadFloat3(&vertex->bitangent)));
//	//file.seekg(1, ios_base::cur);
//
//	//// 24
//	//file.read(reinterpret_cast<char *>(&t_norm), sizeof(byte));
//	//vertex->tangent.z = -(t_norm / 127.0f - 1.0f);
//	//file.read(reinterpret_cast<char *>(&t_norm), sizeof(byte));
//	//vertex->tangent.y = t_norm / 127.0f - 1.0f;
//	//file.read(reinterpret_cast<char *>(&t_norm), sizeof(byte));
//	//vertex->tangent.x = t_norm / 127.0f - 1.0f;
//	//XMStoreFloat3(&vertex->tangent, XMVector3Normalize(XMLoadFloat3(&vertex->tangent)));
//	//file.seekg(5, ios_base::cur);
//	//// size 32 
//	////size 35
//
//
//};
//
//
//struct _RMV2_Vertex_Default_Data
//{
//
//
//
//
//
//
//
//	half pos_x;
//	half pos_z;
//	half pos_y;
//
//	char unknown1_2[2];
//
//	half textcord_u;
//	half textcord_v;
//	half textcord_u2;
//	half textcord_v2;
//
//
//
//	byte normal_x;
//	byte normal_y;
//	byte normal_z;
//
//	char unknown4_1;
//
//	byte bitangent_x;
//	byte bitangent_y;
//	byte bitangent_z;
//
//	char unknown5_1;
//
//	byte tangent_x;
//	byte tangent_y;
//	byte tangent_z;
//
//	char unknown6_5[5];
//};

// A struct containing constants about the different known vertex formats
//struct vertex_format {
//	static constexpr word default_format = 0;
//	static constexpr word weighted_format = 3;
//	static constexpr word cinematic_format = 4;
//};
//

// A struct containing constants about the different known MaterialIds
//struct MaterialId
//{
//	static constexpr uint32_t bow_wave = 22;
//	static constexpr uint32_t non_renderable = 26;
//	static constexpr uint32_t texture_combo_vertex_wind = 29;
//	static constexpr uint32_t texture_combo = 30;
//	static constexpr uint32_t decal_waterfall = 31;
//	static constexpr uint32_t standard_simple = 32;
//	static constexpr uint32_t campaign_trees = 34;
//	static constexpr uint32_t point_light = 38;
//	static constexpr uint32_t static_point_light = 45;
//	static constexpr uint32_t debug_geometry = 46;
//	static constexpr uint32_t custom_terrain = 49;
//	static constexpr uint32_t weighted_cloth = 58;
//	static constexpr uint32_t cloth = 60;
//	static constexpr uint32_t collision = 61;
//	static constexpr uint32_t collision_shape = 62;
//	static constexpr uint32_t tiled_dirtmap = 63;
//	static constexpr uint32_t ship_ambientmap = 64;
//	static constexpr uint32_t weighted = 65;
//	static constexpr uint32_t projected_decal = 67;
//	static constexpr uint32_t default_material = 68;
//	static constexpr uint32_t grass = 69;
//	static constexpr uint32_t weighted_skin = 70;
//	static constexpr uint32_t decal = 71;
//	static constexpr uint32_t decal_dirtmap = 72;
//	static constexpr uint32_t dirtmap = 73;
//	static constexpr uint32_t tree = 74;
//	static constexpr uint32_t tree_leaf = 75;
//	static constexpr uint32_t weighted_decal = 77;
//	static constexpr uint32_t weighted_decal_dirtmap = 78;
//	static constexpr uint32_t weighted_dirtmap = 79;
//	static constexpr uint32_t weighted_skin_decal = 80;
//	static constexpr uint32_t weighted_skin_decal_dirtmap = 81;
//	static constexpr uint32_t weighted_skin_dirtmap = 82;
//	static constexpr uint32_t water = 83;
//	static constexpr uint32_t unlit = 84;
//	static constexpr uint32_t weighted_unlit = 85;
//	static constexpr uint32_t terrain_blend = 86;
//	static constexpr uint32_t projected_decal_v2 = 87;
//	static constexpr uint32_t ignore = 88;
//	static constexpr uint32_t tree_billboard_material = 89;
//	static constexpr uint32_t water_displace_volume = 91;
//	static constexpr uint32_t rope = 93;
//	static constexpr uint32_t campaign_vegetation = 94;
//	static constexpr uint32_t projected_decal_v3 = 95;
//	static constexpr uint32_t weighted_texture_blend = 96;
//	static constexpr uint32_t projected_decal_v4 = 97;
//	static constexpr uint32_t global_terrain = 98;
//	static constexpr uint32_t decal_overlay = 99;
//	static constexpr uint32_t alpha_blend = 100;
//
//	uint32_t uiValue;
//};

// A struct containing constants about the different known TextureTypes
// Also works as a class as it can use "getString" to get text info on each type
//struct item_base
//{
//
//
//};
//
//struct safe_enum_base
//{
////	virtual bool addToMap(item I) {};
//};
//
//struct item : public item_base
//{
//	operator dword()
//	{
//		return dwKey;
//	}
//	
//	item(item_base I)
//	{
////		PSEB->addToMap(i);
//	}
//
//	dword	dwKey;
//	string	strValue;
//};
//
//
//
//
//
//struct safe_enum_item
//{
//	safe_enum_item(item I)
//	{
////		PSEB->addToMap(i);
//	}
//
//	
//	safe_enum_base* PSEB;
//};
//
//struct safe_enum : public safe_enum_base
//{
//	/*item ShaderId1 = { 1, "ShanderId1" };
//	item ShaderId2 = { 2, "ShanderId2" };
//	item ShaderId3 = 3;*/
//} _test;
//
//
////dword dw = _test.ShaderId1;
//
//class texture_type
//{
//public:
//	static const struct values {
//		static constexpr uint32_t	uiDiffuse = 0;
//		static constexpr uint32_t	uiNormal = 1;
//		static constexpr uint32_t	uiMask = 3;
//		static constexpr uint32_t	uiAmbientOcclusion = 5;
//		static constexpr uint32_t	uiTilingDirtUV2 = 7;
//		static constexpr uint32_t	uiDirtAlphaMask = 8;
//		static constexpr uint32_t	uiSkinMask = 10;
//		static constexpr uint32_t	uiSpecular = 11;
//		static constexpr uint32_t	uiGlossMap = 12;
//		static constexpr uint32_t	uiDecalDirtmap = 13;
//		static constexpr uint32_t	uiDecalDirtmask = 14;
//		static constexpr uint32_t	uiDecalMask = 15;
//		static constexpr uint32_t	uiDiffuseDamage = 17;
//	};
//
//	texture_type()
//	{
//
//	}
//
//	//	using _value::operator=;
//
//protected:
//	virtual const char* getTextureTypeString(uint32_t uiValue);
//
//};
//
//
//
//
//template <class T>
//struct _value_info
//{
//
//
//
//	operator T*()
//	{
//		return &Content;
//	}
//
//
//	operator T()
//	{
//		return Content;
//	}
//
//
//
//
//
//
//
//	dword dwOfsset;
//	dword dwSize;
//	dword dwMaxLength;
//	char* pPointer;
//
//
//	T Content;
//};
//
//
//
//
//
//
//
//struct files_strings
//{
//
//
//
//};
//
//
//
//
//
//
//
//// The lod group data
//struct _RMV2_Lod_Data
//{
//	// The Lod Data Header, very different from the "LOD Header", contains impotant data on the Lod group itself
//	_RMV2_Lod_Data_Header Header;
//
//	_RMV2_SupplementaryBone_Data* PSupplementaryBone_Data[255];
//	_RMV2_Texture_Data* PTextureData[255];
//
//	// ** MAYBE the folowing is true, maybe not, but they need to stay in to preserve the size **
//	//4 Bytes - ? // It's always 00.00.00.00, probably a separator or a null mask.
//
//   //4 Bytes - ? // Normally 00.00.00.00, FF.FF.FF.FF if the group has a mask texture.
//	uint32 uiUnknown4;
//	uint32 uiMarkTextureFlag; //maybe
//
//	_RMV2_Vertex_Default_Data** PPVerticeData;
//
//	_RMV2_Indice_Data**  PPIndice_Data;
//};
//
//
//
//struct _RMV2_LodGounpBlock
//{
//	_RMV2_Lod_Data ** PLodGroups;
//};
//
//
//
//
//
//struct _RMV2_File
//{
//	_RMV2_File_Header	FileHeader;
//	_RMV2_Lod_Header	PPLodHeaders[255];
//	_RMV2_Lod_Data*		LodData[255][255];
//};
//
//
//// Vertex data struct, for now this can be ignored
//struct _RMV2_Vertex_Data_
//{
//	half pos_x;
//	half pos_z;
//	half pos_y;
//
//	char unknown1_2[2];
//
//	half textcord_u;
//	half textcord_v;
//	half textcord_u2;
//	half textcord_v2;
//
//	char unknown2_1;
//
//	byte normal_x;
//	byte normal_y;
//	byte normal_z;
//
//	char unknown3_1;
//
//	byte bitangent_x;
//	byte bitangent_y;
//	byte bitangent_z;
//
//	char unknown4_1;
//
//	byte tangent_x;
//	byte tangent_y;
//	byte tangent_z;
//
//	char unknown5_5[5];
//};



#define SIGNATURE 0x32564D52
#define SIGNATURE_DEC 844516690;


//struct string_offse_and_lenghth
//{
//	dword	dwFileOffset;
//	string	strContent;
//	dword	dwMaxLength;
//};

//class RigidMaterial
//{
//public:
//	static constexpr uint32_t bow_wave = 22;
//	static constexpr uint32_t non_renderable = 26;
//	static constexpr uint32_t texture_combo_vertex_wind = 29;
//	static constexpr uint32_t texture_combo = 30;
//	static constexpr uint32_t decal_waterfall = 31;
//	static constexpr uint32_t standard_simple = 32;
//	static constexpr uint32_t campaign_trees = 34;
//	static constexpr uint32_t point_light = 38;
//	static constexpr uint32_t static_point_light = 45;
//	static constexpr uint32_t debug_geometry = 46;
//	static constexpr uint32_t custom_terrain = 49;
//	static constexpr uint32_t weighted_cloth = 58;
//	static constexpr uint32_t cloth = 60;
//	static constexpr uint32_t collision = 61;
//	static constexpr uint32_t collision_shape = 62;
//	static constexpr uint32_t tiled_dirtmap = 63;
//	static constexpr uint32_t ship_ambientmap = 64;
//	static constexpr uint32_t weighted = 65;
//	static constexpr uint32_t projected_decal = 67;
//	static constexpr uint32_t default_value = 68;
//	static constexpr uint32_t grass = 69;
//	static constexpr uint32_t weighted_skin = 70;
//	static constexpr uint32_t decal = 71;
//	static constexpr uint32_t decal_dirtmap = 72;
//	static constexpr uint32_t dirtmap = 73;
//	static constexpr uint32_t tree = 74;
//	static constexpr uint32_t tree_leaf = 75;
//	static constexpr uint32_t weighted_decal = 77;
//	static constexpr uint32_t weighted_decal_dirtmap = 78;
//	static constexpr uint32_t weighted_dirtmap = 79;
//	static constexpr uint32_t weighted_skin_decal = 80;
//	static constexpr uint32_t weighted_skin_decal_dirtmap = 81;
//	static constexpr uint32_t weighted_skin_dirtmap = 82;
//	static constexpr uint32_t water = 83;
//	static constexpr uint32_t unlit = 84;
//	static constexpr uint32_t weighted_unlit = 85;
//	static constexpr uint32_t terrain_blend = 86;
//	static constexpr uint32_t projected_decal_v2 = 87;
//	static constexpr uint32_t ignore = 88;
//	static constexpr uint32_t tree_billboard_material = 89;
//	static constexpr uint32_t water_displace_volume = 91;
//	static constexpr uint32_t rope = 93;
//	static constexpr uint32_t campaign_vegetation = 94;
//	static constexpr uint32_t projected_decal_v3 = 95;
//	static constexpr uint32_t weighted_texture_blend = 96;
//	static constexpr uint32_t projected_decal_v4 = 97;
//	static constexpr uint32_t global_terrain = 98;
//	static constexpr uint32_t decal_overlay = 99;
//	static constexpr uint32_t alpha_blend = 100;
//};
//

// The very file chuck of any RMV2 file, can't be read in one struct/chunk


// data of indices, for now, just now the size and position of it and the file and jump over it
struct _RMV2_Indice_Data
{
	//	2 Bytes[UInt16] - Index1
	char uiIndex1[2];

	// 2 Bytes[UInt16] - Index2 // CA loves to invert indices 2 and 3... this could be the case!
	char uiIndex2[2];


	// 2 Bytes[UInt16] - Index3 // CA loves to invert indices 2 and 3... this could be the case!
	char uiIndex3[2];

};

// data of indices, for now, just now the size of it (which requires some code to find out) and position of it and the file and jump over it
struct _RMV2_Vertex_Data_Default
{
	//half half;
	//byte t_norm;
	//XMFLOAT3 piv;
	//XMStoreFloat3(&piv, pivot);
	//file.read(reinterpret_cast<char *>(&t_pos), sizeof(half));
	//vertex->position.x = t_pos + piv.x;
	//file.read(reinterpret_cast<char *>(&t_pos), sizeof(half));
	//vertex->position.y = t_pos + piv.y;
	//file.read(reinterpret_cast<char *>(&t_pos), sizeof(half));
	//vertex->position.z = -t_pos + piv.z;
	//file.seekg(2, ios_base::cur);
	//// 8

	//file.read(reinterpret_cast<char *>(&t_pos), sizeof(half));
	//vertex->texCoord.x = t_pos;
	//file.read(reinterpret_cast<char *>(&t_pos), sizeof(half));
	//vertex->texCoord.y = 1.0f - t_pos;
	//file.read(reinterpret_cast<char *>(&t_pos), sizeof(half));
	//vertex->texCoord2.x = t_pos;
	//file.read(reinterpret_cast<char *>(&t_pos), sizeof(half));
	//vertex->texCoord2.y = 1.0f - t_pos;
	//// 16
	//
	//
	//file.read(reinterpret_cast<char *>(&t_norm), sizeof(byte));
	//vertex->normal.z = -(t_norm / 127.0f - 1.0f);
	//file.read(reinterpret_cast<char *>(&t_norm), sizeof(byte));
	//vertex->normal.y = t_norm / 127.0f - 1.0f;
	//file.read(reinterpret_cast<char *>(&t_norm), sizeof(byte));
	//vertex->normal.x = t_norm / 127.0f - 1.0f;
	//XMStoreFloat3(&vertex->normal, XMVector3Normalize(XMLoadFloat3(&vertex->normal)));
	//file.seekg(1, ios_base::cur);

	////20
	//file.read(reinterpret_cast<char *>(&t_norm), sizeof(byte));
	//vertex->bitangent.z = -(t_norm / 127.0f - 1.0f);
	//file.read(reinterpret_cast<char *>(&t_norm), sizeof(byte));
	//vertex->bitangent.y = t_norm / 127.0f - 1.0f;
	//file.read(reinterpret_cast<char *>(&t_norm), sizeof(byte));
	//vertex->bitangent.x = t_norm / 127.0f - 1.0f;
	//XMStoreFloat3(&vertex->bitangent, XMVector3Normalize(XMLoadFloat3(&vertex->bitangent)));
	//file.seekg(1, ios_base::cur);

	//// 24
	//file.read(reinterpret_cast<char *>(&t_norm), sizeof(byte));
	//vertex->tangent.z = -(t_norm / 127.0f - 1.0f);
	//file.read(reinterpret_cast<char *>(&t_norm), sizeof(byte));
	//vertex->tangent.y = t_norm / 127.0f - 1.0f;
	//file.read(reinterpret_cast<char *>(&t_norm), sizeof(byte));
	//vertex->tangent.x = t_norm / 127.0f - 1.0f;
	//XMStoreFloat3(&vertex->tangent, XMVector3Normalize(XMLoadFloat3(&vertex->tangent)));
	//file.seekg(5, ios_base::cur);
	//// size 32 
	////size 35


};


struct _RMV2_Vertex_Converted
{
	//half half_floatingpoint;
	//byte t_norm;
	//XMFLOAT3 piv;
	//XMStoreFloat3(&piv, pivot);

	//file.read(reinterpret_cast<char *>(&t_pos), sizeof(half));
	//vertex->position.x = t_pos + piv.x;

	half position_x;


	//file.read(reinterpret_cast<char *>(&t_pos), sizeof(half));
	//vertex->position.y = t_pos + piv.y;

	word position_y;

	//file.read(reinterpret_cast<char *>(&t_pos), sizeof(half));
	//vertex->position.z = -t_pos + piv.z;

	half position_Z;

	//file.seekg(2, ios_base::cur);
	word Uknown1_2;

	//// offset 8

	//file.read(reinterpret_cast<char *>(&t_pos), sizeof(half));
	//vertex->texCoord.x = t_pos;
	half texture_u1;

	//file.read(reinterpret_cast<char *>(&t_pos), sizeof(half));
	//vertex->texCoord.y = 1.0f - t_pos;
	half texture_v1;

	//file.read(reinterpret_cast<char *>(&t_pos), sizeof(half));
	//vertex->texCoord2.x = t_pos;
	half texture_u2;

	//file.read(reinterpret_cast<char *>(&t_pos), sizeof(half));
	//vertex->texCoord2.y = 1.0f - t_pos;
	half texture_v2;

	//// offset 16
	//
	//
	//file.read(reinterpret_cast<char *>(&t_norm), sizeof(byte));
	//vertex->normal.z = -(t_norm / 127.0f - 1.0f);
	//file.read(reinterpret_cast<char *>(&t_norm), sizeof(byte));
	//vertex->normal.y = t_norm / 127.0f - 1.0f;
	//file.read(reinterpret_cast<char *>(&t_norm), sizeof(byte));
	//vertex->normal.x = t_norm / 127.0f - 1.0f;
	//XMStoreFloat3(&vertex->normal, XMVector3Normalize(XMLoadFloat3(&vertex->normal)));
	//file.seekg(1, ios_base::cur);

	////20
	//file.read(reinterpret_cast<char *>(&t_norm), sizeof(byte));
	//vertex->bitangent.z = -(t_norm / 127.0f - 1.0f);
	//file.read(reinterpret_cast<char *>(&t_norm), sizeof(byte));
	//vertex->bitangent.y = t_norm / 127.0f - 1.0f;
	//file.read(reinterpret_cast<char *>(&t_norm), sizeof(byte));
	//vertex->bitangent.x = t_norm / 127.0f - 1.0f;
	//XMStoreFloat3(&vertex->bitangent, XMVector3Normalize(XMLoadFloat3(&vertex->bitangent)));
	//file.seekg(1, ios_base::cur);

	//// 24
	//file.read(reinterpret_cast<char *>(&t_norm), sizeof(byte));
	//vertex->tangent.z = -(t_norm / 127.0f - 1.0f);
	//file.read(reinterpret_cast<char *>(&t_norm), sizeof(byte));
	//vertex->tangent.y = t_norm / 127.0f - 1.0f;
	//file.read(reinterpret_cast<char *>(&t_norm), sizeof(byte));
	//vertex->tangent.x = t_norm / 127.0f - 1.0f;
	//XMStoreFloat3(&vertex->tangent, XMVector3Normalize(XMLoadFloat3(&vertex->tangent)));
	//file.seekg(5, ios_base::cur);
	//// size 32 
	////size 35


};


struct _RMV2_Vertex_Raw
{

	half pos_x;
	half pos_z;
	half pos_y;
	
	char unknown1_2[2];
																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																									
	half textcord_u;
	half textcord_v;
	half textcord_u2;
	half textcord_v2;



	byte normal_x;
	byte normal_y;
	byte normal_z;

	char unknown4_1;

	byte bitangent_x;
	byte bitangent_y;
	byte bitangent_z;

	char unknown5_1;

	byte tangent_x;
	byte tangent_y;
	byte tangent_z;
	
	char unknown6_5[5];
};

// A struct containing constants about the different known vertex formats
struct vertex_format {
	static constexpr word default_format = 0;
	static constexpr word weighted_format = 3;
	static constexpr word cinematic_format = 4;
};


// A struct containing constants about the different known MaterialIds
//struct MaterialId
//{
//	static constexpr uint32_t bow_wave = 22;
//	static constexpr uint32_t non_renderable = 26;
//	static constexpr uint32_t texture_combo_vertex_wind = 29;
//	static constexpr uint32_t texture_combo = 30;
//	static constexpr uint32_t decal_waterfall = 31;
//	static constexpr uint32_t standard_simple = 32;
//	static constexpr uint32_t campaign_trees = 34;
//	static constexpr uint32_t point_light = 38;
//	static constexpr uint32_t static_point_light = 45;
//	static constexpr uint32_t debug_geometry = 46;
//	static constexpr uint32_t custom_terrain = 49;
//	static constexpr uint32_t weighted_cloth = 58;
//	static constexpr uint32_t cloth = 60;
//	static constexpr uint32_t collision = 61;
//	static constexpr uint32_t collision_shape = 62;
//	static constexpr uint32_t tiled_dirtmap = 63;
//	static constexpr uint32_t ship_ambientmap = 64;
//	static constexpr uint32_t weighted = 65;
//	static constexpr uint32_t projected_decal = 67;
//	static constexpr uint32_t default_material = 68;
//	static constexpr uint32_t grass = 69;
//	static constexpr uint32_t weighted_skin = 70;
//	static constexpr uint32_t decal = 71;
//	static constexpr uint32_t decal_dirtmap = 72;
//	static constexpr uint32_t dirtmap = 73;
//	static constexpr uint32_t tree = 74;
//	static constexpr uint32_t tree_leaf = 75;
//	static constexpr uint32_t weighted_decal = 77;
//	static constexpr uint32_t weighted_decal_dirtmap = 78;
//	static constexpr uint32_t weighted_dirtmap = 79;
//	static constexpr uint32_t weighted_skin_decal = 80;
//	static constexpr uint32_t weighted_skin_decal_dirtmap = 81;
//	static constexpr uint32_t weighted_skin_dirtmap = 82;
//	static constexpr uint32_t water = 83;
//	static constexpr uint32_t unlit = 84;
//	static constexpr uint32_t weighted_unlit = 85;
//	static constexpr uint32_t terrain_blend = 86;
//	static constexpr uint32_t projected_decal_v2 = 87;
//	static constexpr uint32_t ignore = 88;
//	static constexpr uint32_t tree_billboard_material = 89;
//	static constexpr uint32_t water_displace_volume = 91;
//	static constexpr uint32_t rope = 93;
//	static constexpr uint32_t campaign_vegetation = 94;
//	static constexpr uint32_t projected_decal_v3 = 95;
//	static constexpr uint32_t weighted_texture_blend = 96;
//	static constexpr uint32_t projected_decal_v4 = 97;
//	static constexpr uint32_t global_terrain = 98;
//	static constexpr uint32_t decal_overlay = 99;
//	static constexpr uint32_t alpha_blend = 100;
//
//	uint32_t uiValue;
//};

// A struct containing constants about the different known TextureTypes
// Also works as a class as it can use "getString" to get text info on each type
//struct item_base
//{
//
//
//};
//
//struct safe_enum_base
//{
////	virtual bool addToMap(item I) {};
//};
//
//struct item : public item_base
//{
//	operator dword()
//	{
//		return dwKey;
//	}
//	
//	item(item_base I)
//	{
////		PSEB->addToMap(i);
//	}
//
//	dword	dwKey;
//	string	strValue;
//};
//
//
//
//
//
//struct safe_enum_item
//{
//	safe_enum_item(item I)
//	{
////		PSEB->addToMap(i);
//	}
//
//	
//	safe_enum_base* PSEB;
//};
//
//struct safe_enum : public safe_enum_base
//{
//	/*item ShaderId1 = { 1, "ShanderId1" };
//	item ShaderId2 = { 2, "ShanderId2" };
//	item ShaderId3 = 3;*/
//} _test;
//
//
////dword dw = _test.ShaderId1;

class texture_type
{
public:
	static const struct values {
		static constexpr uint32_t	uiDiffuse = 0;
		static constexpr uint32_t	uiNormal = 1;
		static constexpr uint32_t	uiMask = 3;
		static constexpr uint32_t	uiAmbientOcclusion = 5;
		static constexpr uint32_t	uiTilingDirtUV2 = 7;
		static constexpr uint32_t	uiDirtAlphaMask = 8;
		static constexpr uint32_t	uiSkinMask = 10;
		static constexpr uint32_t	uiSpecular = 11;
		static constexpr uint32_t	uiGlossMap = 12;
		static constexpr uint32_t	uiDecalDirtmap = 13;
		static constexpr uint32_t	uiDecalDirtmask = 14;
		static constexpr uint32_t	uiDecalMask = 15;
		static constexpr uint32_t	uiDiffuseDamage = 17;
	};

	texture_type()
	{

	}

	//	using _value::operator=;

protected:
	virtual const char* getTextureTypeString(uint32_t uiValue);

};




template <class T>
struct _value_info
{



	operator T*()
	{
		return &Content;
	}


	operator T()
	{
		return Content;
	}







	dword dwOfsset;
	dword dwSize;
	dword dwMaxLength;
	char* pPointer;


	T Content;
};







struct files_strings
{



};







// The lod group data
struct _RMV2_Lod_Data
{
	// The Lod Data Header, very different from the "LOD Header", contains impotant data on the Lod group itself
	_RMV2_Lod_Data_Header Header;

	_RMV2_SupplementaryBone_Data* PSupplementaryBone_Data[255];
	_RMV2_Texture_Data* PTextureData[255];

	// ** MAYBE the folowing is true, maybe not, but they need to stay in to preserve the size **
	//4 Bytes - ? // It's always 00.00.00.00, probably a separator or a null mask.

   //4 Bytes - ? // Normally 00.00.00.00, FF.FF.FF.FF if the group has a mask texture.
	uint32 uiUnknown4;
	uint32 uiMarkTextureFlag; //maybe

	//_RMV2_Vertex_Default_Data** PPVerticeData;

	//_RMV2_Indice_Data**  PPIndice_Data;


	vector<_RMV2_Vertex_Raw> m_vecRawVertices;
	vector<_RMV2_Vertex_Converted> m_vecConvertedVerticec;

};



struct _RMV2_LodGounpBlock
{
	_RMV2_Lod_Data ** PLodGroups;
};





struct _RMV2_File
{
	_RMV2_File_Header	FileHeader;
	_RMV2_Lod_Header	PPLodHeaders[255];
	_RMV2_Lod_Data*		LodData[255][255];
};

using half_float::half;
// Vertex data struct, for now this can be ignored
struct _RMV2_Vertex_Data_
{
	half pos_x;
	half pos_z;
	half pos_y;

	char unknown1_2[2];

	half u;
	half v;
	half_float::half u2;
	half v2;

	char unknown2_1;

	byte normal_x;
	byte normal_y;
	byte normal_z;

	char unknown3_1;

	byte bitangent_x;
	byte bitangent_y;
	byte bitangent_z;

	char unknown4_1;

	byte tangent_x;
	byte tangent_y;
	byte tangent_z;

	char unknown5_5[5];
};
