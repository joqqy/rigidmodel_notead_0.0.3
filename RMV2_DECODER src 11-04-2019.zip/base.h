#pragma once
//class basef1
//{
//public:
//	base();
//	virtual ~base();
//};
//
