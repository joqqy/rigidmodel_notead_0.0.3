
#include "rmv2_file.h"
#include "definitions.h"
#include <window.h>
#include "structs.h"
//#include <error_codes.h>

using namespace DirectX;
	const char * texture_type::getTextureTypeString(uint32_t uiValue)
	{
		switch (uiValue)
		{
		case values::uiDiffuse:
			return "Diffuse";

		case values::uiSpecular:
			return "Specular";

		case values::uiNormal:
			return "Normal Map";

		case values::uiGlossMap:
			return "Gloss Map";

		case values::uiAmbientOcclusion:
			return "Ambient Acclusion";

		case values::uiDecalDirtmap:
			return "Decal Dirt Map";

		case values::uiDecalDirtmask:
			return "Decal Dirt Mask";

		case values::uiDecalMask:
			return "Decal Mask";

		case values::uiDiffuseDamage:
			return "Diffuse Damage";

		case values::uiDirtAlphaMask:
			return "Dirt Alpha Mask";

		case values::uiMask:
			return "Mask";

		case values::uiSkinMask:
			return "Skin Mask";

		case values::uiTilingDirtUV2:
			return "Tilinig Dirt UV2";
		
		default:
			return "***unknown***";
		}

	};


//using namespace std;

size_t rmv2_file::_getFileSize(const char* pchFileName)
{
	streampos begin, end;
	ifstream ifsFile(pchFileName, ios::in | ios::binary);
	/* if ( ifsFile.fail() ) {
        
		 this->m_error_code = predefined_error_codes::FILE_NOT_FOUND;
		 if (window::poMainWindow)
			 window::getOKErrorBox(window::poMainWindow, "Error!", "File not opened.");
		 else
			 window::getOKErrorBox(NULL, "Error!", "File not opened.");
		 
		 writeDebugMessage("rmv2_file::_getFileSize: File not opened");
		 
		 return false;
    }*/

	begin = ifsFile.tellg();
	ifsFile.seekg(0, ios::end);
	end = ifsFile.tellg();
	ifsFile.close();

	size_t rEnd = end;
	size_t rBegin = begin;

	//if (rEnd - rBegin >= 0) {

	//	this->m_error_code = predefined_error_codes::FILE_SIZE_ZERO;
	//	if (window::poMainWindow)
	//		window::getOKErrorBox(window::poMainWindow, "Error!", "File size = 0!");
	//	else
	//		window::getOKErrorBox(NULL, "Error!", "File size = 0!");

	//	writeDebugMessage("rmv2_file::_getFileSize: File size = 0!");

	//	return false;
	//}



	return (rEnd - rBegin);

};



//
//rmv2_file::rmv2_file()
//{
//
//}
//
//
//rmv2_file::~rmv2_file()
//{
//
//}

void rmv2_file::setGroupName(u32 lod, u32 group, const string strContent)
{

	m_File.LodData[lod][group]->Header.GroupName.setString(strContent);
	saveToBuffer(&m_File.LodData[lod][group]->Header.GroupName);
	// TODO: make sure this works
}

void rmv2_file::setShadername(u32 lod, u32 group, const string strContent)
{
	m_File.LodData[lod][group]->Header.ShaderName.setString(strContent);
	saveToBuffer(&m_File.LodData[lod][group]->Header.ShaderName);
	// TODO: Make sure this works

}

void rmv2_file::setTextureDirectory(u32 lod, u32 group, const string strContent)
{
	m_File.LodData[lod][group]->Header.TextureDirectory.setString(strContent);
	saveToBuffer(&m_File.LodData[lod][group]->Header.TextureDirectory);
	// TODO: make sure this works
}

void rmv2_file::setAllTextureDirectories(const string strContent)
{
	for (uint lod = 0; lod < m_File.FileHeader.LodsCount; lod++)
		for (uint group = 0; group < m_File.PPLodHeaders[lod].GroupsCount; group++)
		{
			m_File.LodData[lod][group]->Header.TextureDirectory.setString(strContent);
			saveToBuffer(&m_File.LodData[lod][group]->Header.TextureDirectory);
		}
}


void rmv2_file::setTextureDirAndNamne(u32 lod, u32 group, u32 texture, const string strContent)
{
	// TODO: check this
	m_File.LodData[lod][group]->PTextureData[texture]->TextureDirAndFileName.setString(strContent);
		
	 	saveToBuffer(&m_File.LodData[lod][group]->PTextureData[texture]->TextureDirAndFileName);
	// TODO: make sure this works
}

//void rmv2_file::setallTexturesByNumber(u32 texture, const string strContent)
//{
//	for (int lod = 0; lod < m_File.FileHeader.LodsCount; lod++)
//		for (int group = 0; group < m_File.PPLodHeaders[lod].GroupsCount; group++)
//				setTextureDirAndNamne(lod, group, texture, strContent);
//}

void rmv2_file::setallTexturesByNumber(u32 texture, const string strName)
{
	for (int lod = 0; lod < m_File.FileHeader.LodsCount; lod++)
		for (int group = 0; group < m_File.PPLodHeaders[lod].GroupsCount; group++)
			for (int i = 0; i < m_File.LodData[lod][group]->Header.uiTextureCount; i++)
			{				
				//string str = m_File.LodData[lod][group]->Header.pchTextureDirectory;
				//str += strName;

				//m_File.LodData[lod][group]->PTextureData[texture]->TextureDirAndFileName.setString(str);


				saveToBuffer(&m_File.LodData[lod][group]->PTextureData[texture]->TextureDirAndFileName);
			}
}



bool rmv2_file::readLodDataHeaderItems(dword lod, dword group)
{
	
	 
	#define read_item(item) readBuffer(&m_File.LodData[lod][group]->Header.##item, sizeof(m_File.LodData[lod][group]->Header.##item));

	#define item(_item) m_File.LodData[lod][group]->Header.##_item

	   
	//readBuffer(&m_File.LodData[lod][group]->Header.uiMaterialId, sizeof(uint32));

	//uint32 uiMaterialId;		// 4 Bytes[UInt32] - ? // Looks like and ID or a flag, it's always 65 for the moment.
	read_item(uiMaterialId);

	//uint32 uiUnkown;			// No idea. It's a very big number normally.	
	read_item(uiUnkown);

	//uint32 uiUnkown1_1;			// No idea. It's a very big number normally.
	read_item(uiUnkown1_1);	

	//uint32 uiVerticesCount;		// 4 Bytes[UInt32] - VerticesCount
	read_item(uiVerticesCount);

	//(uint32 uiUnkown2_1;			// No idea. It's a very big number normally.
	read_item(uiUnkown2_1);
	
	//uint32 uiIndicesCount;		// 	4 Bytes[UInt32] - IndicesCount
	read_item(uiIndicesCount);

	// offset 24

	//float GroupMinimumX;
	read_item(GroupMinimumX);
	
	//float fGroupMinimumY;
	read_item(fGroupMinimumY);
	
	//float fGroupMinimumZ;
	read_item(fGroupMinimumZ);

	//float fGroupMaximumX;
	read_item(fGroupMaximumX);
	
	//float fGroupMaximumY;
	read_item(fGroupMaximumY);

	//float fGroupMaximumZ;
	read_item(fGroupMaximumZ);

	// offset 48
	   
	//char  pchShaderName[12];
	item(ShaderName) = m_uiBufferOffset; // save offset
	read_item(pchShaderName);		
	item(ShaderName) = item(pchShaderName);  // save text
	
	//  0

	//offset 60


	//char pBlocknown4_20[20];  //offset of the item MAY be determined of the length of the previous string
	read_item(pBlocknown4_20);
	
	//offset 80

	
	read_item(wVertexFormat);
	
	
	//char pchGroupName[32];		// 32 Bytes [0-Padded String] - GroupName
	item(GroupName) = m_uiBufferOffset; // save offset
	read_item(pchGroupName);	
	item(GroupName) = item(pchGroupName);  // save text
	

	
	//char pchTexturesDirectory[256];		// 256 Bytes[0 - Padded String] - TexturesDirectory
	item(TextureDirectory) = m_uiBufferOffset; // save offset
	read_item(pchTextureDirectory);
	item(TextureDirectory) = item(pchTextureDirectory); // save text

	// 256
	
	// jump 56 and read this and then jump back                                                                                                                                                                                                                                               


	//char Unknown3_422[422];//422 Bytes - ? // 422 bytes of perplexity... shader settings? 4 bytes in the middle of this block change if
	read_item(Unknown3_422);

	//I scale the whole model so it's probably not a single block!
	
	//uint32 uiSupplementarBonesCount; //4 Bytes[UInt32] - SupplementarBonesCount
	read_item(uiSupplementarBonesCount);


	//int32 uiTextureCount; //4 Bytes[UInt32] - TexturesCount
	read_item(uiTextureCount);

	//char Unknown140[140];	//140 Bytes - ? // No idea.
	read_item(Unknown140);

	//uint32_t uiUnknow_1_1;
	//read_item(uiUnknow_1_1);


	return true;
};



//
//bool rmv2_file::readFileHeader(string strFileName)
//{
//	this->readBuffer(&m_File.FileHeader, sizeof(_RMV2_File_Header));
//	return true;
//}


bool rmv2_file::readFile(string strFileName)
{
	m_uiBufferOffset = 0;
	m_strFileName2 = strFileName;
	
	if (!readEntireFileIntoBuffer(m_strFileName2))
		return false;
	
	if (m_uiFileSize == 0)
	{
		window::getOKErrorBox(window::poMainWindow, "File Size = 0");
		return false;

	}
	// TODO: make the file string single "\" and not "double"
	readFileHeader(strFileName);
	//return false;


	readLodHeaders(strFileName);
	
	readLodData(strFileName);

	



	bFIleLoaded = true;
	
	



	return true;

}

bool rmv2_file::writeFileAs(string strFileName)
{
	m_strFileName2 = strFileName;
	return writeEntireFileFromBuffer(strFileName);
}

bool rmv2_file::readVertices()
{
	XMFLOAT3 xf;


	uint ui = m_uiBufferOffset;
	_RMV2_Vertex_Raw vertices;
	readBuffer(&vertices, sizeof(_RMV2_Vertex_Raw));
	
	

	xf.x = vertices.pos_x;
	xf.y = vertices.pos_y;
	xf.z = vertices.pos_z;
		
	
	
	
	float x = vertices.pos_x;
	float y = vertices.pos_y;
	float z = vertices.pos_z;	

	float u = vertices.textcord_u;
	float v = vertices.textcord_v;

	
		return false;
}

bool rmv2_file::writeFile()
{
	return writeEntireFileFromBuffer(m_strFileName2);
}

bool rmv2_file::readFileHeader(string strFileName)
{
	readBuffer(&m_File.FileHeader, sizeof(_RMV2_File_Header));
	
 	if (m_File.FileHeader.Signature.dwSignature != SIGNATURE)	
	{
		window::getOKErrorBox(window::poMainWindow, "Invalid Rigid Mod v2 File!");
		

		m_strLastEvent = "ERROR: ";
		m_strLastEvent =+ "File: " + strFileName + "' is NOT a valid rigid_model_v2 file!";
		m_bSucces = false;

		m_strLogText += m_strLastEvent + " \n";

		return false;

	}
	else
	{
		m_strLastEvent = "SUCCESS: ";
		m_strLastEvent = +"File: " + strFileName + "' is valid rigid_model_v2 file!";
		m_bSucces = false;

		m_strLogText += m_strLastEvent + " \n";

		return true;
	}


	return true;
}


// // read the lod header
bool rmv2_file::readLodHeaders(string strFileName)
{
	//m_File.PPLodHeaders = new _RMV2_Lod_Header*[m_File.FileHeader.LodsCount];
	

	for (int i = 0; i < m_File.FileHeader.LodsCount; i++)
	{
		//m_File.PPLodHeaders[i] = new _RMV2_Lod_Header;
		readBuffer(&m_File.PPLodHeaders[i], sizeof(_RMV2_Lod_Header));
		if (m_File.FileHeader.ModelVersion == 7)
			seekBuffer(8, rmv2_file::seek_direction::seek_forward);
		

	}	
	//if (m_File.FileHeader.ModelVersion == 7)
		//seekBuffer(8);
	return 0;
}






bool rmv2_file::readEntireFileIntoBuffer(string strFIleName)
{	
	m_uiFileSize = _getFileSize(strFIleName.c_str());		

	m_ofsFile.open(strFIleName.c_str(), ios::in | ios::binary);
	
	if (m_ofsFile.fail())	{	
		this->m_error_code = predefined_error_codes::FILE_NOT_FOUND;
		if (window::poMainWindow)
			window::getOKErrorBox(window::poMainWindow, "File not found.");
		else
			window::getOKErrorBox(NULL, "File not found.");
		writeDebugMessage("rmv2_file::_getFileSize: File not found");
		return false;
		
		
	}
	
	if (m_pFileBuffer)
		delete m_pFileBuffer;

	m_pFileBuffer = new char[m_uiFileSize];

	
	m_ofsFile.read(m_pFileBuffer, m_uiFileSize);

	m_strFileName2 = strFIleName;

	m_ofsFile.close();

	return 1;

}
bool rmv2_file::writeEntireFileFromBuffer(string strFIleName)
{

	std::ofstream m_ofsFile;
	//m_uiFileSize = _getFileSize(strFIleName.c_str());
	


	m_ofsFile.open(strFIleName.c_str(), ios::out | ios::binary);
	m_ofsFile.write(m_pFileBuffer, m_uiFileSize);


	m_strFileName2 = strFIleName;

	m_ofsFile.close();

	return 1;
}

struct _RMV2_LOD_GRUOP
{
	_RMV2_Lod_Data* PPLodData[255];
};




bool rmv2_file::readLodData(string strFileName)
{
	int lod = 0;
	int group = 0;

	

	for (lod = 0; lod < m_File.FileHeader.LodsCount; lod++)  // count the lods
	{
	
		seekBuffer(m_File.PPLodHeaders[lod].Start_offset);

		for (group = 0; group < m_File.PPLodHeaders[lod].GroupsCount; group++) // count the subgroupd
		{
			//uint32 uiMaterialId;		// 4 Bytes[UInt32] - ? // Looks like and ID or a flag, it's always 65 for the moment.
			m_File.LodData[lod][group] = new _RMV2_Lod_Data;

			//readBuffer(&m_File.LodData[lod][group]->Header, sizeof(_RMV2_Lod_Data_Header));
			readLodDataHeaderItems(lod, group);
			


			//**** read supplementary bones
			for (int i = 0; i < m_File.LodData[lod][group]->Header.uiSupplementarBonesCount; i++)
			{
				m_File.LodData[lod][group]->PSupplementaryBone_Data[i] = new _RMV2_SupplementaryBone_Data;
				readBuffer(m_File.LodData[lod][group]->PSupplementaryBone_Data[i], sizeof(_RMV2_SupplementaryBone_Data));
			}

			
			
			
			// *****  read textures inf o
 			for (int i = 0; i < m_File.LodData[lod][group]->Header.uiTextureCount; i++)
			{
				//m_File.LodData[lod][group]->PTextureData[i] = new _RMV2_Texture_Data;
				//readBuffer(m_File.LodData[lod][group]->PTextureData[i], sizeof(_RMV2_Texture_Data));

				readTextureData(lod, group, i);
			}
			

			//  jump over that "padding"			
			seekBuffer(4, seek_direction::seek_forward);
			if (m_File.LodData[lod][group]->Header.uiMaterialId == RigidMaterial::tiled_dirtmap)
				seekBuffer(16, seek_direction::seek_forward);  // file.seekg(16, ios_base::cur);
			else if (m_File.LodData[lod][group]->Header.uiMaterialId == RigidMaterial::decal
				|| m_File.LodData[lod][group]->Header.uiMaterialId == RigidMaterial::weighted_decal
				|| m_File.LodData[lod][group]->Header.uiMaterialId == RigidMaterial::weighted_skin_decal)
				seekBuffer(20, seek_direction::seek_forward); // file.seekg(20, ios_base::cur);
			else if (m_File.LodData[lod][group]->Header.uiMaterialId == RigidMaterial::dirtmap
				|| m_File.LodData[lod][group]->Header.uiMaterialId == RigidMaterial::weighted_dirtmap
				|| m_File.LodData[lod][group]->Header.uiMaterialId == RigidMaterial::weighted_skin_dirtmap)
				seekBuffer(32, seek_direction::seek_forward); // file.seekg(32, ios_base::cur);
			else if (m_File.LodData[lod][group]->Header.uiMaterialId == RigidMaterial::decal_dirtmap
				|| m_File.LodData[lod][group]->Header.uiMaterialId == RigidMaterial::weighted_decal_dirtmap
				|| m_File.LodData[lod][group]->Header.uiMaterialId == RigidMaterial::weighted_skin_decal_dirtmap)
				seekBuffer(52, seek_direction::seek_forward); // file.seekg(52, ios_base::cur);
			else if (m_File.LodData[lod][group]->Header.uiMaterialId == RigidMaterial::tree)
				seekBuffer(56, seek_direction::seek_forward); // file.seekg(56, ios_base::cur);
			seekBuffer(4, seek_direction::seek_forward); // "alpha mode"
			
			
			//jump over vertices
			//seekBuffer(vertex_size * m_File.LodData[lod][group]->Header.uiVerticesCount, seek_direction::seek_forward );
			dword vertex_size = 0;
			dword indice_size = 6;

			switch (m_File.LodData[lod][group]->Header.wVertexFormat)
			{
				case vertex_format::default_format: vertex_size = 32;
					break;
				case vertex_format::weighted_format: vertex_size = 28;
					break;
				case vertex_format::cinematic_format: vertex_size = 32;
			
			}
				
			
			
			//for (size_t k = 0; k < m_File.LodData[lod][group]->Header.uiVerticesCount; ++k)
			//seekBuffer(vertex_size * m_File.LodData[lod][group]->Header.uiVerticesCount, seek_direction::seek_forward);
		
			word w = m_File.LodData[lod][group]->Header.wVertexFormat;

			// read vertices first
			for (int x = 0; x < m_File.LodData[lod][group]->Header.uiVerticesCount; x++)
				readVertices();
			
			for (size_t k = 0; k < m_File.LodData[lod][group]->Header.uiIndicesCount / 3; ++k)
				seekBuffer(6, seek_direction::seek_forward);


		}
		//rmv2_file.

		dword dwBufferPos ;

	}
	
	
	return true;
}

bool rmv2_file::readTextureData(u32 lod, u32 group, u32 texture)
{

		vector<_RMV2_Vertex_Raw> m_vecRawVertices;
	vector<_RMV2_Vertex_Converted> m_vecConvertedVerticec;

	m_File.LodData[lod][group]->PTextureData[texture] = new _RMV2_Texture_Data;
	// read elements one by one

	readBuffer(&m_File.LodData[lod][group]->PTextureData[texture]->uiTextureType, 4);
	   	
	m_File.LodData[lod][group]->PTextureData[texture]->TextureDirAndFileName.setOffset(m_uiBufferOffset);
	readBuffer(m_File.LodData[lod][group]->PTextureData[texture]->pchTextureDirAndFileNam, 256);
	
	
	return false;
}


bool rmv2_file::readTextureInfo(string strFileName)
{
	
	
	
	return false;
}
	/*
	_RMV2_Vertex_Default_Data **PSupplementaryBone_Data[255];
	_RMV2_Texture_Data* PTextureData[255];


	//4 Bytes - ? // It's always 00.00.00.00, probably a separator or a null mask.

   //4 Bytes - ? // Normally 00.00.00.00, FF.FF.FF.FF if the group has a mask texture.
	uint32 uiUnknown4;
	uint32 uiMarkTextureFlag;

	_RMV2_Vertex_Default_Data** PPVerticeData;

	_RMV2_Indice_Data**  PPIndice_Data;

	*/
//	return true;


bool rmv2_file::readBuffer(void * pDest, size_t length)
{
	if (length + m_uiBufferOffset > m_uiFileSize - 1)
		return 0;

	CopyMemory(pDest, &m_pFileBuffer[m_uiBufferOffset], length);
	
	m_uiBufferOffset += length;
	
	return true;
}

bool rmv2_file::saveToBuffer(const str_info * PStrInfo)
{
	memcpy(&m_pFileBuffer[PStrInfo->getOffset()], PStrInfo->getStrContent(), PStrInfo->getLength() );
	return true;
}

bool rmv2_file::seekBuffer(size_t offset, rmv2_file::seek_direction i)
{
	
	if (i == seek_direction::seek_forward)
	{
		if (m_uiBufferOffset + offset < m_uiFileSize)
			m_uiBufferOffset += offset;
		else
			return false;
	}	
	else if (i == seek_direction::seek_backward)
	{

		if (m_uiBufferOffset - offset > 0)
			m_uiBufferOffset -= offset;
		else
			return false;
	}
	

	return true;
}

bool rmv2_file::seekBuffer(size_t offset)
{
	if (m_uiBufferOffset + offset >= m_uiFileSize)
		return 1;
	
	m_uiBufferOffset = offset;
	return 1;
}


void rmv2_file::changeTextureData(UINT uiLOD, UINT uiGroup, UINT uiTextureType, string strDirAndName, bool bCHangeeType, bool bChangeDirAndName)
{
	m_File.LodData[uiGroup][uiLOD]->PTextureData[0]->uiTextureType = uiTextureType;
	strcpy_s(m_File.LodData[uiGroup][uiLOD]->PTextureData[0]->pchTextureDirAndFileNam, strDirAndName.c_str());

}

//void rmv2_file::updateTextureDataInFileBuffer()
//{
//	DWORD dwOFfset = getOffet("TEXURE_DATA");
//	memcpy(&m_pFileBuffer[dwOFfset], &m_File.LodData[0][0]->PTextureData[0], sizeof(_RMV2_Texture_Data));
//
//	int i = 1;
//	return;
//}

void rmv2_file::setOffset(string strID, DWORD dwOffset)
{
	m_maOffSets[strID] = dwOffset;

}

//DWORD rmv2_file::getOffet(string strID)
//{
//	map<string, DWORD>::iterator it = m_maOffSets.find(strID);
//
//	if (it == m_maOffSets.end())
//		return this->m_uiFileSize + 1;
//
//	return it->second;
//}




void rmv2_file::copyStringsToBuffer()
{
}



	