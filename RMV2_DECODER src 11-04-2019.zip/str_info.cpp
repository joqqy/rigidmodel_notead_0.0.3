//nclude "pch.h"
#include "str_info.h"
#include <Windows.h>

str_info::str_info()
{
}



//
//
//str_info::str_info(dword dwMaxLen)
//{
//	m_dwMaxLength = dwMaxLen;
//}
//
//
//
//str_info::str_info(dword dwMaxLen, bool bZeroPadding)
//{
//	m_dwMaxLength = dwMaxLen;
//	m_bZeroPadding = bZeroPadding;
//}

str_info::str_info(sz pszConent, dword dwMaxLen, bool bZeroPadding)
{
	m_szOriginal = pszConent;	

	//m_szContent[0] = 'T';
	//m_szContent[1] = '1';

	m_dwMaxLength = dwMaxLen;
	m_bZeroPadding = bZeroPadding;

}

//str_info::str_info(csz cszContent, bool bZeroPadding)
//{
//	setString(cszContent, bZeroPadding);
//}

dword str_info::getLength() const
{
	return m_dwMaxLength;
}

dword str_info::getOffset() const
{
	return m_dwOffsset;
}

sz str_info::getStrContent() const
{
	return m_szContent;
}

str_info::operator dword()
{
	return m_dwOffsset;
}



str_info::operator int()
{
	return m_dwOffsset;
}

string & str_info::pathToCString(const string)
{
	char ch = 47;
	
	return sm_strTemp;
	// TODO: insert return statement here
}

string & str_info::getFileFromString(const string str)
{
	sm_strTemp = "";
	uint len = str.size() ;
	uint offset;
	for (offset = len-1; offset > 0; offset--)
	{
	
		if (str[offset] == '/')
			break;

		
	}
	
	offset++;
	sz szTemp = new char[len - offset+1];
	szTemp[len - offset] = '\0';

	str._Copy_s(szTemp, str.size(), (len - offset), offset);

	sm_strTemp = szTemp;

	delete[] szTemp;

	return sm_strTemp;
}

string & str_info::getDirFromString(const string _strText)
{
	sm_strTemp = "";
	uint len = _strText.size();
	uint offset;
	for (offset = len - 1; offset > 0; offset--)
	{

		if (_strText[offset] == '/')
			break;
	}

	
	// "+ 2" make room for the last "/"
	sz szTemp = new char[offset+2];
	szTemp[offset+1] = '\0';

	// "offset+1" to copy the last "/"
	memcpy(szTemp, &_strText.c_str()[0], offset+1);

	sm_strTemp = szTemp;

	delete[] szTemp;

	return sm_strTemp;
}

string & str_info::getPathFromDirAndFile(const string strDir, const string strFile)
{
	sm_strTemp = strDir;
	sm_strTemp += strFile;

	return sm_strTemp;	
	
}

str_info::operator csz()
{
	if (m_szContent == NULL)
		return m_szOriginal;

	return m_szContent;
}

dword & str_info::operator=(dword index)
{
	m_dwOffsset = index;

	return index;
	
}

const string& str_info::operator=(const string & strContent)
{
	setString(strContent.c_str(), m_bZeroPadding);
		
	return strContent;	
}

void str_info::fillZeros()
{
	if (m_szContent)
		delete[] m_szContent;
	
	ZeroMemory(m_szOriginal, m_dwMaxLength);

}




void str_info::setString(csz cszContent, bool bZeroPadded)
{
	if (m_dwMaxLength == 0)
		return;

	m_bZeroPadding = bZeroPadded;

	if (m_szContent)
		delete m_szContent;

	m_szContent = new char[m_dwMaxLength];


	if (m_bZeroPadding)						// Is the buffer supposed to be padded with seros?
	{
		memset(m_szContent, '\0', m_dwMaxLength);		// set entire bugger to NULL terminating character
			
		if (strlen(cszContent) >= m_dwMaxLength)			// If input string is long than max, leave the last chars
			memcpy(m_szContent, cszContent, m_dwMaxLength - 1);
		else    // TODO: Maybe the len should be 1 less (-1)
			memcpy(m_szContent, cszContent, strlen(cszContent));   // If not, copy them all
	}
	else // not zero padding
	{
		memcpy(m_szContent, cszContent, m_dwMaxLength);			// copy input string up to max_length
	}

}

void str_info::setString(string strContent)
{
 	setString(strContent.c_str(), m_bZeroPadding);
}

void str_info::setOffset(dword dwOffset)
{
	m_dwOffsset = dwOffset;
}

void str_info::setMaxLength(dword dwMaxLength)
{
	m_dwMaxLength = dwMaxLength;
}

void str_info::setZeroPadding(bool bZeroPadded)
{
	m_bZeroPadding = bZeroPadded;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//									Statics
////////////////////////////////////////////////////////////////////////////////////////////////////////////

string str_info::sm_strTemp;