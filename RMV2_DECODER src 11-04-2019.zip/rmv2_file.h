#pragma once
/////////////
// LINKING //
/////////////
//#pragma comment(lib, "dxgi.lib")
//#pragma comment(lib, "d3d11.lib")
//#pragma comment(lib, "d3dx11.lib")
//#pragma comment(lib, "d3dx10.lib")
//
//
////////////////
//// INCLUDES //
////////////////
////#include <dxgi.h>
////#include <d3dcommon.h>


// rmv2_tnc_c.cpp : this file contains the 'main' function. program execution begins and ends there.
//



#include "pch.h"
//#include <conio.h>
#include <ctype.h>

#include <iostream>

#include <iostream>
#include <fstream>
#include <string>

//#include "half.h"

#include "structs.h"
#include "definitions.h"
#include <window.h>

using namespace std;
//using half_float::half;

const char file_name[] = "s4h_spatha_pb_149_sword_01_old.rigid_model_v2";


// the signature in the beginning of a RMV2 file, the a byte chars spell out "RMV2"
class rmv2_file
	{
public:
	vector<_RMV2_Vertex_Raw> m_vecVerticesRaw;
	vector<_RMV2_Vertex_Converted> m_vecVerticesConverted;

	rmv2_file()
	{

	}

	size_t _getFileSize(const char* pchFileName);
	static enum class seek_direction : int { seek_forward = 1, seek_backward = -1 };

	static constexpr int SEEK_FORWARD = 1;
	static constexpr int SEEK_BACKWARD = -1;

	
      	

	bool readVertices();
	//bool readIndicies();


	// Lod data hedaer
	void setGroupName(u32 lod, u32 group, const string strContent);
	void setShadername(u32 lod, u32 group, const string strContent);	//TODO: make this work
	void setTextureDirectory(u32 lod, u32 group, const string strContent); //TODO: make this work
	
	void setAllTextureDirectories(const string strContent); //TODO: make this work
	
	// lod data
	void setTextureDirAndNamne(u32 lod, u32 group, u32 texture, const string strContent);
	
	

	// eet all


	void setAllTextureDirsAndNames(const string strContent);


	void setallTexturesByNumber(u32 texture, const string strName);


	// Lod data
	void setBoneName(u32 lod, u32 group, u32 bone_mnumber, const string strContent); //TODO: make this work
	

	void setTextureName(u32 lod, u32 group, u32 texture_mnumber, const string strConten, int dwType = -1);	//TODO: make this work
	void setTextureType(u32 lod, u32 group, u32 texture_mnumber, int tyoe);	//TODO: make this work

	//bool readVerticesAndIndices();

	bool readFile(string strFileName);
	bool writeFileAs(string strFileName);
	
	
	bool writeFile();


	bool readFileHeader(string strFileName = "");

	bool readLodHeaders(string strFileName = "");
	bool readLodData(string strFileName = "");
	bool readSupplementaryBones(string strFileName = "");
	
	bool readTextureData(u32 lod, u32 group, u32 texture);
	
	bool readTextureInfo(string strFileName = "");


	bool readEntireFileIntoBuffer(string strFIleName); // read a file into the buffer	
	bool writeEntireFileFromBuffer(string strFIleName); // save buffer content to a file


	bool readLodDataHeaderItems(dword lod, dword group);;
	bool readTextureData(dword lod, dword group);;
	bool readBoneData(dword lod, dword group);;


	bool readBuffer(void *pDest, size_t length);
	
	bool saveToBuffer(const str_info* PStrInfo);

	// Moves the buffer pointer n bytes in the selected direction	
	bool seekBuffer(size_t offset, seek_direction direction);
	
	// sets the pointer to an absolute offset
	bool seekBuffer(size_t offset);

	
	// storestring("DIR", "DIFFUSE", 0, 0, "\_rigimodels\man\weapons\tex\")

	void changeTextureData(UINT uiLOD, UINT uiGroup, UINT uiTextureType, string strDirAndName, bool bCHangeeType = false, bool bChangeDirAndName = true);
	void updateTextureDataInFileBuffer(); // fills the new data into the file buffer

	void setOffset(string strID, DWORD dwOffset);

	//DWORD getOffet(string);
	//void storeLodStringData(size_t lod, size_t group, const Lod_String_Data)
	//{

	//}
	
	
protected:
	map<string, DWORD> m_maOffSets;

	//map<uint32, map<uint32, Lod_Info>> m_mapLodInfo;

	// copy all the (maybe) edited strings from the parsing of the file to the "snapshot" of the file (the buffer)
	void copyStringsToBuffer();

	bool m_bSucces;
	bool m_bHasAddedChangeLabel;
	string m_strLastEvent;
	string m_strLogText;
	
public:
	string		m_strFileName2 = "234";
	int m_error_code;
	 _RMV2_File   m_File;
	bool bFIleLoaded = false;
	
	ifstream	m_ifsFile;
	//char m_pchSignature[5];
	std::ifstream m_ofsFile;

	char* m_pFileBuffer = NULL;
	

	uint32 m_uiFileSize = 0;
	uint32 m_uiBufferOffset = 0;
	
};