#pragma once

#include "def.h"

//extern void asm_copy_memory(void* pDest, const void* pSource, dword dwSizeofElement, dword dwNumberofElement);
//aextern "C" void asm_mem_copy(void * pDest, const void * pSource, dword dwCount);

class fast_string final
{
public:
	fast_string();
	~fast_string();

	
	void asm_copy_memory(void* pDest, const void* pSource, dword dwSizeofElement, dword dwNumberofElement);

protected:

	char* m_pchBuffer;
	dword m_dwBufferLength;
};

