// #include "stdafx.h"
#include "event_handler.h"
//#include "variadic.h"
//var::var()
//{
//	
//}
//
//var::var(int _int)
//{
//	data._int = _int;
//	type = "int";
//}
//
//var::var(uint _input)
//{
//	type = "uint";
//	data._uint = _input;
//}
//
//var::var(char _input)
//{
//	type = "char";
//	data._char = _input;
//}
//
//var::var(float _input)
//{
//	type = "float";
//	data._float = _input;
//}
//
//var::var(const char * _input)
//{
//	type = "csz";
//	data._csz = _input;
//}
//
//int& var::operator=(const int& other)
//{
//	type = "int";
//	data._int = other;
//	return data._int;
//}
