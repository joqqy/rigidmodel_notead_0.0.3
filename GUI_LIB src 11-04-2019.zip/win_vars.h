#pragma once
#include "window.h"

class str_var
{

public:
	str_var() {};
	str_var(window * _poThis) { m_poThis = _poThis; };

	operator sz() { return m_poThis->getText(); };
	operator string() { return m_poThis->getText(); }

	string & operator=(string _str) {
		//m_poThis->setText(_str);  return m_poThis->m_strText;
		
		return str;
	}
	string str = "";
	sz & operator=(sz _sz) { m_poThis->setText(_sz);  return m_poThis->m_szText; }

protected:
	string m_strTemp;
	window* m_poThis;

} Text = str_var(this);


class int_var_width {
public:
	int_var_width() {}
	int_var_width(window* _poWindf) : m_poParent{ _poWindf } {}

	operator int() {
		return m_poParent->getWidth();
	}
protected:
	window* m_poParent;
} Width2 = int_var_width(this);

class int_var_height {
public:
	int_var_height() {}
	int_var_height(window* _poWindf) : m_poParent{ _poWindf } {}

	operator int() {
		
		return m_poParent->getHeight();
	}
protected:
	window* m_poParent;
} Height1 = int_var_height(this);

class int_var_x {
public:
	int_var_x() {}
	int_var_x(window* _poWindf) : m_poParent{ _poWindf } {}

	operator int() {
		return m_poParent->getX();
	}
protected:
	window* m_poParent;
} X1 = int_var_x(this);

class int_var_y {
public:
	int_var_y() {}
	int_var_y(window* _poWindf) : m_poParent{ _poWindf } {}

	operator int() {
		return m_poParent->getY();
	}
protected:
	window* m_poParent;
} Y1 = int_var_y(this);