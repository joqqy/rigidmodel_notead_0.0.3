// #include "stdafx.h"
#include "text.h"
#include "combo_box.h"

combo_box::combo_box()
{
}


bool combo_box::create(window * pParentWindow, LPCSTR szContent, DWORD dwExstyle, DWORD dwStyle, LPVOID pParam, int x, int y, int width, int height, bool bFollowParent)
{
	return (0 != _createEx(pParentWindow, WC_COMBOBOXEX, szContent, dwExstyle, dwStyle, NULL, x, y, width, height));
}

combo_box::~combo_box()
{
}




bool combo_box::create(window* PParent, string strName, int x, int y, int width, int height, uint uiExStyle, uint uiStyle)
{
	u32 uFlags = CBS_HASSTRINGS | WS_CHILD | WS_VISIBLE | 
					uiStyle;

	return _createEx(PParent, WC_COMBOBOX, strName.c_str() , uiExStyle, uFlags, NULL, x, y, width, height);
}
bool combo_box::addElement(csz szText, LPARAM lParam, int image)
{
	COMBOBOXEXITEM item;
	
	
	
	if (image > -1)
		item.mask = CBEIF_IMAGE | CBEIF_SELECTEDIMAGE | CBEIF_TEXT | CBEIF_LPARAM; 
	else
		item.mask = CBEIF_TEXT | CBEIF_LPARAM;


	// create text buffer and copy string
	item.pszText = new char[strlen(szText)+1];
	strcpy_s(item.pszText, strlen(szText)+1, szText);
		
	item.lParam = lParam;
	item.iItem = -1;
	item.iImage = image;
	item.iSelectedImage = image;

	LRESULT lr = sendMessage(CBEM_INSERTITEM, 0, (LPARAM)&item);

	
	return true;
}

image_list & combo_box::operator=(const image_list _list)
{	
	setImageList(_list);
	return m_CurrentImageList;	
}

LRESULT combo_box::setImageList(image_list  _ImageLIst)
{
	m_CurrentImageList = _ImageLIst;
	HIMAGELIST tempImageList = _ImageLIst.getHandle();
	return sendMessage(CBEM_SETIMAGELIST, 0, reinterpret_cast<LPARAM>(tempImageList));
}



bool combo_box::selectByIndex(u32 index)
{
			
	LRESULT lr = sendMessage(CB_SETCURSEL, index, 0);

	if (lr == CB_ERR)
		return false;
	
	return true;
}

void combo_box::selectByParam(const LPARAM _lParam)
{
	int index = findByLPARAM(_lParam);
	
	selectByIndex(index);	
}

int combo_box::findByLPARAM(const LPARAM _lParam)
{
	COMBOBOXEXITEM * p;
	m_cbeiTemp.mask = CBEIF_LPARAM;
	for (uint i = 0; i < size(); i++)
	{
		m_cbeiTemp.iItem = i;
		sendMessage(CBEM_GETITEM, 0, reinterpret_cast<LPARAM>(&m_cbeiTemp));

		if (m_cbeiTemp.lParam == _lParam)
		return m_cbeiTemp.iItem;
	}
	
	return CB_ERR;
}

COMBOBOXEXITEM * combo_box::get(uint _index)
{
	m_cbeiTemp.mask = CBEIF_LPARAM;
	m_cbeiTemp.iItem = _index;
	
	sendMessage(CBEM_GETITEM, 0, reinterpret_cast<LPARAM>(&m_cbeiTemp));
		
	return &m_cbeiTemp;
}

LRESULT combo_box::getCurrectSelectionIndex()
{
	return sendMessage(CB_GETCURSEL, 0, 0);
}

size_t combo_box::size()
{
	return sendMessage(CB_GETCOUNT, 0, 0);
}

COMBOBOXEXITEM & combo_box::getSelectedItem(int _index)
{
	ZeroMemory(&m_cbeiTemp, sizeof(COMBOBOXEXITEM));		
	m_cbeiTemp.mask = CBEIF_LPARAM | CBEIF_TEXT;
	m_cbeiTemp.iItem = getCurrectSelectionIndex();
	if (m_cbeiTemp.iItem == CB_ERR) 
	{ 
		m_cbeiTemp.pszText = text::makeCopyOfSZ(sm_cszError);
		return m_cbeiTemp;
	}


	m_cbeiTemp.pszText = new char [256];
	m_cbeiTemp.cchTextMax = 254;
	LRESULT lr = sendMessage(CBEM_GETITEM, 0, reinterpret_cast<LPARAM>(&m_cbeiTemp));
	if ( (0 != lr))
		return m_cbeiTemp;
	else {
		m_cbeiTemp.pszText = text::makeCopyOfSZ(sm_cszError);


		return m_cbeiTemp;
	}
}

combo_box* combo_box::sm_poCb;