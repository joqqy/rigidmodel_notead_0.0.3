#pragma once


#include "base.h"
#include "Process.h"
#include "properties.h"
#include "text.h"

class menu;

struct _item
{
	string str;
	uint flags;
};


class menu_item
{
public:

	friend class menu;


	menu_item();
	menu_item(UINT id);


	// Use this for the expriment where ID nummmber or menus are not used by the user
	/*menu_item(string strText, UINT uiFlags = 0);

	menu_item(string strText, UINT fTYpe, UINT uiFlags);

	template <class C>
	menu_item(string strText, UINT fTYpe, UINT uiFlags, C* _po, typename tpmf<C>::MsgFunc _pmfHandlerFunc)
	{
	}
*/


	/*operator const menu_item*()
	{
		return this;
	}*/

	//menu_item & operator=(const _item);

	UINT getId();
	operator UINT()
	{
		return m_Id;
	}

	template<class C>
	menu_item * operator() (string strText, C * _po, typename tpmf<C>::MsgFunc _pmfHandlerFunc, UINT _uiId = 0)
	{
		
		m_oMenuItemInfo.fMask = MIIM_STRING | MIIM_ID;
		m_oMenuItemInfo.fType = MFT_STRING;
		if (_uiId)
			m_oMenuItemInfo.wID = _uiId;
		else
			m_oMenuItemInfo.wID = getId();


		cond_del_arrary(m_oMenuItemInfo.dwTypeData);
		m_oMenuItemInfo.dwTypeData = text::makeCopyOfSZ(strText.c_str());
				   	
		

		if (_po && _pmfHandlerFunc)
			window::t_bindHandlerToMenuEvent(m_oMenuItemInfo.wID, _po, _pmfHandlerFunc);

		return this;
	}

	// set the new menu item 
	menu_item * set(string strText, UINT _type = 0, UINT _flags = 0, HBITMAP _hBitmap = NULL);

	void setText(string strText, bool bUpdate = false)
	{
		// Set the mask
		m_oMenuItemInfo.fMask |= MIIM_STRING;

		m_oMenuItemInfo.dwTypeData = text::makeCopyOfSZ(strText.c_str());
		

	}

	bool isChecked()
	{
		return (m_oMenuItemInfo.fState & MFS_CHECKED) != 0;		
	}

	bool setChecked(bool bState)
	{
		bool bOld = ((m_oMenuItemInfo.fState & MFS_CHECKED) != 0);
		
		if (bState)			
			m_oMenuItemInfo.fState |= MFS_CHECKED;			
		else
			m_oMenuItemInfo.fState &= ~MFS_CHECKED;

		update(MIIM_STATE);

		return bOld;

	}

	bool enable(bool bState)
	{
		bool bOld = ((m_oMenuItemInfo.fState & MFS_CHECKED) != 0);
		
		
		if (bState)
			m_oMenuItemInfo.fState &= ~MFS_DISABLED;
		else
			m_oMenuItemInfo.fState |= MFS_DISABLED;

		update(MIIM_STATE);

		return bOld;

	}


	bool update(UINT _mask);

	HMENU m_hParentMenu = NULL;
	//sz m_szItemText;
	//UINT m_uiItemFlags;
	menu* m_poParentMenu;
	MENUITEMINFO m_oMenuItemInfo;
	menu_item* m_poTempItem;

	//static map<UINT, menu_item*> sm_mapIDToMenuItem;
private:
	static uint getNextId();

	UINT m_Id;
	static	uint sm_uiNextId;

};


//template<class C>
//inline menu_item * menu_item::operator()(csz cszext, UINT type, UINT flags)
//{
//	m_ItemInfo.fMask = MIIM_STRING | MIIM_STATE | MIIM_ID;
//	if (uiFlags == 0)
//		m_ItemInfo.fState = MFS_ENABLED;
//	else
//		m_ItemInfo.fState = uiFlags;
//
//	if (m_ItemInfo.dwTypeData)
//		delete[] m_ItemInfo.dwTypeData;
//
//	m_ItemInfo.cch = strlen(strText) + 1;
//
//	m_ItemInfo.dwTypeData = new char[m_ItemInfo.cch];
//	strcpy_s(m_ItemInfo.dwTypeData, m_ItemInfo.cch, strText.data());
//
//	return *this;
//}