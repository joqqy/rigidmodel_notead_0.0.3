#pragma once

#include "Definitions.h"
#include "base.h"



template <class C>
class WM
{
public:
	typedef LRESULT(C::*_WM_CHAR)(DWORD dw);
};

class window_message_handler_base
{
public:
	virtual LRESULT invoke(window_message* _poWindowMessage, LPARAM lParam, WPARAM  wParam) = 0;

};

class test
{
};


template <class C, class PMF>
class window_message_handler : public window_mesage_handler_base
{
public:
	 
	virtual LRESULT invoke(window_message* _poWindowMessage override
	{
		
	}

	C* m_poHandlerObject;
	PMF* m_poHandlerFunction; 

};


class WM_char_handler : public window_message_handler < test, WM<test>::_WM_CHAR >
{

};
