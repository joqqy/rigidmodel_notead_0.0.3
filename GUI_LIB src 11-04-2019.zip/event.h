#pragma once

#include "base.h"
//#include "var.h"

namespace window_event_info
{
	struct base	{
		base() {

		}

		base(HWND _hwnd, UINT _msg, WPARAM _wParam, LPARAM _lParam)
		{
			hwnd = _hwnd;
			message = _msg;
			wParam = _wParam;
			lParam = _lParam;
		};

		void fillData(HWND _hwnd, UINT _msg, WPARAM _wParam, LPARAM _lParam)
		{
			hwnd = _hwnd;
			message = _msg;
			wParam = _wParam;
			lParam = _lParam;
		}
		
		HWND hwnd;
		UINT message;
		WPARAM wParam;
		LPARAM lParam;

	};	

	struct test123 : base
	{
		
		
	};

}

struct  window_generic_event_handle_base
{

	

	virtual lr invoke(
		HWND hwnd,
		UINT message,
		WPARAM wParam,
		LPARAM lPARAM
	) = 0;

	virtual lr fillData(
		HWND hwnd,
		UINT message,
		WPARAM wParam,
		LPARAM lPARAM
	) = 0;
};

template <class C, class P>
struct window_event_handle : window_generic_event_handle_base
{
	virtual ~window_event_handle() {
		delete m_param;
	}



	typedef int  (C::*__pmf) (P*);



	P* m_param = new P;
	P* m_param_raise;

	C* m_po;
	__pmf m_pmf;



	virtual lr  fillData(
		HWND hwnd,
		UINT message,
		WPARAM wParam,
		LPARAM lPARAM)
	{

		return 1;
		
	}

	virtual lr invoke(
		HWND _hwnd,
		UINT _message,
		WPARAM _wParam,
		LPARAM _lParam)	
	{
		window_event_info::base *p = new window_event_info::base;
		p->hwnd = _hwnd;
		p->message = _message;
		p->wParam = _wParam;
		p->lParam = _lParam;		

		return (*m_po.*m_pmf)(p);
	}


	/*virtual lr invoke(var* pvar)
	{
		return (*m_po.*m_pmf)(pvar);
	}*/
};

struct window_event_manager
{


	window_generic_event_handle_base* m_phandler;
	
	template <class P, class C>
	void assign(C* _po, int(C::*_pmf)(P*))
	{
		window_event_handle<C,P>* p = new window_event_handle<C, P>;
			//		p->assign<P>((_po, _pmf);
		
		p->m_po = _po;
		p->m_pmf = _pmf;

					//m_po = _po;
					//m_pmf = _pmf;

		m_phandler = p;
	}

	

	virtual lr invoke(
		HWND _hwnd,
		UINT _message,
		WPARAM _wParam,
		LPARAM _lParam)
	{
		window_event_info::base *p = new window_event_info::base;
		p->hwnd = _hwnd;
		p->message = _message;
		p->wParam = _wParam;
		p->lParam = _lParam;
				
		return m_phandler->invoke(_hwnd, _message, _wParam, _lParam);
	}



	
	


	
};


struct invoke_base
{
};

template <class C, class R, class _T1>
struct invoke_1 : public invoke_base
{	
	typedef R (C::*pmf) (_T1);
	pmf m_pmf; C m_po;
	
	void assign(C* po, pmf _pmf)
	{
		m_pmf = _pmf;
		m_po = po; 
	}

	/*R raise(var v1)
	{
		(C::*pmf_T1) (_T1);
	}*/
};


