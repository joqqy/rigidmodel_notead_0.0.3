//#include "pch.h"
// #include "stdafx.h"
#include "gdi_window.h"



gdi_window::gdi_window()
        {
}


gdi_window::~gdi_window()
{
}
