// #include "stdafx.h"
#include "dc.h"



dc::dc()
{
}


dc::~dc()
{
}

dc::operator HDC() const
{
	return m_hDeviceContext;
}

dc::operator HDC*()
{
	return &m_hDeviceContext;
}

dc::operator HDC&()
{
	return m_hDeviceContext;
}
