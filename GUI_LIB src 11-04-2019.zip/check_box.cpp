// #include "stdafx.h"
#include "check_box.h"



check_box::check_box()
{
	window_type = win_types::check_box;
;
}

check_box::check_box(window * pParentWindow, LPCSTR szCaption, DWORD dwExstyle, DWORD dwStyle, int x, int y, int width, int height, bool bFollowParent)
	: button(pParentWindow, szCaption, dwExstyle, dwStyle, x, y, width, height, bFollowParent)
{

}

bool check_box::create(window * pParentWindow, LPCSTR szCaption, DWORD dwExstyle, DWORD dwStyle, int x, int y, int width, int height, bool bFollowParent)
{
	if (width == -1)
	{

		HDC hdc = pParentWindow->hDC;
		SIZE size;
		GetTextExtentPoint32(hdc, szCaption, strlen(szCaption), &size);

	
		return (0 != _createEx(pParentWindow, WC_BUTTON, szCaption, dwExstyle, dwStyle, NULL, x, y, size.cx, size.cy));
	}



	
	DWORD dw = (dwStyle | WS_CHILD);
	bool b = (0 != _createEx(pParentWindow, WC_BUTTON, szCaption, dwExstyle, dw  , NULL, x, y, width, height));
	
	return b;
}


check_box::~check_box()
{
}

void check_box::onClick(check_box * _poCheckBox)
{
}




LRESULT check_box::processOwnNotification(u32 uiID)
{

	if (getStyles() & BS_CHECKBOX)
	{
		if (uiID == BN_CLICKED)
		{
			m_lrState = sendMessage(BM_GETCHECK, 0, 0);
			if (m_lrState == BST_UNCHECKED)
			{
				if (onCheck())
					m_lrState = sendMessage(BM_SETCHECK, BST_CHECKED, 0);
			}
			else
			{
				if (onUnCheck())
					m_lrState = sendMessage(BM_SETCHECK, BST_UNCHECKED, 0);
			}
			if (m_poGroupParent)
				m_poGroupParent->onClick(this);

			disableWindows();
			setReadOnlyWindows();
		}
	}
	else if (getStyles() & BS_3STATE)
	{
		if (uiID == BN_CLICKED)
		{
			if (m_lrState == BST_UNCHECKED)
			{
				if (onCheck())
					m_lrState = sendMessage(BM_SETCHECK, BST_CHECKED, 0);
			}
			else
			{
				if (onUnCheck())
					m_lrState = sendMessage(BM_SETCHECK, BST_UNCHECKED, 0);
			}
			if (m_poGroupParent)
				m_poGroupParent->onClick(this);

			disableWindows();		
			setReadOnlyWindows();
		}	
	}
	// signal to the group parrent (if any) that the check box has been clicked
	
	return m_lrState;
}

bool check_box::onCheck()
{
	return true;
}


bool check_box::onUnCheck()
{
	return true;
}

bool check_box::operator=(const bool b)
{
	if (b) 
		setState(BST_CHECKED);
	else  
		setState(BST_UNCHECKED);
	
	
	if (m_poGroupParent)
		m_poGroupParent->onClick(this);

	return b;
}

check_box::operator bool()
{
	return (getState() == BST_CHECKED);
}

LRESULT check_box::getState()
{
	m_lrState = sendMessage(BM_GETCHECK, 0, 0);
	return m_lrState;
}

LRESULT check_box::setState(LRESULT lrState)
{
	LRESULT lrOld = getState();
	sendMessage(BM_SETCHECK, lrState, 0);
	disableWindows();
	return lrOld;
}

bool check_box::setReadOnly(bool bState)
{
	bool b = sendMessage(EM_SETREADONLY, bState ? 1 : 0, 0);
	setReadOnlyWindows();
	return b;
}

bool check_box::isReadOnly()
{
	return (getLongPtr(GWL_STYLE) & ES_READONLY) == 0 ? false : true;
}

bool check_box::setEnableOnCheck(bool _bState)
{
	bool bOld = m_bEnableOnChecked;
	m_bEnableOnChecked = _bState;
	disableWindows();
	return bOld;
}

void check_box::addWinToDisableList(window * _poWin)
{
	m_vecDisableList.push_back(_poWin);

	if (m_bEnableOnChecked)
	{
		if (getState() == BST_CHECKED)
			_poWin->enable(false, false);
		else
			_poWin->enable(true, true);
	}
	else
	{
		if (getState() == BST_CHECKED)
			_poWin->enable(true, true);
		else
			_poWin->enable(false, false);
	}
}

void check_box::addWinToReadOnlyList(window * _poWin)
{

	m_vecReadOnlylList.push_back(_poWin);

	if (!m_bEnableOnChecked)
	{
		if (getState() == BST_CHECKED)
			_poWin->setReadOnly(false);
		else
			_poWin->setReadOnly(true);
	}
	else
	{
		if (getState() == BST_CHECKED)
			_poWin->setReadOnly(true);
		else
			_poWin->setReadOnly(true);;
	}
}

void check_box::disableWindows() {

	if (m_bEnableOnChecked)
	{
		if (getState() == BST_CHECKED)
		{
			for (uint i = 0; i < m_vecDisableList.size(); i++)
				m_vecDisableList[i]->enable(true, true);
		}
		else
		{
			for (uint i = 0; i < m_vecDisableList.size(); i++)
				m_vecDisableList[i]->enable(false,false);
		}
	} else // if NOT (m_bEnableOnChecked)
	{

		if (getState() == BST_CHECKED)
		{
 			for (uint i = 0; i < m_vecDisableList.size(); i++)
				m_vecDisableList[i]->enable(false, false);
		}
		else
		{
			for (uint i = 0; i < m_vecDisableList.size(); i++)
				m_vecDisableList[i]->enable(true, true);
		}
	}

}

void check_box::setReadOnlyWindows()
{
	if (m_bEnableOnChecked)
	{
		if (getState() == BST_CHECKED)
		{
			for (int i = 0; i < m_vecReadOnlylList.size(); i++)
				m_vecReadOnlylList[i]->setReadOnly(false);
		}
		else
		{
			for (int i = 0; i < m_vecReadOnlylList.size(); i++)
				m_vecReadOnlylList[i]->setReadOnly(true);
		}
	}
	else // if NOT (m_bEnableOnChecked)
	{

		if (getState() == BST_CHECKED)
		{
			for (int i = 0; i < m_vecReadOnlylList.size(); i++)
				m_vecReadOnlylList[i]->setReadOnly(true);
		}
		else
		{
			for (int i = 0; i < m_vecReadOnlylList.size(); i++)
				m_vecReadOnlylList[i]->setReadOnly(false);;
		}
	}
}



