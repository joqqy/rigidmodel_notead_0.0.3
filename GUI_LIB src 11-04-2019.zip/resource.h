﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by RMV2_GUI.rc
//
#define ID_ABOUT_UPDATE                 2
#define IDB_BITMAP1                     103
#define IDD_ABOUT                       104
#define IDD_DIALOG1                     106
#define IDI_FOLDER1                     109
#define IDB_GEAR1                       126
#define IDB_BITMAP2                     127
#define IDI_ICON1                       130
#define IDI_ICON2                       131
#define IDI_ICON3                       132
#define IDI_ICON4                       133
#define IDI_ICON5                       134
#define IDI_ICON6                       135
#define GLOBALACCEL                     136
#define IDR_ACCELERATOR1                137
#define IDC_ABOUT_CLOSE                 1019
#define IDC_EDIT_CREDITS                1021
#define IDC_EDIT_VERSION                1023
#define IDA_COPY                        10001
#define IDA_PASTE                       10002
#define IDA_EXIT                        10003

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        138
#define _APS_NEXT_COMMAND_VALUE         40002
#define _APS_NEXT_CONTROL_VALUE         1025
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
