// #include "stdafx.h"
#include "button.h"
//#include "button.h"
//
//
//
//button::button()
//{
//}
//
//
//button::~button()
//{
//}


button::button()
{
	window_type = win_types::button;
}

bool button::create(window * pParentWindow, LPCSTR szCaption, DWORD dwExstyle, DWORD dwStyle, int x, int y, int width, int height, bool bFollowParent)
{
	return (0 != _createEx(pParentWindow, WC_BUTTON, szCaption, dwExstyle, dwStyle, NULL, x, y, width, height));
	window_type = win_types::button;
}


button::~button()
{
}
