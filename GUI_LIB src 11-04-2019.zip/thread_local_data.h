#pragma once
#include "thread.h"

template <class T, T error>
class thread_local_data
{
public:
	thread_local_data();

	thread_local_data(const T data);

	operator T();
	T operator= (const T data);

	T getData();

protected:
	DWORD m_dwThreadId;
	T m_data;
	
	//map <DWORD, T*> m_mapIdToData;
};

template<class T, T error>
inline thread_local_data<T, error>::thread_local_data()
{
	m_dwThreadId = GetCurrentThreadId();	
}


template<class T, T error>
inline thread_local_data<T, error>::operator T()
{
	if (m_dwThreadId = GetCurrentThreadId())
		return m_data;

	return error;
}

template<class T, T error>
inline T thread_local_data<T, error>::operator=(const T _data)
{
	m_dwThreadId = GetCurrentThreadId();
	m_data = _data;
	return _data;
}


template<class T, T error>
inline thread_local_data<T, error>::thread_local_data(const T _data)
{
	//m_mapIdToData[thread::getCurrentId()]
	m_dwThreadId = GetCurrentThreadId();
	m_data = _data;
}


template<class T, T error>
inline T thread_local_data<T, error>::getData()
{
	if (m_dwThreadId = GetCurrentThreadId())
		return m_data;

	return error;
}
