#pragma once
// #include "stdafx.h"
#include "base.h"

#define window_message_handler(msg, ...) case_##msg(__VA_ARGS__)

#define DEF_WIN_PROC		DefWindowProc(m_oLastMessage.hwndSource, m_oLastMessage.uiMessage, m_oLastMessage.wParam, m_oLastMessage.lParam);

#define MESSAGE_HANDLER virtual LRESULT

#define DEFAULT_ACTION { return DEF_WIN_PROC; }

class window_base :
	public base
{
public:
	window_base();
	virtual ~window_base();













protected:
	window_message m_oLastMessage;
};

