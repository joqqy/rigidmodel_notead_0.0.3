#pragma once
#include "base.h"

 enum predefined_error_codes : int	
{
	ERROR_CODE_NOT_SET = 1,
	UNDEFINED_ERROR = 2,
	SUCCESS = 3,
	FILE_NOT_FOUND = 4,
	FILE_SIZE_ZERO = 5,
	ERROR_READING_FILE = 6

	
};

class safe_enum_item
{
public:
	friend class safe_enum;


	enum class type : int
	{
		INT_TO_STRING = 0,
		STRING_TO_INT = 1,
		STRING_TO_STRING = 2
	};

	

	safe_enum_item();
	safe_enum_item(int _key, string _falue, uint const_value = 0);
	safe_enum_item(string _key, int  value, uint const_value = 0);
	safe_enum_item(string _key, string _Value, uint const_value = 0);




	/*safe_enum_item(string _key, int _Value, uint _const = 0);
	safe_enum_item(string _key, string _Value, uint _const = 0);
	*/


	virtual ~safe_enum_item();
	// TODO:: delete list






protected:
	void addToList(safe_enum_item _poItem)
	{
		m_vecList.push_back(_poItem);
	}
public:


	enum values
	{

	};

	int m_key_int;
	int m_value_int;

	string m_key_string;
	string m_value_string;

	int	m_const = 0;

	string getValue(int _key)
	{
		return 0;
	}

	type m_type;

	//safe_enum* m_poParent;
protected:
	vector <safe_enum_item> m_vecList;
};


