#pragma once
#include "window.h"
class child_window :
	public window
{
public:
	
	//child_window(window* PThisWiind, window_template WT, int x_offset = 0, int y_offset = 0, uint uiExStyles = 0, uint uiStyles  = 0);

	virtual ~child_window();

	bool create(const string strCaption, csz cszWindowClass, dword dwStyle, dword dwExStyle = 0,  int x = CW_USEDEFAULT, int y = CW_USEDEFAULT, int width = CW_USEDEFAULT, int height = CW_USEDEFAULT);
	   


private:
	child_window();
};

