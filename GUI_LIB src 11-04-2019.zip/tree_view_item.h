#pragma once
#include "control_window.h"
#include <vector>
#include <CommCtrl.h>

class tree_view_item :
	public control_window
{
public:
	tree_view_item();

	virtual ~tree_view_item();
	
	operator HTREEITEM();
	operator sz();
	operator string();
	operator LPARAM();
	
	bool updateItem();

	HTREEITEM getHandle();
	
	void setMask(uint uiMask);
	void setHandle(HTREEITEM hHandle);
	void setLParam(LPARAM lParam);
	void setText(string strText);

	
	

protected:
	TVITEMEX m_Item;
	vector<tree_view_item> m_vecCHildren;
	control_window* m_ParentWIndow;

};

