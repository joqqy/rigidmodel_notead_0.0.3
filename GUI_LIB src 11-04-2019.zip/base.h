#pragma once
/**********************************************************************************************************
	[File:]
	base.h

	[Author]
	phazer

	[Created]
	15/11/2018 00:00
	
	[Edited]
	06/12/2018 18:16
	
	[Description:] Base class defintionion for the entire GUI lib. Provides the functions that are 
	common far all derived classes.
***********************************************************************************************************/


#include <DirectXMath.h>

using namespace DirectX;



// #include "stdafx.h"
#include <windows.h>
#include <map>
#include <vector>
#include <string>
#include <functional>
#include <typeinfo.h>

#include "Definitions.h"
#include "safe_enum.h"



#define InvokePMF(pobj, pfunc, ...) ((* ##pobj ).*##pfunc)(__VA_ARGS__)		


#define _case LRESULT
#define ARG window_message* spc( ) _WindowMessage
#define pwm window_message* spc( ) _pwm

typedef LRESULT handler_function;
typedef LRESULT sys_int;

class window;
using namespace std;

class base;

struct window_message
{
	window*		poSourceWindwow;	
	
	HWND		hwndSource;
	UINT		uiMessage;	
	WPARAM		wParam;
	LPARAM		lParam;
	
	int			type;

	UINT		uiNotifyCode;
	UINT		uiMenuItemId;
	
	word		wHIWORD;
	word		wLOWORD;

	
	static struct types
	{
		constexpr static UINT message_event = 1;
		constexpr static UINT ctrl_event = 2;
		constexpr static UINT menu_event = 3;
		constexpr static UINT sys_menu_event = 4;
	};
};



class pmf
{
public:
	typedef		LRESULT(base::*MenuItemHandlerFunc)(UINT uiID);
	typedef		LRESULT(base::*WMHandlerFunc)(window*, UINT, WPARAM, LPARAM);
	typedef		LRESULT(base::*ControlEventHandler)(window* _poWndCtrl, UINT uiEventId);
	typedef		DWORD(base::*ThreadHandlerFunc)();
};


template <class T>
class tpmf
{
public:
	typename typedef		LRESULT(T::*MenuItemHandlerFunc)(UINT uiID);
	typename typedef		LRESULT(T::*WMHandlerFunc)(window*, UINT, WPARAM, LPARAM);
	typename typedef		LRESULT(T::*ControlEventHandler)(window* _poWndCtrl, UINT uiEventId);
	typename typedef		DWORD(T::*ThreadHandlerFunc)();

	typename typedef		LRESULT(T::*MsgFunc)(window_message* poWmMessage);
};

template <class C, class ...Types>
struct var_pmnf
{
	typename typedef		LRESULT(C::*pmf)(Types...);
	
};
template <class T, class... ARGS>
class tpmf_t
{
public:
	typename typedef		LRESULT(T::*MenuItemHandlerFunc)(UINT uiID);
	typename typedef		LRESULT(T::*WMHandlerFunc)(window*, UINT, WPARAM, LPARAM);
	typename typedef		LRESULT(T::*ControlEventHandler)(window* _poWndCtrl, UINT uiEventId);
	typename typedef		DWORD(T::*ThreadHandlerFunc)();	

	typename typedef		int(T::*MsgFunc)(window_message* poWmMessage);
	
	typename typedef		LRESULT(T::*VarArgsFunc)(ARGS... args);

	
};







struct _handler_base
{
public:
	virtual LRESULT invoke(WPARAM wParam, LPARAM lParam) { return 0; };
	virtual LRESULT invoke(window* _poSoucceWindwo, UINT uiMsg, WPARAM wParam, LPARAM lParam) { return 0; };


	virtual LRESULT invoke_WM(window_message* poWmMessage) { 
		
		return 0; 
	
	
	};

	virtual LRESULT invoke_MenuEvent(window_message* poWmMessag) { 
		return 0; 
	};
	
	
	virtual LRESULT invoke_CtrlEVent(window_message* poWmMessage)  { 
		



		


		

		return 0; 
	};
	



	base *PObject;
};


template <class PMF>
struct _handler : public _handler_base
{
public:

	virtual LRESULT invoke(WPARAM wParam, LPARAM lParam)
	{
		return 0;
	}

	base *PObject;
	PMF pmf;


};

enum class event_type
{
	invalid,
	wm_event,
	menu_event,
	control_event,
	notify_event,
	sys_menu_event,
	hotkey_event,
	activate_event,
};


template <class C, class PMF>
struct t_handler : public _handler_base
{
public:

	LRESULT v(WPARAM, LPARAM)
	{

	}

//	tpmf_t<t_handler, WPARAM, LPARAM>::VarArgsFunc __pmf;

	virtual LRESULT invoke(WPARAM wParam, LPARAM lParam) override 
	{ 
		return 0; 
	};

	
	virtual LRESULT invoke_MenuEvent(window_message* poWmMessage)
	{

	/*		0033D4A9  mov         esi, esp
			0033D4AB  mov         eax, dword ptr[poWmMessage]
			0033D4AE  push        eax
			0033D4AF  mov         edx, dword ptr[this]
			0033D4B2  mov         eax, dword ptr[this]
			0033D4B5  mov         ecx, dword ptr[eax + 8]
			0033D4B8  mov         edx, dword ptr[edx + 0Ch]
			0033D4BB  call        edx*/
		


		return ((*poHandlerObject).*poMsgHandlerFunc)(poWmMessage);

		//return InvokePMF(poHandlerObject, poMsgHandlerFunc, poWmMessage);
		//return ((*poHandlerObject).poMenuHandlerFunc)();
		
			//(return 0; // InvokePMF(poHandlerObject, poHandlerFunc);

	}



	virtual LRESULT invoke_WM(window_message* poWmMessage) override
	{ 

		return InvokePMF(poHandlerObject, poMsgHandlerFunc, poWmMessage);
	};


	virtual LRESULT invoke_CtrlEVent(window_message* poWmMessage) override
	{
		

 	//(return InvokePMF(poHandlerObject, poHandlerFunc, poWmMessage);		

		return InvokePMF(poHandlerObject, poMsgHandlerFunc, poWmMessage);

		//return ((*poHandlerObject).*poHandlerFunc)(poWmMessage);
		
		//return InvokePMF(poHandlerObject, poHandlerFunc, NULL);
	}

	C* poHandlerObject;	
		
	//function<LRESULT(C*, window_message*)> m_pmf;
	
	typename tpmf<C>::MsgFunc poMsgHandlerFunc;
	typename tpmf<C>::MenuItemHandlerFunc poMenuHandlerFunc;
	
	
	window* poWindowSource;

};



struct _wm_handler : public _handler<pmf::WMHandlerFunc>
{
public:
	virtual LRESULT invoke(window* _poSoucceWindwo, UINT uiMsg, WPARAM wParam, LPARAM lParam) override
	{
		return InvokePMF(PObject, pmf, poWindow, uiMsg, lParam, wParam);
	}
	
	base *PObject;
	window* poWindow;
};




struct _control_event_handler : public _handler<pmf::ControlEventHandler>
{
public:
	virtual LRESULT invoke(WPARAM wParam, LPARAM lParam) override
	{
		return InvokePMF(PObject, pmf, reinterpret_cast<window*>(lParam), wParam);
		
	}

	base *PObject;

};

struct _menu_event_handler : public _handler<pmf::ControlEventHandler>
{
public:
	virtual LRESULT invoke(WPARAM wParam, LPARAM lParam) override
	{
		return 0; // InvokePMF(PObject, pmf);

	}

	base *PObject;

};

#define MENU_HANDLER(method)		static_cast<pmf::MenuItemHandlerFunc>( &##method )
#define THREAD_HANDLER(method)		static_cast<pmf::ThreadHandlerFunc>( &##method )
#define WM_HANDLER(method)			static_cast<pmf::WMHandlerFunc>( &##method )
#define CONTROL_HANDLER(method)		static_cast<pmf::ControlEventHandler>( &##method )




#define _handler(_oHandlerClass, _handlerMethod) spc( ) ( _oHandlerClass )._action((pmf::ControlEventHandler) &test_app::_Button_Clicked);

#define _const static constexpr

template <class C> 
class _handler_test
{
public:
	typedef int(C::*PMF)();
	
	PMF t;
	C* pc;


	void  assign_pmf( C* po, PMF _pmf )
	{
		pc = po;
		t = _pmf;
	}

};

template <typename T>
static void bar(T t) {


	return;
};

template <typename... Targs> 
static void test_args(Targs &&... Fargs)
{
	int dummy[] = { 0, ( (void) bar( std::forward<Targs>(Fargs) ), 0) ... };



	return;
}


template <class C>
t_handler<C, typename tpmf<C>::MsgFunc> * action(C* t, typename tpmf<C>::MsgFunc _pmf)
{
	t_handler<C, tpmf<C>::MsgFunc>* po = new t_handler<C, tpmf<C>::MsgFunc>;
	
	po->poHandlerObject = t;
	po->poMsgHandlerFunc = _pmf;	


	return po;

}

template <class C>
t_handler<C, typename tpmf<C>::MsgFunc> * bind(C* t, typename tpmf<C>::MsgFunc _pmf)
{
	t_handler<C, tpmf<C>::MsgFunc>* po = new t_handler<C, tpmf<C>::MsgFunc>;

	po->poHandlerObject = t;
	po->poMsgHandlerFunc = _pmf;


	return po;

}



template <class C>
_control_event_handler  action(C* c, typename tpmf<C>::ControlEventHandler pmfControlEvent)
{
	_control_event_handler ceh;

	ceh.PObject = c;
	ceh.pmf = (tpmf<base>::ControlEventHandler) pmfControlEvent;
	return ceh;

}


class base
{
public:
	base();

	virtual ~base();

	const char* getTypeName();

	// *****************************************************************************************
	// Method: G
	// true some other thread is currently accessing the data of the object
	// and no functions should be able to write any data until  the functions show "false"
	// *****************************************************************************************






	template <class T>
	_control_event_handler  &_action(pmf::ControlEventHandler pmfControlEvent)
	{

		m_oControlEventHandler.PObject = this;
		m_oControlEventHandler.pmf = pmfControlEvent;
		return m_oControlEventHandler;

	}

	_wm_handler &  _action(pmf::WMHandlerFunc _pmf)
	{
		m_oWMhandler.PObject = this;
		m_oWMhandler.pmf = _pmf;
		return 	m_oWMhandler;

	}


	LRESULT p1(window* _poWndCtrl, UINT uiEventId)
	{
		return 0;
	}

	template <class T>
	class PMF {
public:
		typedef LRESULT(T::*pmf)(window* _poWndCtrl, UINT uiEventId);
	};


	//PMF<base>::pmf p = &p1;
	

	//LRESULT(C::*_pmf)(window* _poWndCtrl, UINT uiEventId)
	
	struct t {
		
			template <class T> using V_1 = LRESULT(T::*)(window* _poWndCtrl, UINT uiEventId);
	};


	tpmf<base>::ControlEventHandler P_1 = &base::p1;

//	V<base> p = &p1;



	template <typename C>
	_control_event_handler &  _taction(t::V_1<C> _pmf)
	{
		
		
		m_oControlEventHandler.PObject = this;
		
		m_oControlEventHandler.pmf = (tpmf<base>::ControlEventHandler) _pmf;
		
		return 		m_oControlEventHandler;
	
	}

	


	_control_event_handler & operator()(pmf::ControlEventHandler pmfControlEvent)
	{

		
		m_oControlEventHandler.pmf = pmfControlEvent;

		return m_oControlEventHandler;

	}
	csz cszType;

protected:
	_control_event_handler m_oControlEventHandler;		
	_wm_handler m_oWMhandler;


private:
	int m_private_test;
};


