#pragma once
/**********************************************************************************************************
	[File:]
	base.h

	[Author]
	phazer

	[Created]
	15/11/2018 00:00

	[Edited]
	06/12/2018 18:16

	[Description:] Base class defintionion for the entire GUI lib. Provides the functions that are
	common far all derived classes.
***********************************************************************************************************/




#include <string>
#include <cstdint>
#include <iostream>

#include <windows.h>
#include <winbase.H>
#include <winddi.h>
#include <vector>
#include <map>
#include <string>


using namespace std;

//
//Sign bit : 1 bit
//Exponent width : 5 bits
//Significand precision : 11 bits(10 explicitly stored)

//using half_float:

// use to make spaces
#define spc(a) a
#define spc1(a) a
#define txt(param) spc1() ##param

// conditionaally delees a pointer if it is not NULL
#define cond_del(pVoid) if (##pVoid) delete spc(  ) ##pVoid

// Deletes an array if it is not = "nullptr"
#define cond_del_arrary(pVoid) if (##pVoid) delete spc(  ) [] spc(  ) ##pVoid

#define cond_del_al(pVoid, type, count) if (txt(pVoid)) delete spc(  ) txt(pVoid); ##pVoid = new spc( ) txt(type)[count];





// unsigned




typedef std::uint8_t	byte;
typedef std::uint8_t	u8;	

typedef std::uint16_t	word;
typedef std::uint16_t	u16;
typedef std::uint16_t	uint16;
typedef std::uint16_t	u16;
	
typedef std::uint32_t	uint32;
typedef std::uint32_t	uint; 
typedef std::uint32_t	dword;
typedef std::uint32_t	dw;
typedef std::uint32_t	u32;

typedef std::uint64_t	qword;
typedef std::uint64_t	ddword;
typedef std::uint64_t	u64;

typedef float			float32;
typedef double			float64;


// signed
typedef std::int8_t		signed_byte;

typedef signed char		ch;

typedef std::int8_t		i8;

typedef std::int16_t	int16;
typedef std::int16_t	i16;

typedef std::int32_t	int32;
typedef std::int32_t	i32;

typedef std::int64_t	int64;
typedef std::int64_t	i64; 

typedef	void*			pvoid;

typedef float			float32;
typedef double			float64;

typedef char*			pzstr;
typedef const char*		pczstr;

typedef char*			psz;
typedef const char*		pcsz;

typedef char*			sz;
typedef const char*		csz;

typedef const char*		czs;

typedef LRESULT lr;

//typedef DWORD		w_dword;
//typedef UINT		w_uint;
 
const uint a = 1;

#define ENDL "\r\n"

#define _and &
#define _or |

#define AND &&
#define OR ||


#define _xor ^
#define _shl <<
#define _shr >< 


extern "C" void asm_mem_copy(sz, csz, dword);

extern "C" size_t asm_strlen(const char*);

extern "C" sz asm_add_to_buffer();

extern "C" void asm_set_malloc(void* p);

extern void _CopySZ(sz, csz);
extern std::string _IntoStr(long l);

template <class T>
T bits(const char* pchBits) {

	size_t bit_length = sizeof(T) * 8;
	size_t length_of_string = strlen(pchBits);
	unsigned long bit_index = 0;


	unsigned long temp = 0;

	size_t char_index = length_of_string + 1;


	if (bit_length < length_of_string)
		char_index = bit_length + 1;
	else
		char_index = length_of_string - 1;



	for (int i = 0; i < length_of_string; i++)
	{
		if (pchBits[length_of_string - 1 - i] == '1')
		{
			long t = (1 << bit_index);
			temp += t;
			bit_index++;
		}
		else
			if (pchBits[length_of_string - 1 - i] == '0')
			{
				bit_index++;
			}
	}




	//int count = 0;

	//while (char_index > 0)
	//{
	//	count++;
	//	if (pchBits[char_index] == '1')
	//	{
	//		long t = (1 << bit_index);
	//		temp += t;
	//		bit_index++;
	//	}
	//	else
	//	if (pchBits[char_index] == '0')
	//	{
	//			bit_index++;
	//	}
	//	
	//	char_index--;
	//	
	//}
	return (T)temp;
};

//
//extern dword fastcpy(void * dest, const void* src, dword count);
//
//extern float convert16BitFloatTo32Bits(word wInput);
//extern float HalfToSingle(word wInput);
//



