#pragma once
#include "gui_lib.h"


class texture_edit_group :
	public control_group
{
public:
	texture_edit_group();
	virtual ~texture_edit_group();


	check_box cbFolderLock = check_box(this, "", 0, WS_CHILD | BS_CHECKBOX, 0, 10, 15, 15);

	edit_box ebFolder = edit_box(this, "....", WS_EX_CLIENTEDGE, WS_CHILD | ES_RIGHT, NULL, 15, 10, 300, 22);
	edit_box ebFile = edit_box(this, "...", WS_EX_CLIENTEDGE, WS_CHILD, NULL, 325, 10, 300, 22);

	combo_box_decl(comboTextureType, this, "Texture Type", 0, 0, 650, 10, 100, 200);
	image_list m_image_list;
};

