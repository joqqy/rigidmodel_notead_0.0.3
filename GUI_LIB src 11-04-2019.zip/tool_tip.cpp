// #include "stdafx.h"
#include "tool_tip.h"



tool_tip::tool_tip()
{
}


tool_tip::~tool_tip()
{
}

bool tool_tip::create(window * _poParent, int style)
{
	if (_createEx(_poParent, TOOLTIPS_CLASS, "", 0, WS_POPUP | TTS_NOPREFIX | TTS_ALWAYSTIP | style, NULL) == 0)
		return false;

	SetWindowPos(m_hHandle, HWND_TOPMOST, 0, 0, 0, 0,
		SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
	
	return true;
}

void tool_tip::addTool(window * _poParent, window * _poTool, csz _cszText)
{

	TOOLINFO ti = { 0 };
	ti.cbSize = sizeof(TOOLINFO);
	ti.uFlags = TTF_SUBCLASS;
	ti.hwnd = *_poParent;
	//ti.uId = (UINT_PTR)_poTool->operator HWND();
	ti.hinst = H_INST;
	ti.lpszText = 	new char[strlen(_cszText) + 1];
	strcpy_s(ti.lpszText, strlen(_cszText) + 1, _cszText);
		
	GetClientRect(*_poParent, &ti.rect);

	// Associate the tooltip with the "tool" window.
	sendMessage(TTM_ADDTOOL, 0, (LPARAM)(LPTOOLINFO)&ti);

}
