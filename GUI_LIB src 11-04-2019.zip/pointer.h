#pragma once

#include "Definitions.h"

template <class T>
class memory
{
public:
	memory(size_t size)
	{
		m_size = size;
		m_pBuffer = new T[m_size];
	}

	T* getPtr()
	{
		return m_pBuffer;
	}

	size_t getSize()
	{
		return m_size;
	}


protected:
	u32 m_size;
	T* m_pBuffer;
};


template <class T>
class pointer
{
public:
	pointer(memory<T> _buffer)
	{
		m_pPointer = _buffer.getPtr();
		m_size = _buffer.getSize();
	}

	

protected:
	T*		m_pPointer = NULL;
	u32		m_size = 0;

};


