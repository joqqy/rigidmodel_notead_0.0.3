// #include "stdafx.h"
#include "dialog_box.h"
//#include <resource.h>


#define DIALOG_INDEX 1

dialog_box::dialog_box()
{
}


dialog_box::~dialog_box()
{
}

void dialog_box::create(window* _poParent, LPCTSTR _id)
{
	sm_pTempThis = this;
	sm_PTempThisList[DIALOG_INDEX] = this;


	DialogBox(H_INST, _id, *_poParent, DialogWindowProces);

}
void dialog_box::create(window * _poParent, int _id)
{
	sm_pTempThis = this;
	
	
	sm_PTempThisList[DIALOG_INDEX] = this;
	DialogBox(H_INST, MAKEINTRESOURCE(_id), *_poParent, DialogWindowProces);

}

BOOL dialog_box::DialogWindowProces(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	
	dialog_box* temp = reinterpret_cast<dialog_box*>( getThisFromWindowMemory(hDlg) );

	if (temp == nullptr)
	{
	

		//map<DWORD, window*>::iterator it = sm_PTempThisList.find(DIALOG_INDEX);
		
		temp = reinterpret_cast<dialog_box*>(sm_PTempThisList[DIALOG_INDEX]);
		putThisIntoWindowMemory(hDlg, temp);



		sm_mapHandleToWindowPtr[hDlg] = temp;


		return temp->ClassDialogProcedure(hDlg, message, wParam, lParam);
	}
	else
	{
		return temp->ClassDialogProcedure(hDlg, message, wParam, lParam);

	}


	//switch (message)
	//{
	//case WM_INITDIALOG:
	//	return TRUE;

	//case WM_COMMAND:
	//	switch (LOWORD(wParam))
	//	{
	//	case ID_ABOUT_CLOSE:
	//	
	//		EndDialog(hDlg, 0);
	//		return TRUE;
	//	}
	//	break;
	//}
	return FALSE; 
}

bool dialog_box::ClassDialogProcedure(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	if (m_hHandle == NULL)
	{
		
		
		m_hHandle = hDlg;
	}
	
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:	
	{
		onDialogInit();
		return (INT_PTR)TRUE;
	}
	case WM_CLOSE:
		break;

	case WM_SYSCOMMAND:

		this->t_process_SysMenuEvent(this, wParam);
		break;
	
	case WM_COMMAND:	

		this->case_WM_COMMAND(HIWORD(wParam), LOWORD(wParam), reinterpret_cast<HWND>(lParam));

	break;


	case WM_PAINT:
		case_WM_PAINT();
		break;


	}
	return (INT_PTR)FALSE;



}

bool dialog_box::onDialogInit()
{
	return true;
}



INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		return (INT_PTR)TRUE;

	case WM_COMMAND:
		if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
		{
			EndDialog(hDlg, LOWORD(wParam));
			return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}
