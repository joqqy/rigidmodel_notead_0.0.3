#pragma once



//typedef std::uint8_t	byte;
//typedef std::uint16_t	word;
//typedef std::uint16_t	uint16;
//typedef std::uint32_t	uint32;
//typedef std::uint32_t	dword;
//typedef std::uint32_t	dword;
//typedef std::uint64_t	qword;
//typedef std::uint64_t	ddword;
//
//typedef std::int8_t		signed_byte;
//typedef std::uint16_t	int16;
//typedef std::uint32_t	int32;
//typedef std::uint64_t	int64;
//
//typedef float			float32;
//typedef double			float64;
//

#define OR ||
#define AND &&

#define or |
#define or_assign |= 

#define and &
#define and_assign |& 


using namespace std;

//
//Sign bit : 1 bit
//Exponent width : 5 bits
//Significand precision : 11 bits(10 explicitly stored)



template <class T>
struct bits {
	bits(const char* pchBits) {

		size_t bit_length = sizeof(T) * 8;
		size_t length_of_string = strlen(pchBits);
		unsigned long bit_index = 0;


		unsigned long temp = 0;


		size_t char_index = length_of_string + 1;


		if (bit_length < length_of_string)
			char_index = bit_length + 1;
		else
			char_index = length_of_string - 1;



		for (int i = 0; i < length_of_string; i++)
		{
			if (pchBits[length_of_string - 1 - i] == '1')
			{
				long t = (1 << bit_index);
				temp += t;
				bit_index++;
			}
			else
				if (pchBits[length_of_string - 1 - i] == '0')
				{
					bit_index++;
				}
		}
	};
};