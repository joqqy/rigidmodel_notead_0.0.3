// #include "stdafx.h"
#include "safe_enum.h"
#include "safe_enum_item.h"




safe_enum::safe_enum()
{
}

safe_enum::~safe_enum()
{
}

safe_enum::safe_enum(std::initializer_list<safe_enum_item> inputs)
{
	//initializer_list<safe_enum_item>::iterator it = inputs.begin();

	//while (it != inputs.end())
	//{
	//	switch (it->m_type)
	//	{
	//	case safe_enum_item::type::STRING_TO_INT:
	//		m_mapStringToUInt["test"] = it->m_value_int;
	//	break;
	//	
	//	case safe_enum_item::type::INT_TO_STRING:
	//		m_mapUIntToString[it->m_value_int] = it->m_key_string;
	//	break;

	//	case safe_enum_item::type::STRING_TO_STRING:
	//		m_mapStringToString[it->m_value_string] = it->m_key_string;
	//	break;
	//	}
	//}	
	//it++; // advance to next safe_enum_item
}

const string & safe_enum::getValueStringFromUInt(uint _key)
{
	
	map<uint, string>::iterator it = m_mapUIntToString.find(_key);

	if (it == m_mapUIntToString.end())
		return m_strError;
	else
		return it->second;
}

const uint safe_enum::getValueUIntFromString(const string _key)
{
	map<string, uint>::iterator it = m_mapStringToUInt.find(_key);

	if (it == m_mapStringToUInt.end())
		return -1;
	else
		return it->second;
}

const string& safe_enum::getValueStringFromString(const string & _key)
{	
	map<string, string>::iterator it = m_mapStringToString.find(_key);

	if (it == m_mapStringToString.end())
		return m_strError;
	else
		return it->second;
}





//
//const string & safe_enum::getValue(const string& _key)
//{
//	map<string, string>::iterator it = m_mapStringToString.find(_key);
//
//	if (it == m_mapStringToString.end())
//		return m_strError;
//	else
//		return it->second;
//}

string & safe_enum::operator[](int index)
{
	map<uint, string>::iterator it = m_mapUIntToString.find(index);

	// If iterator at end, value not found, return error text
	// else return the found value
	if (it == m_mapUIntToString.end())
		return m_strError;
	else
		return it->second;
}

int safe_enum::operator[](string key)
{
	map<string, uint>::iterator it = m_mapStringToUInt.find(key);

	// If iterator at end, value not found, return error text
	// else return the found value
	if (it == m_mapStringToUInt.end())
		return -1;
	else
		return it->second;
}

safe_enum_item & safe_enum::operator=(std::initializer_list<safe_enum_item> inputs)
{
//	// set the iterator to the start of the input list
//	initializer_list<safe_enum_item&>::iterator it = inputs.begin();
//
//	// return an error message if no input
//	if (it == inputs.end())
//	{
//
//		
//		                     
//		m_TempItem.m_value_int = 0;
//		m_TempItem.m_key_string = "ERROR_safe_enum";
//
//		return m_TempItem;
//	}
//
//	// fill the return item
//	m_TempItem.m_value_int = (int) it->m_value_int;
//	m_TempItem.m_key_string =  it->m_key_string;
//	
//	// run troung the inputs and store them in the map
//	while (it != inputs.end())
//	{
//		insertItem(it->m_value_int, it->m_key_string);
//		it++;
//	}

	return m_TempItem;
}

size_t safe_enum::size()
{
	return m_mapUIntToString.size();
}


void safe_enum::setItem(safe_enum_item * _poItem)
{
	m_poItem = _poItem;
	
}

bool safe_enum::insert(uint key, const string & _value)
{
	string* p = new string(_value);
	return	m_mapUIntToString.insert(pair < uint, string>(key, _value)).second;
}


bool safe_enum::insertIntAnString(uint32 key, string strValue)
{
	return m_mapUIntToString.insert(pair<uint, string>(key, strValue)).second;

}



safe_enum_item::safe_enum_item(int _key, string _value, uint const_value)
{
	m_value_int = _key; 
	m_key_string = _value;
	m_const = const_value;

	
	
	
}

safe_enum_item::safe_enum_item(string _key, int _value, uint const_value)
{
	m_key_string = _key;
	m_value_int = _value;
	m_const = const_value;

}

safe_enum_item::safe_enum_item(string _key, string _value, uint const_value)
{
	m_key_string = _key;
	m_value_string = _value;
	m_const = const_value;
}



