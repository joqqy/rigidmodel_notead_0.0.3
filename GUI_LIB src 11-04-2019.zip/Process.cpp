#include "process.h"
#include <CommCtrl.h>
#include "app_window.h"
#include "app.h"


process::process()
{
	sm_poCurrentProcess = this;
}


process::~process()
{
}

process::operator HINSTANCE()
{
	return m_hInstance; 	

}
LRESULT process::setupHandlers()
{
	return LRESULT();
}
//
//LRESULT process::setupHandlers()
//{
//	return LRESULT();
//}





/////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//								Message Lopp for current process
//
/////////////////////////////////////////////////////////////////////////////////////////////////////////
int process::MessageLoop()
{
	MSG msg;
	BOOL bRet;
	
	if (m_hAcceleratorTableHandle == nullptr)
	{
		if (sm_poCurrentProcess->m_bRunIdle)
		{
			do {
				if (PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE != 0))
				{

					bRet = GetMessage(&msg, NULL, 0, 0);
					{




						if (bRet < 0) // error
						{
							int exit_code = sm_poCurrentProcess->onError(bRet);
							quit(exit_code);
						}


						if (msg.message == WM_QUIT)
						{
							return (int)msg.wParam;
						}


						if (bRet == -1)
						{
							int exit_code = sm_poCurrentProcess->onError(bRet);
							quit(exit_code);
						}
						
					
						{
							TranslateMessage(&msg);
							DispatchMessage(&msg);
						}	
					}

				}
				sm_poCurrentProcess->onIdle();
			} while (bRet > 0);
			// Return the exit code to the system. 
			return (int)(msg.wParam);
		}
		else // if (sm_PCurrentProcess->m_bRunIdle)
		{
			while (bRet = GetMessage(&msg, NULL, 0, 0))
			{
				
				if (bRet < 0) // error
				{
					int exit_code = sm_poCurrentProcess->onError(bRet);
					quit(exit_code);
				}


				if (msg.message == WM_QUIT)
				{
					return (int)msg.wParam;
				}


				if (bRet == -1)
				{
					int exit_code = sm_poCurrentProcess->onError(bRet);
					quit(exit_code);
				}
				else
					
					{
						TranslateMessage(&msg);
						DispatchMessage(&msg);
					}
			}
			return (int)(msg.wParam);
		}
	}
	else // if (m_hAcceleratorTableHandle == nullptr)
	{// TODO: make a flag that determins if peek or getmessage it used.
		BOOL bRet;
		do {
			// check if thre is a message
			if (PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE != 0))
			{
				// if yes, then get it and process it
				bRet = GetMessage(&msg, NULL, 0, 0);
				if (!TranslateAccelerator(msg.hwnd, m_hAcceleratorTableHandle, &msg))
				{
					TranslateMessage(&msg);
					DispatchMessage(&msg);
				}
			}
			else if (sm_poCurrentProcess->m_bRunIdle)
				sm_poCurrentProcess->onIdle();

		} while (bRet > 0);
	}
	return (int)(msg.wParam);
}




LRESULT process::createMainWindow()
{
	return 0;
}

LRESULT process::onCreated()
{
	return 0;
}

int process::onQuit(int _exit_code)
{
	return _exit_code;
}

LRESULT process::onExit()
{
	return 0;
}

LRESULT process::onIdle()
{
	return 0;
}

int process::onError(int)
{
	return -1;
}

void process::error_kill(int ret)
{
	PostQuitMessage(ret);
}

string process::getLastErrorString()
{
	

	LPSTR pBuffer = NULL;
	// TODO: finish this with FormatMessage, so a string is returned explaing the code

	FormatMessage(
		FORMAT_MESSAGE_ALLOCATE_BUFFER |
		FORMAT_MESSAGE_FROM_SYSTEM |
		FORMAT_MESSAGE_IGNORE_INSERTS,
		NULL,
		GetLastError(),
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
		(LPSTR) &pBuffer,
		0, NULL);

	string strTemp = pBuffer;
	LocalFree(pBuffer);

	return strTemp;
}

void process::quit(int _exit_code)
{
	PostQuitMessage(_exit_code);
}

LRESULT process::loadAccelerators(UINT uiID)
{

	return 1;

}


int CALLBACK WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{	
	INITCOMMONCONTROLSEX icex;

	icex.dwSize = sizeof(INITCOMMONCONTROLSEX);
	icex.dwICC = ICC_USEREX_CLASSES;

	bool b = InitCommonControlsEx(&icex);


	//int aElements[2] = { COLOR_ACTIVECAPTION, COLOR_ACTIVECAPTION };
	//DWORD aNewColors[2];
	//aNewColors[0] = RGB(0x0, 0x0, 0x0);  // light gray 
	//aNewColors[1] = RGB(0x00, 0x00, 0x0);  // dark purple 
	//SetSysColors(2, aElements, aNewColors);





	if (!process::sm_poCurrentProcess) // Has an app been declared?
		return 2;
	
	process::sm_poCurrentProcess->m_hInstance			= hInstance;
	process::sm_poCurrentProcess->m_hPrevInstance		= hPrevInstance;
	process::sm_poCurrentProcess->m_iCmdShow			= nCmdShow;
	process::sm_poCurrentProcess->m_strCommandLine	= lpCmdLine;
	

	process::sm_poCurrentProcess->setupHandlers();
	process::sm_poCurrentProcess->createMainWindow();	
	

	char ch1[512];
		
	char * pch2 = new char[ 512];
	
	DWORD a = GetFullPathName(
		lpCmdLine,   
		512,
		ch1,
		&pch2
	);

	process::sm_poCurrentProcess->strCommandLine = ch1;


 	process::sm_poCurrentProcess->onCreated();
	

	return process::sm_poCurrentProcess->onQuit(
	
		process::MessageLoop()

	);
	
}





/////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//								Static member definitions
//
/////////////////////////////////////////////////////////////////////////////////////////////////////////
HACCEL process::m_hAcceleratorTableHandle = nullptr;
process* process::sm_poCurrentProcess = nullptr;;
string process::strCommandLine;