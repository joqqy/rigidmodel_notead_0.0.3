#pragma once
#include "window.h"
class control_group :
	public window
{
public:
	control_group();	

	control_group(window *_pPparent, int style_ex, int style, int x, int y, int width, int height);

/*	virtual bool create(window * _pPparent, int style_ex, int style, int x, int y, int width, int height);
	
	virtual bool create(window * _pPparent, csz szCpation, int style_ex, int style, int x, int y, int width, int height);*/	
		
	virtual bool create(window * _pPparent, csz czWindowClass, csz szCpation, int style_ex, int style, int x, int y, int width, int height);
	
	/*virtual bool create(window * _pPparent, int x, int y, int width, int height);		*/

	virtual ~control_group();

	virtual LRESULT case_WM_NOTIFY(NMHDR* pmnh) override;
	
	virtual LRESULT case_WM_COMMAND(word wCode, word wId, HWND hwndCtrl) override;


	

protected:

	

	static LRESULT CALLBACK WindowProc(
		HWND   hwnd,
		 UINT   uMsg,
		 WPARAM wParam,
		 LPARAM lParam
	);
	static WNDPROC sm_oldWinProc;

	//window* m_poParent;
	int x_offset = 0;
	int y_offset = 0;

};

