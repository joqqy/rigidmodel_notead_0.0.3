#pragma once
#include "Definitions.h"
#include "base.h"
#include <commctrl.h>


class image_list
{
public:
	image_list();
	virtual ~image_list();

	image_list(const image_list &);


	operator HIMAGELIST();

	HIMAGELIST getHandle();


	bool create(uint width, uint height, uint intial, uint grow, uint flags = ILC_COLOR);
	void addIcon(HICON hIcon);
	
protected:
	HIMAGELIST m_hHandle;
};


