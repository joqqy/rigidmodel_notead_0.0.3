#include "error_codes.h"

bool error_codes::isSet()
{
	return m_bIsSet;
}

void error_codes::setLastError(predefined_error_codes _code)
{
	m_last_error = _code;
	m_bIsSet = true;
}

predefined_error_codes error_codes::getLastError()
{
	return m_last_error;
}

