#pragma once
#include <windows.h>
#include <winUser.h>
#include <winefs.h>
#include "Definitions.h"


#define WC_NEW_EDIT "NEW_EDIT"


struct cursor
{
	void create(HWND);
	void set(int _x, int _y);	

	
	void drawCursor();
	void deleteCursor();
	
	void setPos(int _x, int _y);

	// stops the thread
	void show(bool); 

	static void Timerproc(
		HWND Arg1,
		UINT Arg2,
		UINT_PTR Arg3,
		DWORD Arg4
	);

	static DWORD WINAPI ThreadFunc(LPVOID);
	HANDLE hTread;
	DWORD run();
	bool bThreadRun = false;

	bool bErase = false;

	HWND hwndDest;
	int x = 0;
	int y = 0;
	int old_x = 0;
	int old_y = 0;
	bool bBGBufferEmpty = true;

	DWORD dwTimeOut;
	bool bInsert = false;
	SIZE size;
	POINT p;
	HFONT hFont = NULL;

	HDC hdcCursor = NULL;
	HBITMAP hbmCursor = NULL;;

	HDC hdcBG;
	HBITMAP hbmBG;

	HDC hdc;

};


struct NewEditBoxInfo
{
	NewEditBoxInfo();
	virtual ~NewEditBoxInfo();
	
	void allocate(uint _size);
	void enlargeBuffer(uint _size);
	void deallocate();

	sz m_szBuffer = NULL;
	uint m_buffer_size = 0;
	uint m_cursor_pos = 30;
	HBRUSH m_bgBursh;
	HFONT m_hFont;

	cursor m_cursor;
};


extern bool RegisterNewEditBox(HINSTANCE _hHinstance);


extern LRESULT CALLBACK NewEditBoxWindowProc(
	HWND   hwnd,
	UINT   uMsg,
	WPARAM wParam,
	LPARAM lParam
);


