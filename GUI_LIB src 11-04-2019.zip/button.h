#pragma once
// #include "stdafx.h"
#include "control_window.h"
//#include "combo_box.h"


#define button_decl(name, parrent, caption, StyleEx, Style, x, y, width, height)   \
button space( )##name space( ) =\
button(m_main_window, "Push Me!!", 0, WS_CHILD | BS_PUSHBUTTON | BS_FLAT, x, y, width, height);

class button :
	public control_window
{
public:
	

	button();

#define BUTTON(szCaption, dwExStyle, dwStyle, x, y, width, height)\
	 = button(this, ##szCaption, dwExStyle, x, y, width, height)

	button(window* pParentWindow, LPCSTR szCaption,

		DWORD dwExstyle, DWORD dwStyle, int x = CW_USEDEFAULT, int y = CW_USEDEFAULT,
		int  width = CW_USEDEFAULT, int height = CW_USEDEFAULT, bool bFollowParent = false

	) : control_window(pParentWindow, WC_BUTTON, szCaption, dwExstyle, dwStyle, NULL, x, y, width, height, bFollowParent)
	{

	}

	virtual bool create(window* pParentWindow, LPCSTR szCaption,

		DWORD dwExstyle, DWORD dwStyle, int x = CW_USEDEFAULT, int y = CW_USEDEFAULT,
		int  width = CW_USEDEFAULT, int height = CW_USEDEFAULT, bool bFollowParent = false
	);



	virtual ~button();

	event_info clicked = event_info(this, event_info::type::control_event, BN_CLICKED);
	
	/*	BCN_DROPDOWN
		BCN_HOTITEMCHANGE
		BN_CLICKED
		BN_DBLCLK
		BN_DISABLE
		BN_DOUBLECLICKED
		BN_HILITE
		BN_KILLFOCUS
		BN_PAINT
		BN_PUSHED
		BN_SETFOCUS
		BN_UNHILITE
		BN_UNPUSHED
		NM_CUSTOMDRAW(button)
		WM_CTLCOLORBTN*/

};

