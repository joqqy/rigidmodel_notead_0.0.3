#pragma once
#include "window.h"
#define DEF_WIN_PROC		DefWindowProc(m_oLastMessage.hwndSource, m_oLastMessage.uiMessage, m_oLastMessage.wParam, m_oLastMessage.lParam);

#define DEFAULT_ACTION { return DEF_WIN_PROC; }

#define MESSAGE_HANDLER virtual LRESULT


class internals :
	public base
{
public:
	internals();
	virtual ~internals();

///////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////
	MESSAGE_HANDLER case_WM_PAINT();


public:
	operator window*();
	operator window();
	
protected:
	window* m_poParentWindow;



};

