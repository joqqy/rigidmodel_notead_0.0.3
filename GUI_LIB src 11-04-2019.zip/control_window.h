#pragma once
/**********************************************************************************************************
	[File:]
	base.h
	   
	[Author]
	phazer

	[Created]
	15/11/2018 00:00

	[Edited]
	06/12/2018 18:16

	[Description:] Base class defintionion for the entire GUI lib. Provides the functions that are
	common far all derived classes.
***********************************************************************************************************/

// #include "stdafx.h"
#include "window.h"

class control_window : public window
{
public:
	control_window() {}
	virtual ~control_window() {}

	control_window(window* pParentWindow, LPCSTR szClassName, LPCSTR szCaption,

		DWORD dwExstyle, DWORD dwStyle, LPVOID pParam = NULL, int x = CW_USEDEFAULT, int y = CW_USEDEFAULT,
		int  width = CW_USEDEFAULT, int height = CW_USEDEFAULT, bool bFollowParent = false

	) : window(pParentWindow, szClassName, szCaption, dwExstyle, dwStyle, pParam, x, y, width, height, bFollowParent)
	{

	}
	//processOwnNotification(UINT uiNotificationCode)
	


};

