// #include "stdafx.h"
#include "window_class.h"
#include "resource.h"
//#include <resource1.h>


//
//window_class::window_class()
//{
//
//
//
//}
//
//
//window_class::window_class(string strDefaultClassName)
//{
//
//
//
//}
//






bool window_class::create_default(string strName, WNDPROC wndproc, UINT uiWmdExtra )
{

	if (DefaultWindowClass)
		return false;

	


	m_sClassInfo.m_sWindowClass.cbSize = sizeof(WNDCLASSEX);
	m_sClassInfo.m_sWindowClass.style = CS_HREDRAW | CS_VREDRAW;
	m_sClassInfo.m_sWindowClass.lpfnWndProc = wndproc;
	m_sClassInfo.m_sWindowClass.cbClsExtra = 0;
	m_sClassInfo.m_sWindowClass.cbWndExtra = sizeof(void*) + uiWmdExtra;
	m_sClassInfo.m_sWindowClass.hInstance = GetModuleHandle(0);
	m_sClassInfo.m_sWindowClass.hIcon = LoadIcon(H_INST, MAKEINTRESOURCE(IDI_FOLDER1));
	m_sClassInfo.m_sWindowClass.hCursor = LoadCursor(nullptr, IDC_ARROW);
	
	m_sClassInfo.m_sWindowClass.hbrBackground = (HBRUSH)(COLOR_BTNFACE + 1);// (CreateSolidBrush(RGB(240, 250, 250));
		m_sClassInfo.m_sWindowClass.lpszMenuName = NULL;
	m_sClassInfo.m_sWindowClass.lpszClassName = strName.c_str();
	m_sClassInfo.m_sWindowClass.hIconSm = LoadIcon(H_INST, MAKEINTRESOURCE(IDI_FOLDER1));

	
	
	m_sClassInfo.m_atmAtomID = RegisterClassEx(*this); 
		

	return (m_sClassInfo.m_atmAtomID != 0) ? true : false;

}

window_class::operator ATOM()
{
	return m_sClassInfo.m_atmAtomID;
}

//ATOM window_class::getATOM()
//{
//	return m_AtomID;
//}

void window_class::copy(WNDCLASSEX * pSource)
{
}

// ********************************************* static memebers ******************************************************

window_class* window_class::DefaultWindowClass;
