#include "internal_message_handlers.h"
#define MESSAGE_HANDLER LRESULT


internals::internals()
{
}


internals::~internals()
{
}

MESSAGE_HANDLER internals::case_WM_PAINT()
{
	return 1;
}

internals::operator window*()
{
	return m_poParentWindow;
}

internals::operator window()
{
	return *m_poParentWindow;
}

