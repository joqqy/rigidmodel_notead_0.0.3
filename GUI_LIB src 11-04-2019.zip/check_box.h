#pragma once
// #include "stdafx.h"
#include "button.h"
#include "properties.h"

using namespace std;


class check_box :
	public button
{
public:
	friend class check_box_group;

	check_box();
	
	check_box(window* pParentWindow, LPCSTR szCaption,

		DWORD dwExstyle, DWORD dwStyle, int x = CW_USEDEFAULT, int y = CW_USEDEFAULT,
		int  width = CW_USEDEFAULT, int height = CW_USEDEFAULT, bool bFollowParent = false

	);

	
	bool create(window* pParentWindow, LPCSTR szCaption,

		DWORD dwExstyle, DWORD dwStyle, int x = CW_USEDEFAULT, int y = CW_USEDEFAULT,
		int  width = -1, int height = -1, bool bFollowParent = false

	);
	

	

	virtual ~check_box();
	
	virtual void onClick(check_box* _poCheckBox);

	virtual LRESULT processOwnNotification(u32 uiID) override;

	virtual bool onCheck();
	virtual bool onUnCheck();
	
	bool  operator= (const bool);

	operator bool();


	LRESULT getState();
	LRESULT setState(LRESULT lrState);

	virtual bool inline setReadOnly(bool bState) override;
	virtual bool inline isReadOnly() override;

	bool setEnableOnCheck(bool _bState);

	void addWinToDisableList(window* _poWin);
	void addWinToReadOnlyList(window* _poWin);
	
	void disableWindows();
	void setReadOnlyWindows();

	void promtpForUncnheck(string strPrompMessage);
	void promtpForCheck(string strPrompMessage);



protected:
	bool m_bPromptForUncked = false, m, _nPromForCheck = false;
	string m_strUnCheckPrompt, m_strCheckPromptt;
	LRESULT m_lrState;
	check_box* m_poGroupParent;
	vector<window*> m_vecDisableList;
	vector<window*> m_vecReadOnlylList;
	bool m_bEnableOnChecked = true;


public:
	number_property<UINT> State = number_property<UINT>(
		[this]() { return getState(); },
		[this](UINT _state) { return setState(_state); }
	);

	number_property<bool> EnableOnCheck = number_property<bool>(
		[this]() { return m_bEnableOnChecked; },
		[this](bool _bState) { return setEnableOnCheck(_bState); }
	);
			
		
	bool_property Checked = decl_bool_property_2(return (BST_UNCHECKED != getState()), return (_bState ? setState(BST_CHECKED) : setState(BST_UNCHECKED)), false);
};
 