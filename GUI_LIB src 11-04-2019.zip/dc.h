#pragma once
#include "base.h"
#include "gdi_object.h"
class dc :
	public base
{
public:
	dc();
	virtual ~dc();

	operator HDC()	const;
	operator HDC*();
	operator HDC&();		
	
	const HGDIOBJ select(HGDIOBJ _hGDIObj);
	const gdi_object* select(gdi_object* _hGDIObj);

	void blit(HDC hdcDest, int x, int y, DWORD dwCopyModew = SRCCOPY, int size_x = 0, int size_y = 0, int offset_x = 0, int offset_y = 0);

protected:
	gdi_object* m_pCurrent_GDI_Object;
	HGDIOBJ m_hCurret_GDI_Object;
	HDC m_hDeviceContext;
};

