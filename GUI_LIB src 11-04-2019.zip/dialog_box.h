#pragma once
#include "base.h"
#include "process.h"
#include "window.h"

class dialog_box :
	public window
{
public:
	dialog_box();
	virtual ~dialog_box();
	

	void create(window* _poParent, LPCTSTR);
	void create(window* _poParent, int _id);


	static BOOL CALLBACK DialogWindowProces(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);

	bool ClassDialogProcedure(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);

	virtual bool onDialogInit();
	
	

	
};

//extern INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);