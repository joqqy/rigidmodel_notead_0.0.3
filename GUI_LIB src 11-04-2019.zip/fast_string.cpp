//#include "pch.h"
// #include "stdafx.h"
#include "fast_string.h"



 



fast_string::~fast_string()
{
}



//void fast_string::asm_copy_memory(void * pDest, const void * pSource, dword dwSizeofElement, dword dwNumberofElement)
//{
//
//	__asm
//	{
//		mov ecx, [dwNumberofElement]
//
//		mov esi, [pDest]
//		mov edi, [pSource]
//
//		
//	
//
//
//
//
//	}
//
//}
