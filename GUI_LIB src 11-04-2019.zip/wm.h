#include <window.h>

#include <windowsx.h>


#define wm(msg) virtual LRESULT on##msg (WPARAM wParam, LPARAM lParam)	

wm(WM_ACTIVATE);
wm(WM_ACTIVATEAPP);
wm(WM_AFXFIRST);

void dunc()
{
	

	
}