// #include "stdafx.h"
#include "base.h"
#include "image_list.h"



image_list::image_list()
{
}


image_list::~image_list()
{
}

image_list::image_list(const image_list & _imagelist)
{
	m_hHandle = _imagelist.m_hHandle;
}

image_list::operator HIMAGELIST()
{
	return m_hHandle;
}

HIMAGELIST image_list::getHandle()
{
	return m_hHandle;
}

bool image_list::create(uint width, uint height, uint initial, uint grow, uint flags)
{

	InitCommonControls();
	m_hHandle = ImageList_Create(width, height, ILC_COLOR32, initial, grow);

	if (m_hHandle == NULL)
		return false;

	return true;

}

void image_list::addIcon(HICON hIcon)
{
	ImageList_AddIcon(m_hHandle, hIcon);
}
