// #include "stdafx.h"
#include "window_base.h"



window_base::window_base()
{
}


window_base::~window_base()
{
}

//lr window_base::message_handler(WM_ACTIVATE)
//{
//	
//}
