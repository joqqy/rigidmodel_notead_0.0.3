
// #include "stdafx.h"
#include "window.h"
#include <sstream>

POINT g_Point;

using namespace std;

#define WMH_DECL(msg, ...) LRESULT window::case_##msg(__VA_ARGS__)
#define WM_CASE_BEGIN(msg) switch (##msg) 
#define WM_CASE_ENB }


//window::window()
//{
////	event_handler<window> ev;
////
////	//ev.pCurentClass = this;
////	//ev.pMemberFunction = &window::test;
////	
////	ev.assign3(this, &window::test);
////
////	ev.invoke3((LPARAM) this, 1, 2);
//	
//}






window::window(window * _PParentWindow, window_template _wt, int _x_offset, int _y_offset, int _width_offset, int _height_offset)
{
	m_template = _wt;
	m_template.PParentWindow = _PParentWindow;
	m_template.x += _x_offset;
	m_template.y += _y_offset;
	m_template.width += _width_offset;
	m_template.height += _height_offset;
	m_template.height += _height_offset;
	m_template.bFollowParent = false;
	if (_PParentWindow)
	{
		m_template.PParentWindow->_addChildToCreate(this);

	}
	else this->createFromInternalTemplate();

}

window::window(window * pParentWindow, LPCSTR szClassName, LPCSTR szCaption, DWORD dwExstyle, DWORD dwStyle, LPVOID pParam, int x, int y, int width, int height, bool bFollowParent)
{
	m_template.PParentWindow = pParentWindow;
	m_template.x = x;
	m_template.y = y;
	m_template.width = width;
	m_template.height = height;
	m_template.dwExStyle = dwExstyle;
	m_template.dwStyle = dwStyle;
	m_template.strClassName = szClassName;
	m_template.strCaption = szCaption;
	m_template.pParam = pParam;

	if (pParentWindow)
	{
		m_template.PParentWindow->_addChildToCreate(this);
		m_template.PParentWindow->m_bCreateFromInternalTamplate = true;
	}
	//else this->createFromInternalTemplate();
}

window::~window()
{

	//window* p = _getWindowPtrFromHandle(*this);
	//if (!p)
	//	return;

	//sm_mapHandleToWindowPtr.erase(m_hHandle);
	////removeDestroyedFromMap(*this);

	//if (sm_mapHandleToWindowPtr.size() == 0)
	//	return;

	//map<HWND, window*>::iterator it = sm_mapHandleToWindowPtr.find(m_hHandle);

	//if (it != sm_mapHandleToWindowPtr.end())
	//	sm_mapHandleToWindowPtr.erase(m_hHandle);

}





BOOL window::setPositionAndSize(window * pWndInsertAfter, int x, int y, int cx, int cy, UINT uiFlags)
{
	return SetWindowPos(m_hHandle, *pWndInsertAfter, x, y, cx, cy, uiFlags);
}

inline window::operator HWND()
{
	return m_hHandle;
}

inline window::operator POINT()
{
	return { m_x, m_y };
}

window::operator string()
{
	return getText();
}

window::operator LPSTR()
{
	return getText();

}

window::operator LPCSTR()
{
	return getText();
}

window::operator HDC()
{
	return getDC();

}



//
//inline window::operator LPCSTR()
//{
//	return getText();
//}


inline char* & window::operator=(csz & cszText)
{
	string str = cszText;
	setText(str);

	sz szTemp = m_szText;

	return szTemp;
}

inline string& window::operator=(const string& strValue)
{
	setText(strValue.c_str());

	string strTemp = getText();

	return  strTemp;
}

inline HWND & window::operator=(const HWND & _hwnd)
{
	sm_mapHandleToWindowPtr[_hwnd] = this;
	HWND hwndTemp = _hwnd;

	return hwndTemp;
}





window * window::_getWindowPtrFromHandle(HWND hwnd)
{
	map<HWND, window*>::iterator it = sm_mapHandleToWindowPtr.find(hwnd);
	if (it == sm_mapHandleToWindowPtr.end())
		return NULL;

	return it->second;

}

void window::removeDestroyedFromMap(HWND hwnd)
{

	m_mapChildHandleToWindowPtr.erase(hwnd);




}



//RECT & window::operator=(const RECT & rc)
//{
//	RECT rcTemp;
//
//	return rcTemp;
//}



int window::setX(int x)
{
	m_x = x;
	updateDimensions();
	return m_x;
}

int window::setY(int y)
{
	m_y = y;
	updateDimensions();
	return m_y;
}

int window::getX()
{
	getDimensions();
	return m_x;
}

int window::getY()
{
	getDimensions();
	return m_y;

}

void window::setWidth(int width)
{
	m_width = width;
	updateDimensions();
}

void window::setHeight(int height)
{
	m_height = height;
	updateDimensions();
}

void window::moveClientArea(int x, int y, int cx, int cy, bool bRepaint)
{
	MoveWindow(*this, x, y, cx, cy, bRepaint);
}

void window::resizeClientArea(int cx, int cy, bool _bMenu)
{
	int x = GetSystemMetrics(SM_CXSIZEFRAME);
	int y = GetSystemMetrics(SM_CYCAPTION);

	RECT rc = { 0, 0, cx + x * 2 , cy + y + x * 2 };



	DWORD ex_styles = getLongPtr(GWL_EXSTYLE);
	DWORD styles = getLongPtr(GWL_STYLE) xor WS_OVERLAPPED;

	AdjustWindowRectEx(&rc, styles, _bMenu, ex_styles);

	SetWindowPos(m_hHandle, HWND_TOP, rc.left, rc.top, rc.right, rc.bottom, SWP_NOMOVE | SWP_NOZORDER | SWP_SHOWWINDOW);
}

void window::resizeClientAreaRelatively(int dx, int dy, int dcx, int dcy, bool bRepaint)
{
	MoveWindow(*this, m_x + dx, m_y + dy, m_width + dcx, m_height + dcy, bRepaint);
}

const RECT & window::getClientRect()
{
	GetClientRect(_HWND, &m_rcClienRect);
	return m_rcClienRect;
}

void window::setPos(int x, int y, int cx, int cy, HWND hwndInsertAfter, uint uiFlags)
{
	m_hwndInsertAfter = hwndInsertAfter;
	SetWindowPos(*this, m_hwndInsertAfter, x, y, cx, cy, uiFlags);
}

void window::setPos(int x, int y, HWND hwndInsertAfter, uint uiFlags)
{
	m_hwndInsertAfter = hwndInsertAfter;
	SetWindowPos(*this, m_hwndInsertAfter, x, y, m_width, m_height, uiFlags);
}

void window::resize(int cx, int cy, HWND hwndInsertAfter, uint uiFlags)
{
	SetWindowPos(*this, hwndInsertAfter, m_x, m_y, cx, cy, uiFlags);
}

void window::resizeRelatively(int dx, int dy, int dcx, int dcy, HWND hwndInsertAfter, uint uiFlags)
{
	SetWindowPos(*this, hwndInsertAfter, m_x + dx, m_y + dy, m_width + dcx, m_height + dcy, uiFlags);
}

void window::followParentDimensions(int offset_x, int offset_y, int offset_width, int offset_height)
{
	m_bFolowParentDimensions = true;

	m_offset_x = offset_x;
	m_offset_y = offset_y;
	m_offset_width = offset_width;
	m_offset_height = offset_height;
}


BOOL window::moveAndResize(bool bRePaint)
{
	return MoveWindow(m_hHandle, m_x, m_y, m_width, m_height, bRePaint);
}

BOOL window::move(int x, int y, int width, int height, bool bRepaint)
{

	m_x = x;
	m_y = y;
	m_width = width;
	m_height = height;

	return MoveWindow(m_hHandle, x, y, width, height, bRepaint);

}

RECT & window::getClientRect(RECT * prcClientRect)
{
	GetWindowRect(_hwnd, &m_rcWindowRect);

	if (m_poParentWindow)
		MapWindowPoints(HWND_DESKTOP, *m_poParentWindow, (LPPOINT)&m_rcWindowRect, 2);


	m_x = m_rcWindowRect.left;
	m_y = m_rcWindowRect.top;
	m_width = m_rcWindowRect.right - m_x;
	m_height = m_rcWindowRect.bottom - m_y;

	return m_rcWindowRect;
}

bool window::getDialogItem(window* _po, int _id)
{
	m_hHandle = GetDlgItem(*_po, _id);

	if (m_hHandle)
		m_strText = getText();

	sm_mapHandleToWindowPtr[m_hHandle] = this;

	return (m_hHandle != NULL);
}

bool window::exitDialog(INT_PTR _value)
{
	return EndDialog(*this, _value);
}

void window::linkToWindows(window * PWinLeft, window * PWinTop, window * PWinRight, window * PWinBottom)
{

	m_PLinkedWindowLeft = PWinLeft;
	m_PLinkedWindowTop = PWinTop;
	m_PLinkedWindowRight = PWinRight;
	m_PLinkedWindowBottom = PWinBottom;;

	if (PWinLeft)
		PWinLeft->m_PLinkedWindowRight = this;

	if (PWinTop)
		PWinTop->m_PLinkedWindowBottom = this;

	if (PWinRight)
	{

		PWinRight->m_PLinkedWindowLeft = this;
	}



	if (PWinBottom)
		PWinBottom->m_PLinkedWindowTop = this;

}



void window::handleMenuItem(UINT id, base* object, pmf::MenuItemHandlerFunc pmf)
{
	m_mapMenuEventHandlers[id] = { object, pmf };

}

bool window::addChildWindowPtrToMap(string strId, window * PChild)
{
	m_mapString_ChildWindowPtr.insert(pair<string, window*>(strId, PChild));

	return false;
}

window * window::getChildWindowPtrFromMap(string strId)
{
	map<string, window*>::iterator it = m_mapString_ChildWindowPtr.find(strId);

	if (it == m_mapString_ChildWindowPtr.end())

		return NULL;

	return it->second;
}

void window::_addChildToCreate(window * _PChildWindow)
{
	m_vecChildrenToBeCreated.push_back(_PChildWindow);
}

void window::_createChildren(window* PParent, int x, int y)
{
	// runs through the list of child with valid template data and creates them
	vector<window*>::iterator it = m_vecChildrenToBeCreated.begin();
	while (it != m_vecChildrenToBeCreated.end())
	{
		if (PParent)
			(*it)->createFromInternalTemplate(PParent, x, y);
		else
			(*it)->createFromInternalTemplate();
		it++;
	}
}

LONG window::putThisIntoWindowMemory(HWND _hwnd, window* PWindow)
{
	sm_mapHandleToWindowPtr[_hwnd] = PWindow;
	/*while (sm_bThreadLocked)
		;

	sm_bThreadLocked = true;*/
	//return SetWindowLongPtr(hwnd, GWL_USERDATA, (LONG)sm_pTempThis);

	return 1;

	/*sm_bThreadLocked = false;*/
}

window * window::getThisFromWindowMemory(HWND _hwnd)
{
	map<HWND, window*>::iterator it = sm_mapHandleToWindowPtr.find(_hwnd);

	if (it == sm_mapHandleToWindowPtr.end())
		return nullptr;

	return it->second;

	//return (window*)GetWindowLongPtr(hwnd, GWL_USERDATA);
}

void window::handleMessage(UINT uiMessage, base* POJect, pmf::WMHandlerFunc pmf)
{
	/*m_mapMessagedhandlers[uiMessage] = { POJect, pmf };

	int i = m_mapMessagedhandlers.size();*/


}

LRESULT window::SubWindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{

	switch (uMsg)
	{
	case WM_COMMAND:
	{

		if (HIWORD(wParam) == 1 && lParam == 0)
		{
			window* po = _getWindowPtrFromHandle(hwnd);
			return po->t_process_AcceleratorEvent(LOWORD(wParam));
		}


	}
	break;


	case WM_CHAR:
		return 0;

		break;



	default:
		CallWindowProc(sm_oldWinProc, hwnd, uMsg, wParam, lParam);
	}

	return CallWindowProc(sm_oldWinProc, hwnd, uMsg, wParam, lParam);
}


//LRESULT window::invokeMessageHandler(UINT uiMessage, WPARAM wParam, LPARAM lParam)
//{
//	// find the right message handler info struct, if any
//	map<UINT, MsgHandlerInfo>::iterator it = m_mapMessagedHandlers.find(uiMessage);
//	if (it == m_mapMessagedHandlers.end())
//		return -1;		// does not exist, exit
//		   	 
//	// run the method with the right class using data from the iterator (that contains a MessageHandlerInfo struct)
//	return ((*(it->second).PObject).* (it->second).pmf) (wParam, lParam);
//}

LRESULT window::processWM_SIZE_linked_windows(WPARAM wParam, LPARAM lParam)
{

	//RECT *prc = (RECT*)lParam;


	//switch (wParam)
	//{
	//	case WMSZ_RIGHT:
	//		int right = prc->right;
	//		
	//		if (m_PLinkedWindowRight)
	//		{

	//			// GetWindowRect
	//			RECT rc, rcClient;

	//			

	//			GetClientRect(*m_PLinkedWindowRight, &rcClient);
	//			GetWindowRect(*m_PLinkedWindowRight, &rc);

	//			int r = rc.right - rc.left;
	//			r -= rcClient.right;

	//			m_PLinkedWindowRight->setX(right);
	//			m_PLinkedWindowRight->updateDimensions();

	//			
	//		}

	//		
	//		
	//		return  0;

	//	break;

	//}



	////RECT rc;
	////GetWindowRect(*this, &rc);
	////
	////if (rc.left != m_x) // has x changed?
	////{
	////	// Resize the left linked window's width by the difference
	////	if (m_PLinkedWindowLeft)
	////	{
	////		m_PLinkedWindowLeft->m_width += (rc.left - m_x);
	////		m_PLinkedWindowLeft->updateSize();
	////	}
	////}
	////
	////if ((rc.right-rc.left) != (m_width)) // has the width changed?
	////{
	////	// Add the difference to right window's x by the difference
	////	//right->m_x + (rc.right-rc.left) - m_width;
	////	if (m_PLinkedWindowRight)
	////	{
	////		m_PLinkedWindowRight->m_x += ((rc.right - rc.left) - m_width);
	////		m_PLinkedWindowRight->updateSize();
	////	}
	////}

	/////// ******* TOP *********
	////if (rc.top != m_y) // has y changed?
	////{
	////	// Resize the borrom linked window's height by the difference
	////	right->resizeRelatively(0, 0, 0, m_y - rc.top);
	////	
	////}
	////
	/////// ******* BOTTOM *********
	////if ((rc.bottom - rc.top) != m_height) // has height changed?
	////{
	////	// Change the bottom linked window's Y by the difference
	////	top->resizeRelatively(0, 0, 0, m_y - rc.top);
	////	
	////}





	return 0;
}




void window::getDimensions()
{

	GetWindowRect(_hwnd, &m_rcWindowRect);

	if (m_poParentWindow)
		MapWindowPoints(HWND_DESKTOP, *m_poParentWindow, (LPPOINT)&m_rcWindowRect, 2);


	m_x = m_rcWindowRect.left;
	m_y = m_rcWindowRect.top;
	m_width = m_rcWindowRect.right - m_x;
	m_height = m_rcWindowRect.bottom - m_y;

	return;
}

void window::updateDimensions()
{
	if (m_poParentWindow)
		SetWindowPos(_hwnd, HWND_NOTOPMOST, m_x - m_poParentWindow->m_x, m_y - m_poParentWindow->m_y, m_width, m_height, SWP_NOZORDER);
	else
		SetWindowPos(_hwnd, HWND_NOTOPMOST, m_x, m_y, m_width, m_height, SWP_NOZORDER);




}

csz window::setText(string strCaption)
{
	bool b = true;

	if (m_szText)
	{
		delete[] m_szText;
	}

	m_szText = new CHAR[strCaption.length() + 1];


	m_strText = strCaption;
	strcpy_s(m_szText, m_strText.length() + 1, m_strText.c_str());

	b = SetWindowText(*this, m_szText);
	if (!b) return NULL;

	update();
	show();

	return m_szText;
}

sz window::setText(sz cszText)
{
	bool b = true;
	m_strText = cszText;
	cond_del_al(m_szText, char, strlen(cszText) + 1);
	strcpy_s(m_szText, strlen(cszText) + 1, cszText);
	b = SetWindowText(*this, m_szText);
	if (!b) return NULL;

	update();
	show();

	return m_szText;
}

bool window::setReadOnly(bool bState)
{
	return false;
}

bool window::isReadOnly()
{
	return false;
}

bool window::addText(const string strText)
{
	bool b = true;
	DWORD dwLen = GetWindowTextLength(*this) + 1;

	CHAR * pchBuffer = new CHAR[dwLen];

	b = GetWindowText(*this, pchBuffer, dwLen);
	if (!b)
	{
		delete[] pchBuffer;
		return b;
	}


	string strTemp = pchBuffer;
	strTemp += strText;

	setText(strTemp);

	delete[] pchBuffer;

	return true;
}

bool window::addText(csz cszText)
{
	bool b = true;
	DWORD dwLen = GetWindowTextLength(*this) + 1;

	CHAR * pchBuffer = new CHAR[dwLen];

	b = GetWindowText(*this, pchBuffer, dwLen);
	if (!b)
	{
		delete[] pchBuffer;
		return b;
	}


	string strTemp = pchBuffer;
	strTemp += cszText;

	setText(strTemp);

	delete[] pchBuffer;

	return true;

}

HDC window::getDC()
{
	return GetDC(*this);
}

void window::updateText()
{
	SetWindowText(*this, m_strText.c_str());
}

sz window::getText()
{
	// delete any earlier content
	if (m_szText)
		delete[] m_szText;


	// Get text lenth
	m_dwTextLength = GetWindowTextLength(*this);

	// Allocate new memory
	m_szText = new char[m_dwTextLength + 1];

	// copy the window text using the api
	GetWindowText(*this, m_szText, m_dwTextLength + 1);

	// set the "string" also
	m_strText = m_szText;

	return m_szText;
}

void window::copyTextToClipBoard()
{


}

void print(HDC hdc, int x, int y, LPCSTR sz)
{
	TextOut(hdc, x, y, sz, strlen(sz));
	TextOut(hdc, x, y, sz, strlen(sz));
}






//
//LRESULT window::case_WM_CREATE(CREATESTRUCT* pCS)
//{
//	
//
//	m_x = pCS->x;
//	m_y = pCS->y;
//	m_width = pCS->cx;
//	m_height = pCS->cy;
//
//	
//
//
//	return 0;
//}






LRESULT window::process_MenuEvent(UINT uiID)
{
	map<UINT, MenuItemgHandlerInfo>::iterator it = m_mapMenuEventHandlers.find(uiID);
	if (it == m_mapMenuEventHandlers.end())
		return 0;

	it->second.invoke(uiID);


	return LRESULT();
}

LRESULT window::t_process_AcceleratorEvent(UINT uiID)
{

	return t_process_MenuEvent(uiID);

	//	// search for a match for the id
	//	map<UINT, _handler_base*>::iterator it = sm_t_mapAccelEventHandlers.find(uiId);
	//	if (it == sm_t_menuEventHandlers.end()) // is there a match?
	//		return 0; // no match found
	//
	//	// invoke the handler
	//	m_oLastMessage.uiMenuItemId = uiId;
	//	m_oLastMessage.type = window_message::types::menu_event;
	//	return it->second->invoke_MenuEvent(&m_oLastMessage);

}

LRESULT window::t_process_MenuEvent(UINT uiId)
{
	// search for a match for the id
	map<UINT, _handler_base*>::iterator it = sm_t_menuEventHandlers.find(uiId);
	if (it == sm_t_menuEventHandlers.end()) // is there a match?
		return 0; // no match found

	// invoke the handler
	//m_oLastMessage.uiMenuItemId = uiId;
	//m_oLastMessage.type = window_message::types::menu_event;


	ZeroMemory(&sm_oWindowMessage, sizeof(window_message));

	sm_oWindowMessage.type = event_info::type::menu_event;
	sm_oWindowMessage.uiMenuItemId = uiId;

	return it->second->invoke_MenuEvent(&sm_oWindowMessage);
}

LRESULT window::t_process_HotKeyEvent(UINT uiId)
{
	// search for a match for the id
	map<UINT, _handler_base*>::iterator it = sm_t_mapHotKeyHandlers.find(uiId);
	if (it == sm_t_mapHotKeyHandlers.end()) // is there a match?
		return 0; // no match found

	// invoke the handler
	//m_oLastMessage.uiMenuItemId = uiId;
	//m_oLastMessage.type = window_message::types::menu_event;


	ZeroMemory(&sm_oWindowMessage, sizeof(window_message));

	sm_oWindowMessage.type = event_info::type::menu_event;
	sm_oWindowMessage.uiMenuItemId = uiId;

	return it->second->invoke_MenuEvent(&sm_oWindowMessage);


}

LRESULT window::t_process_SysMenuEvent(window* _poSource, UINT uiId)
{
	DefWindowProc(m_oLastMessage.hwndSource, m_oLastMessage.uiMessage, m_oLastMessage.wParam, m_oLastMessage.lParam);

	// search for a match for the id
	if (sm_t_mapSysMenuHandlers.size() == 0)
		return 0;


	map<window*, map<UINT, _handler_base*>>::iterator it_win = sm_t_mapSysMenuHandlers.find(_poSource);

	if (it_win == sm_t_mapSysMenuHandlers.end()) // find the windows
		return 0; // no match found

	map<UINT, _handler_base*>::iterator it_id = it_win->second.find(uiId); //find the event
	if (it_id == sm_t_mapSysMenuHandlers[_poSource].end())
		return 0;

	// invoke the handler
	m_oLastMessage.uiMenuItemId = uiId;
	m_oLastMessage.type = window_message::types::sys_menu_event;

	return it_id->second->invoke_MenuEvent(&m_oLastMessage); // Start the event handler	
}




/*************************************************************************************************
	method:		process_ControlEvent -		method for processing events from child controls

	parm:		UINT uiNotification -		A code the signal what kins of event (click, ...., etc)
	parm:		UINT uiID -					The id (integer) of the control in questioin (not used)
	parm:		HWND hwndControl		The window handle of the control (used for search/handling)
*************************************************************************************************/
//LRESULT window::process_ControlEvent(UINT uiNotification, UINT uiID, HWND hwndControl)
//{
//	window* poWndCtrl;
//	map<HWND, window*>::iterator it = m_mapChildHandleToWindowPtr.find(hwndControl);
//	
//	if (it == m_mapChildHandleToWindowPtr.end())
//		return  0;
//
//	poWndCtrl = it->second;
//
//	(*(*it).second).processOwnNotification(uiNotification);
//
//	
//
//	// Get the map of event associated with this control
//	map<window*, map<UINT, _control_event_handler*>>::iterator itMap = sm_mapControlEventHandlers.find(poWndCtrl);
//	
//	if (itMap == sm_mapControlEventHandlers.end())
//		return 0;
//
//	// get the handler for the even in question
//	map<UINT, _control_event_handler*>::iterator itHandler = (itMap->second).find(uiNotification);
//
//	if (itHandler == (itMap->second).end())
//		return 0;
//
//	// invoke the handler
//	return itHandler->second->invoke(uiID, reinterpret_cast<LPARAM>(poWndCtrl));	
//}

/*************************************************************************************************
	method:		t_process_ControlEvent -		method for processing events from child controls

	parm:		UINT uiNotification -		A code the signal what kins of event (click, ...., etc)
	parm:		UINT uiID -					The id (integer) of the control in questioin (not used)
	parm:		HWND hwndControl		The window handle of the control (used for search/handling)
*************************************************************************************************/
LRESULT window::t_process_ControlEvent(UINT uiNotification, UINT uiID, HWND hwndControl)
{
	if (uiNotification == 5)
	{
		int i = 1;
	}


	window* poWin = _getWindowPtrFromHandle(hwndControl);
	if (!poWin)
		return 0;



	m_oWmMessage.hwndSource = hwndControl;


	m_oWmMessage.uiNotifyCode = uiID;


	window* _poWin = window::_getWindowPtrFromHandle(hwndControl);
	if (!_poWin)
		return 0;


	map<window*, map<UINT, _handler_base*>> ::iterator it = sm_t_mapControlEventHandlers.find(_poWin);

	if (it == sm_t_mapControlEventHandlers.end())
		return 0;



	map<UINT, _handler_base*>::iterator  it2 = it->second.find(uiNotification);
	if (it2 == it->second.end())
		return 0;




	_handler_base* _poBase = it2->second;


	_poWin->processOwnNotification(uiNotification);


	return _poBase->invoke_CtrlEVent(&m_oWmMessage);





	/*
			if ((*it).second == g_pWin)
			{
				return 0;
			}*/





			// Get the map of event associated with this control
			//map<window*, map<UINT, _handler_base*>>::iterator itMap = sm_t_mapControlEventHandlers.find(poWndCtrl);

			//if (itMap == sm_t_mapControlEventHandlers.end())
				//return 0;

			// get the handler for the even in question
			//map<UINT, _handler_base*>::iterator itHandler = (itMap->second).find(uiNotification);

			//if (itHandler == (itMap->second).end())
	//		return 0;

		// invoke the handler
		//return itHandler->second->invoke_CtrlEVent(&m_oWmMessage);
}






window::operator HFONT()
{
	return m_hFont;
}

window::operator font()
{

	return oFont;
}

int window::getWidth()
{
	GetWindowRect(m_hHandle, &m_rcWindowRect);
	return (m_rcWindowRect.right - m_rcWindowRect.left);
}

int window::getHeight()
{
	GetWindowRect(m_hHandle, &m_rcWindowRect);
	return (m_rcWindowRect.bottom - m_rcWindowRect.top);
}

void window::bindHandlerToControlEvent(window * _poControl, uint uiEventId, base * _po, pmf::ControlEventHandler pmfHandlerFunc)

{

	//_control_event_handler* pceh = new _control_event_handler;

	//pceh->pmf = pmfHandlerFunc;
	//pceh->PObject = _po;


	//map<window*, map<UINT, _control_event_handler*>>::iterator it1 = sm_mapControlEventHandlers.find(_poControl);
	//if (it1 == sm_mapControlEventHandlers.end()) // is the control already in the map?
	//{ // no, so put it there
	//	sm_mapControlEventHandlers[_poControl][uiEventId] = pceh;
	//}
	//else
	//{
	//	// add this new event to handler
	//	it1->second[uiEventId] = pceh;
	//}



	// Check if the control is in the first map, if yes, put this new event int the second map
	// if not add it to a temp 2nd map
	// and add that temp 2nd map to the first map
}



void window::bindHandlerToWM(window * _poWindow, uint uiMesageId, base * _po, pmf::WMHandlerFunc _pmf)
{





}


bool window::useDynCtrlRetVal(bool bState)
{
	bool bOld = m_bUseDynamicCtrlHandleValue;
	m_bUseDynamicMsgHandleValue = bState;

	return bOld;
}

bool window::isUsingDynCtrlRetVal()
{
	return m_bUseDynamicCtrlHandleValue;
}

bool window::useDynMsgRetVal(bool bState)
{
	bool bOld = m_bUseDynamicMsgHandleValue;
	m_bUseDynamicMsgHandleValue = bState;

	return bOld;
}

bool window::isUsingDynMsgRetVal()
{
	return m_bUseDynamicMsgHandleValue;
}





LRESULT window::processOwnNotification(UINT uiNotificationCode)
{
	return LRESULT();
}




//#define wm(msg) LRESULT window::on##msg (WPARAM wParam, LPARAM lParam) \\
//{		\\
//		int a= 1;
//		\\
//return 1;\\
//}

//wm(WM_ACTIVATE)  map
//wm(WM_ACTIVATEAPP)
//#define wm(msg) LRESULT window::on##msg(window * PWin, WPARAM wParam, LPARAM lParam) 


//LR window::onWM_ACTIVATE(WPARAM p, LPARAM l)
//{
//
//}





















LONG window::setStyles(DWORD dwStyles)
{
	return SetWindowLong(*this, GWL_STYLE, dwStyles);
}

LONG window::getStyles()
{
	return GetWindowLongPtr(*this, GWL_STYLE);
}

LRESULT window::_createEx(window * PParentWindow, LPCSTR szClassName, LPCSTR szCaption, DWORD dwExStyle,
	DWORD dwStyle, LPVOID pParamint, int x, int y, int width, int height, bool bFollowParent)
{




	m_wcUsing.create_default(window_class::DefaultWinowClassName, window::_WndProc, 0);



	//sm_PTempThis = this;
	// save the point of the main window, the one without a parent

	/*sm_PMainWindow


	// can't go on creating the window if another thread is accesing the static fields

	/*while (sm_bThreadLocked && sm_pTempThis)
		;*/


		// Lock the static field
	sm_bThreadLocked = true;
	sm_pTempThis = this;


	m_poParentWindow = PParentWindow;
	// fill the objec up with data	
	m_x = x;
	m_y = y;
	m_width = width;
	m_height = height;
	m_strText = szCaption;

	m_dwTextLength = strlen(szCaption);
	m_szText = new char[m_dwTextLength + 1];

	//strcpy_s(m_szText, m_dwTextLength , szCaption);
	_CopySZ(m_szText, szCaption);

	if (bFollowParent)
	{
		// Save infro on the control in the parent windos
		m_poParentWindow->m_vecFollowParent.push_back(this);

		// set this control to follow the size of the parent windows
		m_bFolowParentDimensions = bFollowParent;

		// get the client RECT of parent window
		RECT rcClient, rcWin, rcDif, rc;
		GetClientRect(*PParentWindow, &rc);

		int caption = GetSystemMetrics(SM_CYCAPTION);
		int border = GetSystemMetrics(SM_CXEDGE);


		m_offset_x = m_x;
		m_offset_y = m_y;;// -caption;

		m_offset_width = m_width;
		m_offset_height = m_height;



		m_x = rc.left + m_offset_x;
		m_y = rc.top + m_offset_y;

		m_width = rc.right + m_offset_width;;
		m_height = rc.bottom + m_offset_height;
	}



	//WNDCLASSEX wcex;
	//string strTemp;
	//if (szClassName != WC_DEFAULT)
	//{

	//	wcex.cbSize = sizeof(WNDCLASSEX);

	//	GetClassInfoEx(H_INST, szClassName, &wcex);


	//	string strTemp = szClassName;

	//	

	//	if (strTemp.find("MODDED") == string::npos)
	//	{
	//		
	//		strTemp = wcex.lpszClassName;
	//		if (strTemp == "")
	//		{
	//			strTemp = szClassName;
	//			strTemp += "_MODDED";
	//			szClassName = text::makeCopyOfSZ(strTemp.c_str());
	//		}
	//		else
	//		{
	//			strTemp = wcex.lpszClassName;
	//			strTemp += "_MODDED";
	//			szClassName = text::makeCopyOfSZ(strTemp.c_str());

	//		}

	//		//wcex.lpszClassName = strTemp.c_str();

	//		sm_oldWinProc = wcex.lpfnWndProc;
	//		wcex.lpfnWndProc = window::SubWindowProc;

	//		

	//		ATOM a = RegisterClassEx(&wcex);
	//	}
	//}




	m_hHandle = CreateWindowEx(
		dwExStyle,                              // Optional window styles.		
		szClassName,                   // Window class,
		szCaption,    // Window text
		dwStyle,            // Window style

		// Size and position
		m_x, m_y, m_width, m_height,

		*PParentWindow,
		//((PParentWindow != NULL) ? (*PParentWindow) : HWND(NULL),       // Parent window    
		NULL,       // Menu
		H_INST,  // Instance handle
		NULL        // Additional application data
	);

	m_mapChildHandleToWindowPtr[m_hHandle] = this;
	sm_mapHandleToWindowPtr[m_hHandle] = this;


	string strError = process::getLastErrorString();



	if (m_hHandle == NULL)
	{
		return 0;
	}
	setText(szCaption);



	m_bCoordinatesValid = true;
	_createChildren(NULL);

	// TODO: insert error check
	setupMenu();

	setupHandlers();

	// TODO: insert error check
	onCreated();



	// TODO: make sure this works
	// add this window to parrent's child list
	if (PParentWindow)
		PParentWindow->m_vecChildren.push_back(this);


	// store this is in the parent window's child list
	if (m_poParentWindow)
	{
		m_poParentWindow->m_mapChildHandleToWindowPtr[m_hHandle] = this;
	}

	// store in the global window list
	//m_mapChildHandleToWindowPtr[m_hHandle] = this;


	//setMenu(NULL);

	ShowWindow(m_hHandle, process::sm_poCurrentProcess->m_iCmdShow);


	// m_mapChildHWNDtoWinPtr[HWND] = this;




	setFont(m_hFont);

	sm_bThreadLocked = false;

	return 1;

}

LRESULT window::_createChildEx(window * pParentWindow, LPCSTR szClassName, LPCSTR szCaption, DWORD dwExstyle, DWORD dwStyle, LPVOID pParam, int x, int y, int width, int height, bool bFollowParent)
{

	m_wcUsing.create_default(window_class::DefaultWinowClassName, window::_WndProc, 0);


	//sm_PTempThis = this;
	// save the point of the main window, the one without a parent

	/*sm_PMainWindow


	// can't go on creating the window if another thread is accesing the static fields

	/*while (sm_bThreadLocked && sm_pTempThis)
		;*/


		// Lock the static field
	sm_bThreadLocked = true;
	sm_pTempThis = this;


	m_poParentWindow = pParentWindow;
	// fill the objec up with data	
	m_x = x;
	m_y = y;
	m_width = width;
	m_height = height;
	m_strText = szCaption;

	m_dwTextLength = strlen(szCaption);
	m_szText = new char[m_dwTextLength + 1];

	//strcpy_s(m_szText, m_dwTextLength , szCaption);
	_CopySZ(m_szText, szCaption);

	if (bFollowParent)
	{
		// Save infro on the control in the parent windos
		m_poParentWindow->m_vecFollowParent.push_back(this);

		// set this control to follow the size of the parent windows
		m_bFolowParentDimensions = bFollowParent;

		// get the client RECT of parent window
		RECT rcClient, rcWin, rcDif, rc;
		GetClientRect(*pParentWindow, &rc);

		int caption = GetSystemMetrics(SM_CYCAPTION);
		int border = GetSystemMetrics(SM_CXEDGE);


		m_offset_x = m_x;
		m_offset_y = m_y;;// -caption;

		m_offset_width = m_width;
		m_offset_height = m_height;



		m_x = rc.left + m_offset_x;
		m_y = rc.top + m_offset_y;

		m_width = rc.right + m_offset_width;;
		m_height = rc.bottom + m_offset_height;
	}

	m_hHandle = CreateWindowEx(
		dwExstyle,                              // Optional window styles.		
		(szClassName) ? szClassName : window_class::DefaultWinowClassName,                   // Window class
		szCaption,    // Window text
		dwStyle | WS_CHILD,            // Window style

		// Size and position
		m_x, m_y, m_width, m_height,

		*pParentWindow,
		//((PParentWindow != NULL) ? (*PParentWindow) : HWND(NULL),       // Parent window    
		NULL,       // Menu
		H_INST,  // Instance handle
		NULL        // Additional application data
	);

	string strError = process::getLastErrorString();

	if (m_hHandle == NULL)
	{
		return 0;
	}
	setText(szCaption);

	m_mapChildHandleToWindowPtr[m_hHandle] = this;

	m_bCoordinatesValid = true;
	_createChildren(NULL);

	// TODO: insert error check
	setupHandlers();

	// TODO: insert error check
	onCreated();




	// TODO: make sure this works
	// add this window to parrent's child list
	if (pParentWindow)
		pParentWindow->m_vecChildren.push_back(this);


	// store this is in the parent window's child list
	if (m_poParentWindow)
	{
		m_poParentWindow->m_mapChildHandleToWindowPtr[m_hHandle] = this;
	}

	// store in the global window list
	//m_mapChildHandleToWindowPtr[m_hHandle] = this;


	//setMenu(NULL);

	ShowWindow(m_hHandle, process::sm_poCurrentProcess->m_iCmdShow);


	// m_mapChildHWNDtoWinPtr[HWND] = this;




	setFont(m_hFont);

	sm_bThreadLocked = false;

	return 1;
}


bool window::createFromInternalTemplate()
{

	window_template * pwt = &m_template;

	_createEx(
		m_template.PParentWindow, m_template.strClassName.c_str(), pwt->strCaption.c_str(), pwt->dwExStyle, pwt->dwStyle
		, pwt->pParam, pwt->x, pwt->y, pwt->width, pwt->height

	);
	if (m_hHandle)
		return true;

	return false;
}

bool window::createFromInternalTemplate(window * _PParent, int x, int y)
{
	window_template * pwt = &m_template;

	_createEx(
		_PParent, m_template.strClassName.c_str(), pwt->strCaption.c_str(), pwt->dwExStyle, pwt->dwStyle
		, pwt->pParam, pwt->x + x, pwt->y + y, pwt->width, pwt->height

	);
	if (m_hHandle)
		return true;

	return false;
}

bool window::isEnabled()
{
	return IsWindowEnabled(m_hHandle);
}

bool window::enable(bool _bState, bool _bEnableChildren)
{
	bool bOld = true;
	if (!m_bDisabled)
	{
		bOld = EnableWindow(m_hHandle, _bState);
		enableChildren(_bEnableChildren);
	}



	return bOld;
}

bool window::enableChildren(bool _bState)
{
	bool bOld = false;
	for (int i = 0; i < m_vecChildren.size(); i++)
		bOld = m_vecChildren[i]->enable(_bState, _bState);

	return bOld;
}

bool window::disable(bool bState, bool bChildrenState)
{
	bool bOld;
	if (bState == false)
	{
		m_bDisabled = false;
		bOld = enable(true, bChildrenState);

	}
	else
		if (bState == true)
		{
			m_bDisabled = false;

			bOld = enable(false, bChildrenState);
			m_bPrevEnable = bOld;
			m_bDisabled = true;
		}


	disableChildren(bChildrenState);

	return bOld;
}

bool window::disableChildren(bool _bState)
{
	bool bOld = false;
	for (int i = 0; i < m_vecChildren.size(); i++)
	{
		bOld = m_vecChildren[i]->disable(_bState);

	}
	return bOld;
}


void window::createMenu()
{
}

bool window::setMenu(menu * PMenu)
{

	
	return SetMenu(*this, *PMenu);
}

bool window::drawMenu()
{
	return DrawMenuBar(*this);
}

bool window::getYesNoBox(const string & strMessage, const string & strCaption)
{
	return (IDYES == 
		MessageBox(*this, strMessage.c_str(), strCaption.c_str(), MB_YESNO | MB_ICONQUESTION | MB_DEFBUTTON1));	
}

bool window::getYesNoBox(window* _poParent, const string & strMessage, const string & strCaption)
{
	return (IDYES == 
		MessageBox(_poParent == nullptr ? (HWND)NULL : (HWND)*_poParent , strMessage.c_str(), strCaption.c_str(), MB_YESNO | MB_ICONQUESTION | MB_DEFBUTTON1));
}



void window::getOKErrorBox(const string & strMessage, const string & strCaption)
{
	MessageBox(*this, strMessage.c_str(), strCaption.c_str(), MB_OK | MB_ICONERROR | MB_DEFBUTTON1);
}

void window::getOKErrorBox(window * _poParent, const string & strMessage, const string & strCaption)
{
	MessageBox(_poParent == nullptr ? (HWND)NULL : (HWND)*_poParent, strMessage.c_str(), strCaption.c_str(), MB_OK | MB_ICONERROR | MB_DEFBUTTON1);
}

bool window::setHotKey(int id, UINT fsModifiers, UINT _key_code)
{
	return RegisterHotKey(*this, id, fsModifiers, _key_code);
	//getHotKeyEvent(id)
}

LONG window::setExStyles(DWORD dwStyles)
{
	return SetWindowLong(*this, GWL_EXSTYLE, dwStyles);
}

LONG window::getExStyles()
{
	return GetWindowLongPtr(*this, GWL_EXSTYLE);
}


bool window::update()
{
	return UpdateWindow(*this);
}

bool window::show(int iCmdShow)
{
	return ShowWindow(*this, iCmdShow);
}

window * window::setFocus(bool _bIgnoreKeyStrokes)
{
	if (_bIgnoreKeyStrokes)
		SetFocus(NULL);

	HWND hwnd = SetFocus(*this);

	return window::_getWindowPtrFromHandle(hwnd);
}

bool window::destroy()
{
	return DestroyWindow(*this);
}

int window::x()
{
	return m_x;
}

int window::y()
{
	return m_y;
}

int window::width()
{
	return m_width;
}

int window::height()
{
	return m_height;
}


RECT & window::getWindowRect()
{

	GetWindowRect(_hwnd, &m_rcWindowRect);

	if (m_poParentWindow)
		MapWindowPoints(HWND_DESKTOP, *m_poParentWindow, (LPPOINT)&m_rcWindowRect, 2);

	m_x = m_rcWindowRect.left;
	m_y = m_rcWindowRect.top;
	m_width = m_rcWindowRect.right - m_x;
	m_height = m_rcWindowRect.bottom - m_y;

	return m_rcWindowRect;
}

bool window::setWindowRect(RECT rc)
{

	return SetWindowPos(m_hHandle, HWND_TOP, rc.left, rc.top, rc.right, rc.bottom, SWP_NOZORDER | SWP_NOOWNERZORDER);


}

// ********************************************************** static members ***********************************************************************
window* window::sm_pTempThis = nullptr;
window* window::sm_pCurrentThis = nullptr;;
bool window::sm_bThreadLocked = false;
map<string, bool> m_mapMesagToBool;



// ********************************************************** structs ***********************************************************************
//LRESULT MsgHandlerInfo::invoke(WPARAM wParam, LPARAM lParam)
//{
//	return (PObject->*pmf)(wParam, lParam);
//}

LRESULT MenuItemgHandlerInfo::invoke(UINT uiID)
{
	return (PObject->*pmf)(uiID);
}


bool window::onCreated()
{
	return true;
}

bool window::onActivate(uint bState, uint min_state, HWND hwnd)
{
	return DEF_WIN_PROC;
}

void window::displayErrorBoxAndQuit(int _exit_code, const string _strTitle, const string _strDescription)
{
	MessageBox(NULL, _strTitle != "" ? _strTitle.c_str() : "Error!",
		_strDescription != "" ? _strDescription.c_str() : process::getLastErrorString().c_str(), MB_OK | MB_ICONEXCLAMATION | MB_TASKMODAL);

	process::quit(_exit_code);
}

bool window::setupMenu()
{
	return true;
}

bool window::setupHandlers()
{
	return true;
}


bool window::onClose()
{
	return true;
}

void window::onQuit()
{
}

void window::onNotify(window *, UINT _code)
{
}

void window::onError()
{
	string strError = process::getLastErrorString();

	string strText = "An error has  occurred:\n\n";

	strText += strError;

	strText += "\nExiting....";

	MessageBox(*this, strText.c_str(), "Error!", MB_OK | MB_ICONERROR);
	PostQuitMessage(1);

}


LONG window::setLongPtr(int index, LONG _value)
{
	return SetWindowLongPtr(m_hHandle, index, _value);
}

LONG window::getLongPtr(int index)
{
	return GetWindowLongPtr(m_hHandle, index);
}




font & window::operator()(font & _roFont, bool bResizeToText, int x_offset, int y_offset)
{
	if (_roFont == NULL)
		m_hFont = (HFONT)GetStockObject(DEFAULT_GUI_FONT);
	else
	{

		m_hFont = _roFont;
		oFont = _roFont;
	}
	sendMessage(WM_SETFONT, (WPARAM)m_hFont, MAKELPARAM(TRUE, 0));

	int len = GetWindowTextLength(*this);

	if (bResizeToText)
	{

		SIZE size;

		HDC hdc = *this;

		SelectObject(hdc, m_hFont);

		GetTextExtentPoint32(hdc, m_strText.c_str(), m_strText.size() + 2, &size);


		move(m_x, m_y, size.cx + x_offset, size.cy + 4 + 4 + y_offset);

	}

	return oFont;
}

// Set the font for the witn
bool window::setFont(HFONT hFont, bool nRedraw)
{
	



	//HDC  hdc = GetWindowDC(*this);
	//m_hFont = CreateFont(8, 8, 2, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, "Time New Roman");


	/*m_hFont = CreateFont(-MulDiv(12, GetDeviceCaps(hdc, LOGPIXELSY), 72), 12, 0, 0,
		FW_NORMAL, FALSE, FALSE, FALSE,
		ANSI_CHARSET, OUT_DEFAULT_PRECIS,
		CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY,
		DEFAULT_PITCH | FF_ROMAN,
		"Time");*/
		//m_hFont = CreateFont(-MulDiv(24, GetDeviceCaps(hdc, LOGPIXELSY), 72), 0, 0, 0, FW_EXTRABOLD, TRUE, TRUE, FALSE, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS,
		//	CLIP_DEFAULT_PRECIS, ANTIALIASED_QUALITY, VARIABLE_PITCH, "Couries New");


	if (hFont == NULL)
		m_hFont = (HFONT)GetStockObject(DEFAULT_GUI_FONT);
	else
		m_hFont = hFont;

	sendMessage(WM_SETFONT, (WPARAM)m_hFont, MAKELPARAM(TRUE, 0));


	return false;

}

// sends a message to the message loop
LRESULT window::sendMessage(UINT uiMsg, WPARAM wParam, LPARAM lParam)
{
	return SendMessage(*this, uiMsg, wParam, lParam);
}


// Sends a message and return without wait for the  message to be processed
LRESULT window::postMessage(UINT uiMsg, WPARAM wParam, LPARAM lParam)
{
	return PostMessage(*this, uiMsg, wParam, lParam);
}

LRESULT window::postQuit(int _exit_code)
{

	PostQuitMessage(_exit_code);
	return _exit_code;
}


// Get the SCREEN dimensions of the window
bool window::getScreenRect(RECT* pRECT)
{
	return GetWindowRect(*this, pRECT);
}


// get the screen x, y for the window
POINT window::getScreenPos()
{
	RECT rc;
	bool b = GetWindowRect(*this, &rc);
	if (!b)
		return { -1, -1 };

	return { rc.left, rc.top };
	// TODO: Add your implem
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//								Static member definitions
//
/////////////////////////////////////////////////////////////////////////////////////////////////////////
//window* window::PDesktopWindow = nullptr;
map<HWND, window*> window::sm_mapHandleToWindowPtr;
HFONT window::hDefaultFont = NULL;


map<UINT, _handler_base*> window::sm_t_menuEventHandlers;
map<UINT, _handler_base*> window::sm_t_mapHotKeyHandlers;


map<window*, map<UINT, _handler_base*>> window::sm_t_mapControlEventHandlers;
map<window*, map<UINT, _handler_base*>> window::sm_t_mapSysMenuHandlers;

map<UINT, _handler_base*> window::sm_t_mapAccelEventHandlers;

font window::DefaultFont;
map<DWORD, window*> window::sm_PTempThisList;
//thread_local_data<window*, NULL> window::sm_PTempThis = NULL;

window_message window::sm_oWindowMessage;

window* window::poMainWindow = nullptr;
WNDPROC window::sm_oldWinProc;


_window_events1 window::m_oWindowEvents;


static LRESULT CALLBACK SubWindowProc(
	HWND   hwnd,
	UINT   uMsg,
	WPARAM wParam,
	LPARAM lParam
);




window::event_info::event_info()
{
	_type = type::invalid;
}

window::event_info::event_info(window * _poSoure, int type, UINT _uiId)
{
	poSource = _poSoure;
	_type = type;
	uiId = _uiId;
}

window::event_info::event_info(window * _poSoure, UINT window_message)
{
	poSource = _poSoure;
	uiId = window_message;
}

POINT & PosFromRect(RECT & rc)
{
	g_Point.x = rc.left;
	g_Point.y = rc.top;
	
	return g_Point;
}

POINT & DimFromRect(RECT & rc)
{
	// TODO: insert return statement here
	
	if (rc.right >= rc.left)
		g_Point.x = rc.right - rc.left;
	else
		g_Point.x = rc.left - rc.right;

	if (rc.top >= rc.bottom)
		g_Point.y = rc.bottom - rc.top;
	else
		g_Point.y = rc.top - rc.bottom;
		

	return g_Point;
}

window DesktopWindow(GetDesktopWindow());