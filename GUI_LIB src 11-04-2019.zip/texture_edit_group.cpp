// #include "stdafx.h"
#include "texture_edit_group.h"



texture_edit_group::texture_edit_group()
{
}


texture_edit_group::~texture_edit_group()
{
}
