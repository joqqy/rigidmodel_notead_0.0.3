// #include "stdafx.h"
#include "child_window.h"



child_window::child_window()
{
}


child_window::~child_window()
{
}
