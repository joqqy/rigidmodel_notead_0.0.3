// #include "stdafx.h"
#include "new_edit_box.h"

bool RegisterNewEditBox(HINSTANCE _hHinstance)
{
	WNDCLASSEX wcex;

	wcex.cbSize = sizeof(WNDCLASSEX);
	wcex.cbWndExtra = sizeof(NewEditBoxInfo*); // Allocate space for a pointer to and info struct
	wcex.cbClsExtra = 0;
	wcex.hbrBackground = (HBRUSH)COLOR_BTNFACE;
	wcex.lpfnWndProc = NewEditBoxWindowProc;
	wcex.hCursor = 0;
	wcex.hIcon = 0;
	wcex.hIconSm = 0;
	wcex.hInstance = _hHinstance;
	wcex.lpszClassName = "NEW_EDIT";
	wcex.lpszMenuName = NULL;
	wcex.style = CS_HREDRAW | CS_VREDRAW;

	return RegisterClassEx(&wcex);	
}


LRESULT CALLBACK NewEditBoxWindowProc(
	HWND   hwnd,
	UINT   msg,
	WPARAM wParam,
	LPARAM lParam)
{
	// Get the struct pointer from memory
	NewEditBoxInfo* P = (NewEditBoxInfo*) GetWindowLongPtr(hwnd, 0);	
	if (P == NULL)
	{	// if none present yet, create one and store it
		P = new NewEditBoxInfo;
		SetWindowLongPtr(hwnd, 0, (LONG_PTR)P);
		P->m_bgBursh = CreateSolidBrush(RGB(0, 0, 0));
		
		

		P->m_hFont = CreateFont(-10, -5, 0, 0,
		FW_NORMAL, FALSE, FALSE, FALSE,
		ANSI_CHARSET, OUT_DEFAULT_PRECIS,
		CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY,
		DEFAULT_PITCH | FF_ROMAN,
		"Times New Roman");

//		SendMessage(hwnd, WM_SETFONT, (WPARAM)P->m_hFont, TRUE);


		P->m_cursor.create(hwnd);
		
		
		
		
		
	}
	

	uint x = 0;
	uint y = 0;
	int cx = 0;
	int cy = 0;
	
	P->m_cursor.setPos(0, 0);
	
	switch (msg)
	{
		case WM_TIMER:
		{
			if (P->m_cursor.bErase)
			{
				P->m_cursor.drawCursor();
				P->m_cursor.bErase = false;
			}
			else
			{
				P->m_cursor.drawCursor();
				P->m_cursor.bErase = true;
			}			

			
		}
		break;


		case WM_PAINT:
		{
			//P->m_cursor.show(false);
			//SuspendThread(P->m_cursor.hTread);
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hwnd, &ps);
			{
				
				FillRect(hdc, &ps.rcPaint, P->m_bgBursh);
				SetTextColor(hdc, RGB(255, 255, 255));				
				SetBkColor(hdc, RGB(0, 0, 0));
				SIZE size, size2;
				
				//if (P->m_cursor.hFont == NULL)
				//	P->m_cursor.hFont = CreateFont(14, 0, 0, 0, 500, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS,
				//									CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FIXED_PITCH, TEXT("Times New Roman"));

				if (P->m_cursor.hFont == NULL)
					P->m_cursor.hFont = CreateFont(72, 34, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS,
					CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FIXED_PITCH, TEXT("Consolas"));
			
				SelectObject(hdc, P->m_cursor.hFont);

				SetTextColor(hdc, RGB(200, 200, 200));

				sz szTemp = new char[2];
				szTemp[0] = 'A';
				szTemp[1] = '\0';
				GetTextExtentPoint32(hdc, szTemp, 1, &size2);
				
				POINT p = { size2.cx, size2.cy };
				LPtoDP(hdc, &p, 1);
				
				for (int i = 0; i < 1000; i++)
				{
					
					if (i == P->m_cursor_pos)
					{
									
						P->m_cursor.setPos(x, y);			
					}


					if (P->m_szBuffer[i] == '\n')
					{
						x = 0;
						y += size2.cy;
					}
					else
					{
						szTemp[0] = P->m_szBuffer[i];
						GetTextExtentPoint32(hdc, szTemp, 1, &size);
						TextOut(hdc, x, y, szTemp, 1);
						x += size.cx+1;
					}
				}



				
			}
			
			
			



			EndPaint(hwnd, &ps);
			//InvalidateRect(hwnd, NULL, true);
			//P->m_cursor.deleteCursor();
			P->m_cursor.show(true);
			ResumeThread(P->m_cursor.hTread);
		}
		break;

		default:
			return DefWindowProc(hwnd, msg, wParam, lParam);
	}

	
	return DefWindowProc(hwnd, msg, wParam, lParam);
}

NewEditBoxInfo::NewEditBoxInfo()
{
	allocate(0xFFFF);
	memcpy(m_szBuffer, "C:\\Window\\Sys..Testing Fonts\nand text functions\n0123456789\nto see how they work and\nimprove them", strlen("Testing Fonts\nand text functions\n0123456789\nto see how they work and\nimprove them"));
}

NewEditBoxInfo::~NewEditBoxInfo()
{
	deallocate();
}

void NewEditBoxInfo::allocate(uint _size)
{
	if (m_szBuffer)
		delete[] m_szBuffer;

	m_szBuffer = new char[_size];
	m_buffer_size = _size;
}

void NewEditBoxInfo::enlargeBuffer(uint _sizeAdd)
{
	
	if (m_szBuffer)
	{

		sz szTemp = new char[m_buffer_size];
		memcpy(szTemp, m_szBuffer, m_buffer_size);
		
		uint old_size = m_buffer_size;

		allocate(m_buffer_size + _sizeAdd);

		memcpy(m_szBuffer, szTemp, old_size);

	}
	else
	{
		allocate(_sizeAdd);
	}

}

void NewEditBoxInfo::deallocate()
{
	if (m_szBuffer)
		delete[] m_szBuffer;
}

void cursor::create(HWND _hwnd)
{
	show(false);
	hwndDest = _hwnd;
	HDC hdcDest = GetDC(hwndDest);

	char szTemp[] = "A";
	
	
	
	
	
	
	GetTextExtentPoint32(hdcDest, szTemp, 1, &size);
	p = { size.cx, size.cy };
	bool b = LPtoDP(hdcCursor, &p, 1);

	hdcCursor = CreateCompatibleDC(hdcDest);
	hbmCursor = CreateCompatibleBitmap(hdcDest, p.x, p.y);
	SelectObject(hdcCursor, hbmCursor);

	hdcBG = CreateCompatibleDC(hdcDest);
	hbmBG = CreateCompatibleBitmap(hdcDest, p.x, p.y);
	SelectObject(hdcBG, hbmBG);


	SetTextColor(hdcCursor, RGB(255, 255, 255));
	SetBkColor(hdcCursor, RGB(0, 0, 0));

	RECT rc = { 0, 0, size.cx, size.cy };
	HBRUSH hbr = CreateSolidBrush(0x00FFFFFF);
	//FillRect(hdcCursor, &rc, hbr);
	TextOut(hdcCursor, 0, 0, "_", 1);
	
	hdc = GetDC(_hwnd);


	//SetTimer(_hwnd, 12344, 100, NULL);
	hTread = CreateThread(NULL, 0, ThreadFunc, reinterpret_cast<LPVOID>(this),0,  NULL);	
}

void cursor::drawCursor()
{
	//HDC hdc = GetDC(hwndDest);
	old_y = y;
	old_x = x;
	hdc = GetDC(hwndDest);
	
	// copy background
	BitBlt(hdcBG, 0, 0, size.cx, size.cy, hdc, x, y, SRCCOPY);
	bBGBufferEmpty = false;

	// draw cursor
	BitBlt(hdc, x, y, size.cx, size.cy, hdcCursor, 0, 0, SRCINVERT);
	
	
	//BitBlt(hdc, x, y, size.cx, size.cy, hdcBG, 0, 0, SRCCOPY);
	
	//BitBlt(hdc, old_x, old_y, size.cx, size.cy, hdcBG, 0, 0, SRCCOPY);
}

void cursor::deleteCursor()
{
	if (bBGBufferEmpty)
		return;
	hdc = GetDC(hwndDest);	
	

	//BitBlt(hdc, x, y, size.cx, size.cy, hdcCursor, 0, 0, SRCINVERT);
	
	
	BitBlt(hdc, old_x, old_y, size.cx, size.cy, hdcBG, 0, 0, SRCCOPY);
	
	//BitBlt(hdc, old_x, old_y, size.cx, size.cy, hdcBG, 0, 0, SRCCOPY);
	//BitBlt(hdc, x, y, size.cx, size.cy, hdcCursor, 0, 0, SRCINVERT);
}

void cursor::setPos(int _x, int _y)
{
	if (bErase)
		 deleteCursor();
	
	x = _x;
	y = _y;
}

DWORD cursor::run()
{
	//
	//HDC hdcDest = GetDC(hwndDest);

	//char szTemp[] = "_";

	///*hFont = CreateFont(-10, -5, 0, 0,
	//	FW_NORMAL, FALSE, FALSE, FALSE,
	//	ANSI_CHARSET, OUT_DEFAULT_PRECIS,
	//	CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY,
	//	DEFAULT_PITCH | FF_ROMAN,
	//	"System");
	//SelectObject(hdcCursor, hFont);*/
	//hdcCursor = CreateCompatibleDC(hdcDest);
	//GetTextExtentPoint32(hdcCursor, szTemp, 1, &size);
	//p = { size.cx, size.cy };
	//bool b = LPtoDP(hdcCursor, &p, 1);

	//hbmCursor = CreateCompatibleBitmap(hdcDest, p.x, p.y);
	//SelectObject(hdcCursor, hbmCursor);

	//hdcBG = CreateCompatibleDC(hdcDest);
	//hbmBG = CreateCompatibleBitmap(hdcDest, p.x, p.y);
	//SelectObject(hdcBG, hbmBG);


	//SetTextColor(hdcCursor, RGB(255, 255, 255));
	//SetBkColor(hdcCursor, RGB(0, 0, 0));
	//TextOut(hdcCursor, 0, 0, "_", 1);

	//hdc = GetDC(hwndDest);


	int _x, _y;
	while (true)
	{
	
		if (bThreadRun)
		{
			// get the x and y first, so that they don't between draw and "delete"
			if (bErase)
			{
				drawCursor();
				bErase = false;
			}
			else
			{
				deleteCursor();
				bErase = true;
			}

			Sleep(400);
		}
	}
}

void cursor::show(bool _b)
{
	bThreadRun = _b;
}

void cursor::Timerproc(HWND Arg1, UINT Arg2, UINT_PTR Arg3, DWORD Arg4)
{
	cursor* pCursor = reinterpret_cast<cursor*>(Arg4);
}

DWORD __stdcall cursor::ThreadFunc(LPVOID pVoid)
{
	cursor* pCursor = reinterpret_cast<cursor*>(pVoid);
	return pCursor->run();
	
}
