#pragma once

#include "Definitions.h"
#include "safe_enum_item.h"

using namespace std;







class safe_enum
{
public:
	
	map<uint, string> m_mapUIntToString;
	map<string, uint> m_mapStringToUInt;
	map<string, string> m_mapStringToString;
	
public:
	safe_enum();

	virtual ~safe_enum();
		
	


	safe_enum(std::initializer_list <safe_enum_item> inputs);
		
	const string& getValueStringFromUInt(const uint _key);
	
	const uint getValueUIntFromString(const string  _key);
	
	const string& getValueStringFromString(const string& _key);

	string & operator[](int key);
	int operator[](string key);

	safe_enum_item & operator=(std::initializer_list <safe_enum_item> inputs);


	size_t size();


	void setItem(safe_enum_item * _poItem);

	

	bool insert(uint key, const  string&  _value);
	const string & findItem(uint key);

	bool insert(const string key, uint _vakue);
	bool insert(uint key, uint _valuw);

	bool insertItem(uint key, const string _value);
	bool insertItem(const string& key, uint _vakue);



protected:
	bool insertIntAnString(uint32 key, string   strValue);



	string m_strTemp;

	string  m_strError = "ERROR safe_enumn!";



	safe_enum_item*	m_poItem;
	safe_enum_item	m_TempItem;


	

};

