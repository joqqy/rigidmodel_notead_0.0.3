#pragma once
#include "window.h"


class frame_window : public window
{
public:
	
	
};

