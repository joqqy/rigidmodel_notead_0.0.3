// #include "stdafx.h"
#include "GDISurface.h"

//
//
//GDISurface::GDISurface()
//{
//}
//
//
//GDISurface::~GDISurface()
//{
//	HBITMAP h;
//	
//}
//
//bool GDISurface::create(u32 width, u32 height)
//{
//	m_hDC = CreateCompatibleDC(GetDC(GetDesktopWindow()));
//	m_hBitmnp = CreateCompatibleBitmap(m_);
//
//	HWND w;
//	GetDC(w);
//	
//	
//	return false;
//}
