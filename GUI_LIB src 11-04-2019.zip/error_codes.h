#pragma once

#include "safe_enum.h"
#include "safe_enum_item.h"

class error_codes
{
	/*safe_enum error_enum_safe = safe_enum(  
		 {"ERROR_CODE_NOT_SET",	"Error Code Not set", 1},
		   {"UNDEFINED_ERROR",		"Error is undefine", 2},
		   {"FILE_NOT_FOUND",		"Error: File Not Found", 3},
		   {"FILE_READ_ERROR",		"Error Reading File", 4}
		};*/
	
	


	
	bool isSet();
	void setLastError(predefined_error_codes	 _code);
	predefined_error_codes	 getLastError();


private:
	bool m_bIsSet = false;
	predefined_error_codes m_last_error  = predefined_error_codes::ERROR_CODE_NOT_SET;

};