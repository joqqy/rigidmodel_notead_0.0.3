// #include "stdafx.h"
#include "menu_item.h"



menu_item::menu_item()
{
	ZeroMemory(&m_oMenuItemInfo, sizeof(MENUITEMINFO));
	m_oMenuItemInfo.wID = getNextId();
	m_Id = m_oMenuItemInfo.wID;
	m_oMenuItemInfo.dwTypeData = NULL;
	m_oMenuItemInfo.cbSize = sizeof(MENUITEMINFO);
	m_oMenuItemInfo.fMask = MIIM_STATE;
	m_oMenuItemInfo.fState = MFS_ENABLED;
}
menu_item::menu_item(UINT id)
{
	ZeroMemory(&m_oMenuItemInfo, sizeof(MENUITEMINFO));
	m_oMenuItemInfo.wID = id;
	m_Id = m_oMenuItemInfo.wID;
	m_oMenuItemInfo.dwTypeData = NULL;
	m_oMenuItemInfo.cbSize = sizeof(MENUITEMINFO);
	m_oMenuItemInfo.fMask = MIIM_STATE;
	m_oMenuItemInfo.fState = MFS_ENABLED;
}
//
//menu_item::menu_item(string strText, UINT uiFlags)
//	: menu_item()
//{
//
//	m_oMenuItemInfo.fMask = MIIM_STRING | MIIM_STATE | MIIM_ID;
//	if (uiFlags == 0)
//		m_oMenuItemInfo.fState = MFS_ENABLED;
//	else
//		m_oMenuItemInfo.fState = uiFlags;
//
//	if (m_oMenuItemInfo.dwTypeData)
//		delete[] m_oMenuItemInfo.dwTypeData;
//
//	m_oMenuItemInfo.cch = strText.size() + 1;
//
//	m_oMenuItemInfo.dwTypeData = new char[m_oMenuItemInfo.cch];
//	strcpy_s(m_oMenuItemInfo.dwTypeData, m_oMenuItemInfo.cch, strText.data());
//
//
//
//}
//
//menu_item::menu_item(string strText, UINT fType, UINT uiFlags)
//{
//
//	m_oMenuItemInfo.fMask = MIIM_STATE | MIIM_FTYPE;
//
//	m_oMenuItemInfo.fState = uiFlags;
//
//	m_oMenuItemInfo.fType = fType;
//
//
//}


//menu_item & menu_item::operator=(const _item _i)
//{
//	m_ItemInfo.fMask = MIIM_STRING | MIIM_STATE | MIIM_ID;
//	if (_i.flags == 0)
//		m_ItemInfo.fState = MFS_ENABLED;
//	else
//		m_ItemInfo.fState = _i.flags;
//
//	if (m_ItemInfo.dwTypeData)
//		delete[] m_ItemInfo.dwTypeData;
//
//	m_ItemInfo.cch = _i.str.size() + 1;
//
//	m_ItemInfo.dwTypeData = new char[m_ItemInfo.cch];
//	strcpy_s(m_ItemInfo.dwTypeData, m_ItemInfo.cch, _i.str.data());
//}

UINT menu_item::getId()
{
	return m_Id;
}

//menu_item::operator UINT()
//{
//	return m_Id;
//}

menu_item * menu_item::set(string strText, UINT _type, UINT _flags, HBITMAP _hBitmap)
{
	
	
	

	m_oMenuItemInfo.fMask = MIIM_STRING | MIIM_STATE | MIIM_ID;
	if (_flags == 0)
		m_oMenuItemInfo.fState = MFS_ENABLED;
	else
		m_oMenuItemInfo.fState = _flags;

	if (m_oMenuItemInfo.dwTypeData)
		delete[] m_oMenuItemInfo.dwTypeData;

	m_oMenuItemInfo.cch = strText.size() + 1;

	m_oMenuItemInfo.dwTypeData = new char[m_oMenuItemInfo.cch];
	strcpy_s(m_oMenuItemInfo.dwTypeData, m_oMenuItemInfo.cch, strText.data());
	
	// if already in a menu, change its values
	MENUITEMINFO mii;
	mii.fMask = 0xFFFFFFFF; /// MIIM_BITMAP | MIIM_DATA | MIIM_FTYPE | MIIM_ID | MIIM_STATE | MIIM_SUBMENU | MIIM_CHECKMARKS
	if (m_hParentMenu)
	if (GetMenuItemInfo(m_hParentMenu, getId(), false, &mii))
	{
		
		


		SetMenuItemInfo(m_hParentMenu, getId(), false, &m_oMenuItemInfo);

	}

	return this;
}

bool menu_item::update(UINT _mask)
{
	if (m_hParentMenu)
	{
		m_oMenuItemInfo.fMask = _mask;

		BOOL b = SetMenuItemInfo(m_hParentMenu, getId(), false, &m_oMenuItemInfo);
		return b;
	}

}

uint menu_item::getNextId()
{
	// asm BEGIIN
	return sm_uiNextId++;
}	// asm END.


/////////////////////////////////////////////////////////////////////////////////
//			Static Member Variables
/////////////////////////////////////////////////////////////////////////////////
uint menu_item::sm_uiNextId = 1;