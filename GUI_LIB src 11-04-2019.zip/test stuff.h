

void setMessageHandler(UINT uiMessage, base *PObject, PBaseMemberFunction pmf)
{
	m_mapMessageHandler[uiMessage] = pmf;
}

//typedef (base::*handler_WM_COMMAND)(

// Link each side to another window, so they will resize together
void linkToWindows(window* left, window* top, window* right, window* bottom)
{
	// The left window ptr is set to left win ptr param 
	// the left->PwindRight is set to this window
	// When this gets a WM_SIZE message making the left side bigger, 
	// it will make RIGHT side smaller on the other window, and the linked window will do the same in reverse
	
	
	m_PLeft = left;
	m_PTop = top;
	m_PRight = right;
	m_PBottom = bottom;
	
	if (left)		
		left->m_PRight = this;
	
	if (top)		
		top->m_PBottom = this;
	
	if (right)		
		right->m_PLeft = this;
	
	if (bottom)		
		bottom->m_PTop = this;	
}

LRESULT processWM_SIZE_linked_wins(WPARAM wParam, LPARAM lParam)
{	
	Rect rc;
	GetWindowRect(*this, &rc);
	
	if (rc.left != m_x) // has x changed?
	{
		// Resize the right linked window's width by the difference
		right->resizeRelatively(0, 0, m_x - rc.left, 0);
		
	}
	
	if ((rc.right-rc.left) != (m_width)) // has the width changed?
	{
		// Add the difference to right window's x by the difference
		right->m_x + (rc.right-rc.left) - m_width;
		
		rigth->resizeRelatively((rc.right-rc.left) - m_width, 0, 0, 0);
	}

	/// ******* TOP *********
	if (rc.top != m_y) // has y changed?
	{
		// Resize the borrom linked window's height by the difference
		right->resizeRelatively(0, 0, 0, m_y - rc.top);
		
	}
	
	/// ******* BOTTOM *********
	if ((rc.bottom - rc.top) != m_height) // has height changed?
	{
		// Change the bottom linked window's Y by the difference
		top->resizeRelatively(0, 0, 0, m_y - rc.top);
		
	}

	
	

}


