#pragma once

#include "control_window.h"
#include "image_list.h"


#define space(s)  #s  
#define combo_box_decl(name, parrent, caption, StyleEx, Style, X, Y, width, height)\
combo_box space( )  ##name = combo_box(parrent, caption, 0, 0, NULL, X, Y, width, height) 


class combo_box :
	public window
{
	
public:
	combo_box();

	combo_box(window* pParentWindow,
		LPCSTR szContent, DWORD dwExstyle, DWORD dwStyle, LPVOID pParam = NULL, int x = CW_USEDEFAULT, int y = CW_USEDEFAULT,
		int  width = CW_USEDEFAULT, int height = CW_USEDEFAULT, bool bFollowParent = false
	)
		: window(pParentWindow, WC_COMBOBOXEX, szContent, dwExstyle, WS_CHILD | CBS_DROPDOWNLIST, pParam, x, y, width, height, bFollowParent)
	{
		sm_poCb = this;
	}

	virtual bool create(window* pParentWindow,
		LPCSTR szContent, DWORD dwExstyle, DWORD dwStyle, LPVOID pParam = NULL, int x = CW_USEDEFAULT, int y = CW_USEDEFAULT,
		int  width = CW_USEDEFAULT, int height = CW_USEDEFAULT, bool bFollowParent = false
	);

	static combo_box* sm_poCb;

	virtual ~combo_box();

	// creates the combo box
	bool create(window* PParent, string strName, int x, int y, int width, int height, uint uiExStyle, uint uiStyle);

	// add a string to the combo box at the end of any other stings
	bool addElement(csz str, LPARAM lParam = 0, int image = -1);

	
	image_list & operator=(const image_list);
		
	LRESULT setImageList(image_list  _ImageList);
	
	bool selectByIndex(u32 index);

	void selectByParam(const LPARAM _lParam);

	
	// TODO: Write tis method
	int findByLPARAM(const LPARAM _lParam);




	COMBOBOXEXITEM * get(uint _index);


	LRESULT getCurrectSelectionIndex();
	

	size_t size();
	

	COMBOBOXEXITEM & getSelectedItem(int _index = -1);

protected:
	image_list m_CurrentImageList;
	vector<COMBOBOXEXITEM*> m_vecList;
	COMBOBOXEXITEM m_cbeiTemp;
	constexpr static char sm_cszError[] = "ERROR, COMBOBOX";

};


