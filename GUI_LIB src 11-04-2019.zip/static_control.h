#pragma once
#include "window.h"
class static_control :
	public window
{	// TODO: finish this
public:
	WIN_ASSIGN;
	static_control();
	virtual ~static_control();
};

