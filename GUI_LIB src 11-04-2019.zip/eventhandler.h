#pragma once
#include "base.h"


class event_handler_base_windows : public base
{
public:
	virtual LRESULT invoke(WPARAM wParam, LPARAM lPAram) = 0;
	

protected:
	//window* m_pParentWindow;
};






template <class C>
class event_handler_derived_windows : public base
{
public:
	typedef LRESULT (C::*pFunc)(WPARAM, LPARAM);

	virtual LRESULT invoke(WPARAM wParam, LPARAM lParam)
	{
																	
																	
		(*m_pClass.*m_pMemberFunc)(1, 2);
		return 1;
		

	}
	void setTagerMethod(C* pClass, pFunc p )
	{
  
		m_pClass = pClass;
		m_pMemberFunc = p;

	}
	

protected:
	C* m_pClass;

	pFunc m_pMemberFunc;

};

class event_handler_list {

public:
	//template <class C>
	//void handlWindowsMessage(window* pParentWindow, UINT uiMsg, c* pClass, pFuuc pMethod);
	//void assignHandlerToEven()window* pParentWindow, UINT uiMsg, c* pClass, pFuuc pMethod);


protected:
	map<UINT, event_handler_base_windows*> mapWM_Handler;

};