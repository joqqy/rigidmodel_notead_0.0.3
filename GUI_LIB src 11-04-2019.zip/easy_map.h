#pragma once


#pragma once

#include "Definitions.h"

using namespace std;


// TODO: finish this template with code from safe_enum

template <class _KEY, class _VALUE>
class easy_map_item
{
public:
	friend class safe_enum;


	safe_enum_item();
	safe_enum_item(_KEY _key, _VALUE _value);v


	virtual ~safe_enum_item();

	// TODO:: delete list



protected:
	void addToList(safe_enum_item _poItem)
	{
		m_vecList.push_back(_poItem);
	}
protected:
	_KEY m_key;
	_VALUE m_value;

	//safe_enum* m_poParent;

	vector <safe_enum_item> m_vecList;
};

class safe_enum
{
public:
	safe_enum();

	virtual ~safe_enum();

	safe_enum(std::initializer_list <safe_enum_item> inputs);

	

	string & operator[](int index);

	safe_enum_item & operator=(std::initializer_list <safe_enum_item> inputs);


	size_t size();


	void setItem(safe_enum_item * _poItem);




public:






	string m_strTemp;

	string  m_strError = "ERROR safe_enumn!";



	//safe_enum_item*	m_poItem;
	//safe_enum_item	m_TempItem;


	map<uint32, string> m_mapItemList;

};









struct menu_item
{
	uint key;
	string strValue;
};


class test
{
public:
	test(std::initializer_list <menu_item> inputs)
	{

		initializer_list<menu_item>::iterator it = inputs.begin();




	}
};




