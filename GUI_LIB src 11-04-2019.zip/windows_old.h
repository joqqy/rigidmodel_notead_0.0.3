#pragma once
#pragma once
#pragma once
/**********************************************************************************************************
	[File:]		windows.h
	[Author:]	phazer
	[Created:]	15/11/2018 00:00
	[Edited:]	02/01/2019 20:15

	[Description:]
	Window Class declartion for GUI LIB

***********************************************************************************************************/

#include "base.h"
#include "process.h"
#include "menu.h"
#include "event_handler.h"
#include "window_class.h"
#include "thread_local_data.h"
#include "font.h"
#include "properties.h"
#include <vector>

class window;


//#include <resource1.h>
#include <Commctrl.h>

#define _hwnd m_hHandle 
#define space(T) T

#define _case(msg, ...)\
	case space( ) ##msg: return this->case_##msg(__VA_ARGS__); break;

#define CALL_CASE(msg, ...)\
	return this->case_##msg(__VA_ARGS__); break;


#define CASE2(func, msg, ...) case space( ) ##msg:func; return this->case_##msg(__VA_ARGS__); break;

#define CASE_WL(msg) case space( ) ##msg: return this->case_##msg(wParam, lParam ); break;

#define DECL_WM_HANDLER(msg, ...) virtual LRESULT case_##msg(__VA_ARGS__)
#define DEF_WM_HANDLER(msg, ...)  LRESULT window::case_##msg(__VA_ARGS__)

#define message_handler(msg, ...) case_##msg(__VA_ARGS__)

//#define WMH(msg, ...) virtual inline LRESULT case_##msg(__VA_ARGS__)
#define WMH_DECL virtual inline LRESULT
#define WMH_DEF  inline LRESULT

#define _CASE(msg) case_##msg

// Adds assignment operators to derivatives of window
#define WIN_ASSIGN\
	sz & operator=(const sz _csz)\
	{\
		setText(_csz);\
		return m_szText;\
	}\
	string & operator=(const string _str)\
	{\
		setText(_str.c_str());\
		string strret = _str;\
		return strret;\
	}\
	long & operator=(const long _l)\
	{\
		cond_del_al(m_pszTempText, char, 255);\
		_ltoa_s(_l, m_pszTempText, 255, 10);\
		setText(m_pszTempText);\
		long lRet = _l;\
		return lRet;\
	}\
	int & operator=(const int _i)\
	{\
		cond_del_al(m_pszTempText, char, 255);\
		_itoa_s(_i, m_pszTempText, 255, 10);\
		setText(m_pszTempText);\
		int iRet = _i;\
		return iRet;\
	}\

//#define WMH virtual LRESULT 


#define DEF_WM_HANDLER(msg, ...) LRESULT window::case_##msg(__VA_ARGS__)

#define CALL_WM_HANDLER(msg, ...) case_##msg(__VA_ARGS__)

#define _decl_wn_handler(msg, ...) virtual LRESULT WM_HANDLER_##msg(__VA_ARGS__)

#define WS_DEFAULT			WS_OVERLAPPEDWINDOW | WS_BORDER | WS_CAPTION
#define WS_EX_DEFAULT		WS_EX_CLIENTEDGE

#define WINDOW_DESKTOP		GetDesktopWindow()

#define W					(*this)
#define _HWND				m_hHandle
#define THIS_WINDOW			(*this)


#define DEF_WIN_PROC		DefWindowProc(m_oLastMessage.hwndSource, m_oLastMessage.uiMessage, m_oLastMessage.wParam, m_oLastMessage.lParam);





class event_type
{
	static constexpr int type_invalid = 0;
	static constexpr int type_wm_event = 1;
	static constexpr int type_menu_event = 2;
	static constexpr int type_control_event = 3;
};



struct _event
{
	constexpr static int TYPE_WM_EVENT = 0;
	constexpr static int TYPE_MENU_EVENT = 1;
	constexpr static int TYPE_CTRL_EVENT = 2;
	constexpr static int TYPE_ACCELL_EVENT = 2;
	
	uint type;
	uint id;
	window* source;

};




struct menu_handler : public _handler<pmf::MenuItemHandlerFunc>
{
	virtual LRESULT invoke(WPARAM wParam, LPARAM lParam)
	{		
		return InvokePMF(PObject, pmf, LOWORD(wParam));	
	}
};

//struct control_event_handler : public wm_handler<pmf::ConntrolEventHandlerFunc>
//{
//	virtual LRESULT invoke(WPARAM wParam, LPARAM lParam) override
//	{
//		return InvokePMF(PObject, pmf, reinterpret_cast<window*>(lParam), wParam);
//	}
//
//};

struct msg_handler : public _handler<pmf::WMHandlerFunc>
{
	virtual LRESULT invoke(UINT msg, WPARAM wParam, LPARAM lParam) 
	{
		return InvokePMF(PObject, pmf, poWinSource, msg, wParam, lParam);
	}

	window* poWinSource;
};

//struct MsgHandlerInfo
//{
//	virtual LRESULT invoke(WPARAM wParam, LPARAM lParam)
//	{
//		return InvokePMF(PObject, pmf, wParam, lParam);
//	}
//	base *PObject;	
//	pmf::WMHandlerFunc pmf;
//	
//};

struct MenuItemgHandlerInfo
{
	base *PObject;
	pmf::MenuItemHandlerFunc pmf;
	LRESULT invoke(UINT uiID);
}; 

struct window_template
{
	window_template()
	{};

	window_template(window* _PParent, 
		string _strClassName,
		string _strCaption,
		DWORD _dwExstyle, DWORD _dwStyle,
		LPVOID _pParam = NULL,
		int _x = CW_USEDEFAULT,
		int _y = CW_USEDEFAULT,
		int _width = CW_USEDEFAULT,
		int _height = CW_USEDEFAULT,
		bool _bFollowParent = false
	) {
		PParentWindow = _PParent;
		strClassName = _strClassName;
		strCaption = _strCaption;
		dwExStyle = _dwExstyle;
		dwStyle = _dwStyle;
		pParam = _pParam;
		x = _x;
		y = _y;
		width = _width;
		height = _height;
		bFollowParent = _bFollowParent;
	};

	window* PParentWindow;
	string strClassName;
	string strCaption;
	DWORD dwExStyle, dwStyle;
	LPVOID pParam = NULL;
	int x = CW_USEDEFAULT;
	int y = CW_USEDEFAULT;
	int width = CW_USEDEFAULT;
	int height = CW_USEDEFAULT;
	bool bFollowParent = false;

};



class window :
	public base
{
	////////////////////////////////////////////////////////////////////////////////
//
//	** HWND **: and other variables
//
/////////////////////////////////////////////////////////////////////////////////
protected:
	string	m_strText;
	// Handle to Win32 Window Object
	sz		m_szText = NULL;;





	friend class control_group;
	friend class check_box_group;
	friend class event_handler_base;
	friend class dialog_box;

public:
	window()
	{

	}
	
	window(window* PParentWindow, window_template, int x_offset = 0, int y_offset = 0, int width_offset = 0, int height_offset = 0);






	// TODO: make so you can declare child windows with all parameteres in the parent class definition, 
	// TODO: set some (maybe temp) member vars and use the "createFromCopiedValues()" in children  and "createChildren()" in parent

	// fills the relevant variables with the needed info for when it should be created
	window(window* pParentWindow, LPCSTR szClassName,
		LPCSTR szCaption, DWORD dwExstyle, DWORD dwStyle, LPVOID pParam = NULL, int x = CW_USEDEFAULT, int y = CW_USEDEFAULT,
		int  width = CW_USEDEFAULT, int height = CW_USEDEFAULT, bool bFollowParent = false);


	virtual ~window();


	// creates a window object from an existing hwnd and extract all data from the HWND



	// cntrol_event_hanlder handlewr(buttom1, BN_CLICKED, DEST(process1, button1_handler));

	// DEST is macro that make dealing with member funtion pointers more straight forward.

	virtual LRESULT _createEx(window* pParentWindow, LPCSTR szClassName,
		LPCSTR szCaption, DWORD dwExstyle, DWORD dwStyle, LPVOID pParam, int x = CW_USEDEFAULT, int y = CW_USEDEFAULT,
		int  width = CW_USEDEFAULT, int height = CW_USEDEFAULT, bool bFollowParent = false);


	virtual LRESULT _createChildEx(window* pParentWindow, LPCSTR szClassName,
		LPCSTR szCaption, DWORD dwExstyle, DWORD dwStyle, LPVOID pParam, int x = CW_USEDEFAULT, int y = CW_USEDEFAULT,
		int  width = CW_USEDEFAULT, int height = CW_USEDEFAULT, bool bFollowParent = false);



	////////////////////////////////////////////////////////////////////////////////////////////
	//	Window Template functions
	////////////////////////////////////////////////////////////////////////////////////////////
public:
	// create the window from the INTERNAL template data without any changes
	virtual bool createFromInternalTemplate();

	// create the window from the INTERNAL template data BUT change the parent window pointer
	virtual bool createFromInternalTemplate(window* _PParent, int x = 0, int y = 0);


	// create the window from the EXTERNAL template data without any changes
	//bool _createFromTemplate(window_template wt);

	// create the window from the template data BUT change the parent window pointer
	//bool _createFromTemplate(window_template wt, window* _PParent);


	// TODO: Make sure this works, and does not interfere the core in _createEx()
	//bool _addToParentChildList();

	// TODO: finsish this, and make sure all children are created = it works
	// call the onCreate on the children
//	bool _createChildWindow();



	// TODO: write these:
	//virtual LRESULT _createFromCopiedValues() ;
	//virtual LRESULT _createChildren();

	// create the child windows with proper offset, if any


	//virtual LRESULT create_with_unique_wndproc(window* pParentWindow, LPCSTR szClassName,
	//	LPCSTR szCaption, DWORD dwExstyle, DWORD dwStyle, LPVOID pParam, int x = CW_USEDEFAULT, int y = CW_USEDEFAULT,
	//	int  width = CW_USEDEFAULT, int height = CW_USEDEFAULT);
public:	// // destroys the window

	virtual bool isEnabled();
	virtual bool enable(bool _bState, bool _bEnableChildren = true);	
	virtual bool enableChildren(bool _bState);

	// disables the window, so that bool enable(bool) can't enable the window
	virtual bool disable(bool bState, bool bDisableChildren = false);
	virtual bool disableChildren(bool _bState);
	
protected:
	bool m_bDisabled = false;
	bool m_bPrevEnable = true;
public:


	bool setMenu(menu *PMenu);

	virtual void setAllMessageandler()
	{

	}


	//LRESULT createFromHWND(HWND hwnd);

	////////////////////////////////////////////////////////////////////////////////
	//
	//							Operator ovcerloads
	//
	////////////////////////////////////////////////////////////////////////////////
public:
	operator HWND();
	operator POINT();
	operator string();
	
	//operator string&() {};
	//operator string*() {};
;
	operator LPSTR();
	operator LPCSTR();

	operator HDC();


	inline operator window*()
	{
		return this;
	}
	
	csz operator<< (csz szText) {

		return "";
	}


	csz operator>>(csz& szText) {

		return "";
	}

	virtual sz& operator=(csz& cszText);
	
	
	virtual string& operator=(const string& strValue);
protected:
	HWND& operator=(const HWND& rc);
	
	// get window ptr from HWND handle
	static window* _getWindowPtrFromHandle(HWND);
	
	// map to link HWND to window*
	static map<HWND, window*> sm_mapHandleToWindowPtr; 

public:
	void removeDestroyedFromMap(HWND);
	
protected:

	window* getWindowFromPoint(int x, int y);


public:
	////////////////////////////////////////////////////////////////////////////////
	//
	//							String operat�ons
	//
	////////////////////////////////////////////////////////////////////////////////	
	// set the window's tewxt with variable strText
public:
	virtual csz setText(const string strText);
	virtual sz setText(sz cszText);

	bool addText(const string strText);
	bool addText(csz cszText);
	virtual sz getText();
	
	// Set the text that appears when them mouse hovers
	string & setToolTipText(const string);


	//const string & operator= (const string & strValue);

	HDC getDC();

	window* f();
	/*inline HWND getParentHWND();
	inline window* getParent();*/

	
	void updateText();	   

	////////////////////////////////////////////////////////////////////////////////
	//
	//							Window dimension operations
	//
	////////////////////////////////////////////////////////////////////////////////	

	void setPos(int x, int y, int cx, int cy, HWND hwndInsertAfter = HWND_TOP, uint uiFlags = 0);
	void setPos(int x, int y, HWND hwndInsertAfter = HWND_TOP, uint uiFlags = 0);
	int setX(int x);
	int setY(int y);
	int getX();
	int getY();

	


	// Uses SetWindowLong to change the extended style of the window
	LONG setExStyles(DWORD dwSExStyles);
	LONG getExStyles();

	// Uses SetWindowLong to change the style of the window
	LONG setStyles(DWORD dwStyles);
	LONG getStyles();

	bool update();
	bool show(int iCmdShow = SW_SHOW);
	
	window* setFocus(bool _bIgnoreKeyStrokes = false);
		

	inline int x();
	inline int y();
	inline int width();
	inline int height();

	inline RECT getRect();


	RECT & getWindowRect();
	bool setWindowRect(RECT rc);


	void calculateExtendsOfChidlren() {
		// TODO get x,y,w,h values of the children that are closest to the edgde, that can be used to adjust the window bases on the child position and size
	}

	inline void setWidth(int width);
	inline void setHeight(int height);
	//inline bool setDim(int width, int height);

	void moveClientArea(int x, int y, int cx, int cy, bool bRepaint = true);
	void resizeClientArea(int cx, int cy, bool _bMenu = false);
	void resizeClientAreaRelatively(int dx, int dy, int dcx, int dcy, bool  bRepaint = true); // resize the from any side a the user can

	const RECT & getClientRect();
	
	void resize(int cx, int cy, HWND hwndInsertAfter = HWND_TOP, uint uiFlags = 0);
	void resizeRelatively(int dx, int dy, int dcx, int dcy, HWND hwndInsertAfter = HWND_TOP, uint uiFlags = 0);

	
	// TODO: make this work:
	// call from a child window that recently has been moved and/or resized
	// so the parent window can adjust its "virtual client area size" variables
	//void informOfNewDimensions();

	

	void followParentDimensions(int offset_x, int offset_y, int offset_width, int offset_height);
		BOOL setPositionAndSize(
		window* pWndInsertAfter,
		int  X,
		int  Y,
		int  wwith,
		int  height,
		UINT uFlags
	);

	//BOOL moveAndResize(bool bRepaint = true);
//	BOOL moveAndResize(RECT_XY PositionAndSize, bool bRepaint = true);

		//void informParrentOnSizeChange(int _x, int _y, int, int _width, int _height_);
	
	void getDimensions();
		
	void updateDimensions();

	BOOL moveAndResize(bool bRePaint);

	BOOL move(int x, int y, int width, int height, bool bRepaint = true);

public:
	RECT & getClientRect(RECT* prcClientRect);

	bool getDialogItem(window*, int _id);
	bool exitDialog(INT_PTR);

public:

	// link windows on the "child level) so the reize togethether
	void linkToWindows(window* PWinLeft, window* PWinTop, window* PWinRight, window* PWinBottom);
	
	

	////////////////////////////////////////////////////////////////////////////////////
	//	Containter (map/vector)methods
	//////////////////////////////////////////////////////////////////////////////////////////
protected:
	bool addChildWindowPtrToMap(string strId, window* PChild);
	window* getChildWindowPtrFromMap(string strId);



	void _addChildToCreate(window* _PChildWindow);
	void _createChildren(window* PParent = NULL, int x = 0, int y = 0);

public:
	void handleMenuItem(UINT id, base* object, pmf::MenuItemHandlerFunc pmf);
	


	// uses event_handler class to call any method in any class when a menu item is selected
	

	


	//template <class CLASS>
	//void setMenuItemHandler(CLASS* C, LRESULT (CLASS::*classMeberFunction1)(UINT message, WPARAM wPAram, LPARAM lParam));

	
	//static window* getWindowObjectFromHWND(HWND hHandle);
	//static bool setAssociateHWNDWithWindowObject(�INT uiMenItemnId, HWND hHandle, window* PWindow);
	
	

protected:
	// redefinable methods for processing the WM_ messages
	//virtual bool processWM_COMMAND(WPARAM wParam, LPARAM lParam);	
	//virtual bool processMenuEvents(UINT uiId);
	//virtual bool processControlEvent(word wNotificationCode, word wControlId, window* PControl);	
	//virtual bool processAccellerator(UINT uiId);

protected:
	static LONG putThisIntoWindowMemory(HWND _HWND, window* PWindow);
	static window* getThisFromWindowMemory(HWND h);
	
public:
	void handleMessage(UINT uiMessage, base* POJect, pmf::WMHandlerFunc);
	
protected:
	LRESULT invokeMessageHandler(UINT uiMessage, WPARAM wParam, LPARAM lParam);
	   
protected:

	LRESULT processWM_SIZE_linked_windows(WPARAM wParam, LPARAM lParam);


	
	
	virtual LRESULT process_MenuEvent(UINT uiID);
	virtual LRESULT process_AcceleratorEvent(UINT uiID);
	
	virtual LRESULT t_process_MenuEvent(UINT uiId);


	/*************************************************************************************************
	method:		t_process_ControlEvent -		method for processing events from child controls

	parm:		UINT uiNotification -		A code the signal what kins of event (click, ...., etc)
	parm:		UINT uiID -					The id (integer) of the control in questioin (not used)
	parm:		HWND hwndControl		The window handle of the control (used for search/handling)
	*************************************************************************************************/
	virtual LRESULT t_process_ControlEvent(UINT uiNotification, UINT uiID, HWND hwndControl);

	
		// INTERNAL WM_ command handlers
 
protected:
	window_class m_wcUsing;

	HWND m_hHandle = NULL;;

	HWND m_hwndInsertAfter = HWND_TOP;
	//PMFMessageHandler m_pmf = &this::case_wm_CREATE();
	static thread_local_data<window*, NULL> sm_PTempThis;

	static map<DWORD, window*> sm_PTempThisList;

public:
	static window* sm_PMainWindow;
protected:
	window_template m_template;	

	struct _last_msg
	{
		HWND _HWND;
		UINT uiMsg;		
		WPARAM wParam;
		LPARAM lParam;
	} m_last_message;

	bool m_bCreateFromInternalTamplate = false;
	bool m_bCreateByParent = false;
	bool m_bCoordinatesValid = false;
	bool m_bIsDebugguing = false;

	//map < UINT, _wm_handler> m_mapMessagedHandlers;
	map<UINT, MenuItemgHandlerInfo> m_mapMenuEventHandlers;

	

	
	sz		m_pszTempText = NULL;;
	
	dword	m_dwTextLength = 0;
	dword	m_dwTemTextLength = 0;
	
	window* m_poParentWindow;
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//		Font stuff
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
	HFONT m_hFont = NULL;
public:
	font oFont;
public:
	static HFONT hDefaultFont;
	static font DefaultFont;
	operator HFONT();	
	operator font();	
	int getWidth();
	int getHeight();


protected:	
	// Used for linking windows in a GUI, when one linkedwindow is resized to the right,
	// tne linked window to its right is reiszed from left to right and so on
	window* m_PLinkedWindowLeft = nullptr, *m_PLinkedWindowTop = nullptr, *m_PLinkedWindowRight = nullptr, *m_PLinkedWindowBottom = nullptr;
	bool m_bControlLeft = false, m_bColtrolTop = false, m_bControlRight = false, m_bControlBotoom = false;
	// list of child window the folow their parent when resizing;
	vector<window*>		m_vecFollowParent;          

	int m_x, m_y, m_width, m_height;
	int m_client_x, m_client_y, m_client_width, m_client_height;
	
	int m_offset_x, m_offset_y, m_offset_width, m_offset_height;
	bool m_bFolowParentDimensions = false;	

	RECT m_rcClienRect;
	RECT m_rcWindowRect;

	//virtual LRESULT WM_TEST(WPARAM wParam, LPARAM lParam);

	                           
	//static map<HWND, window*> m_mapHWNDToWindowPtr;	
	//static map<string, window*> m_mapStringToWindowPtr;

	map<string, window*> m_mapString_ChildWindowPtr;

	map<UINT, bool> m_mapMesagToBool;

	// is this map tne derived form "template <clasa C > event_handler {}" is added,
	// so that the handler can call any method in any class
	//map<UINT, event_handler_base*> m_mapMenuEventHandlers;

	map<HWND, window*> m_mapChildHandleToWindowPtr;
	
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//
	//		Dynamic message handler stuff
	//
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

public:
	static void bindHandlerToControlEvent(window* _poSource, uint uiEventId, base* _po, pmf::ControlEventHandler pmfHandlerFunc);
	
	template <class C>
	static void t_bindHandlerToControlEvent(window* _poSource, uint uiEventId, C* _po, typename tpmf<C>::MsgFunc pmfHandlerFunc);

	template <class C>
	void t_bindHandlerToWM (window* _poSource, uint uiMsg, C* _po, typename tpmf<C>::MsgFunc pmfHandlerFunc);

	template <class C>
	static void t_bindHandlerToMenuEvent(uint _Id, C * _po, typename tpmf<C>::MsgFunc _pmfHandlerFunc);
	
	 
	void bindHandlerToWM(window* _poSoucrl, uint uiMesageId, base* _po, pmf::WMHandlerFunc _pmf);

protected:
		// map-map to connent a control event to a function
		static map<window*, map<UINT, _handler_base*>> sm_t_mapControlEventHandlers;

		map<window*, map<UINT, _handler_base*>> sm_t_mapWmEventHandlers;

		static map<UINT, _handler_base*> sm_t_menuEventHandlers;

public:	

	bool useDynCtrlRetVal(bool bState = true);
	bool isUsingDynCtrlRetVal();

	bool useDynMsgRetVal(bool btate = true);
	bool isUsingDynMsgRetVal();

protected:
	bool m_bUseDynamicMsgHandleValue = false;
	bool m_bUseDynamicCtrlHandleValue = false;
	
	LRESULT t_processMessageEvent(HWND hwndDest, UINT msg, window* _poWIndDest, WPARAM wParam, LPARAM lParam)
	{
		/*m_oWmMessage.hwndSource = *this;
		m_oWmMessage.type = event_info::type::wm_event;
		m_oWmMessage.uiMessage = msg;
		m_oWmMessage.poSourceWindwow = this;
		m_oWmMessage.wParam = wParam;
		m_oWmMessage.lParam = lParam;
		m_oWmMessage.uiNotifyCode = 0;*/

		uint m = WM_COMMAND;
		map<HWND, window*>::iterator it_window = sm_mapHandleToWindowPtr.find(hwndDest);
		
		if (it_window == sm_mapHandleToWindowPtr.end())
			return  0;

		window* poWindowSource = it_window->second;
		
		map<window*, map<UINT, _handler_base*>>::iterator it_msg_map = sm_t_mapWmEventHandlers.find(it_window->second);
		
		if (it_msg_map == sm_t_mapWmEventHandlers.end())
			return  0;


		
 		map<UINT, _handler_base*>::iterator it_msg_handler  = it_msg_map->second.find(msg);
		if (it_msg_handler == it_msg_map->second.end())
			return  0;

		m_oLastMessage.uiNotifyCode = 0;
		m_oLastMessage.uiMenuItemId = 0;
		// invoke the handler			   	
		return it_msg_handler->second->invoke_WM(&m_oLastMessage);
	}
	

	// Button1.ctrlEvent(BN_CLICKED) >> this_app(&test_app::button1_clicked);
	//
	// event_info & window::ctrlEvent(UINT uiId);
	//
	// wm_handler_base & base::operator()(pmf::ctrlHandler)
	//
	// wm_handler_base & event_info::operator>>(wm_handler_base & wmhb)

	window_message m_oWmMessage;	


public:

	struct event_info
	{
	public:
		event_info()
		{

		}
		event_info(window* _poSoure, int _type, UINT  _uiId);
		
		event_info(window* _poSoure, UINT window_message) {

		}
		
		//
		//template <class T>
		//__handler<T>  operator>>(__handler<T>  _handlerCtrlEvent)
		//{

		//	//window* pSource = this->poSource;
		//	//UINT ID = uiId;

		//	TODO: tidy up this

		//	window::bindHandlerToControlEvent(poSource, uiId, _handlerCtrlEvent.PObject, _handlerCtrlEvent.pmf);

		//	return _handlerCtrlEvent;
		//}





		_handler_base  operator>>(_control_event_handler  _handlerCtrlEvent)
		{
		
			//window* pSource = this->poSource;
			//UINT ID = uiId;

			// TODO: tidy up this

			window::bindHandlerToControlEvent(poSource, uiId, _handlerCtrlEvent.PObject, _handlerCtrlEvent.pmf);

			return _handlerCtrlEvent;		
		}

		template <class C>
		_handler_base operator>>(t_handler<C, typename tpmf<C>::MsgFunc> * po)
		{

			//window* pSource = this->poSource;
			//UINT ID = uiId;

			// TODO: tidy up this

			// TODO: make this work for all event types
			switch (type)
			{
				case type::wm_event: {
					this->poSource->t_bindHandlerToWM(this->poSource, this->uiId, po->poHandlerObject, po->poMsgHandlerFunc);
				}
				break;

				case type::control_event: {
					window::t_bindHandlerToControlEvent(this->poSource, this->uiId, po->poHandlerObject, po->poMsgHandlerFunc);
				}
				break;
				/*case type::menu_event: {
					window::t_bindHandlerToMenuEvent(this->uiId, po->poHandlerObject, po->poHandlerFunc);
				}
				break;*/
			}	
			
			
				
			

			
			
				
			return *po;
		}


		template <class C>
		_handler_base operator=(t_handler<C, typename tpmf<C>::MsgFunc> * po)
		{

			//window* pSource = this->poSource;
			//UINT ID = uiId;

			// TODO: tidy up this

			// TODO: make this work for all event types
			switch (type)
			{
			case type::wm_event: {
				this->poSource->t_bindHandlerToWM(this->poSource, this->uiId, po->poHandlerObject, po->poMsgHandlerFunc);
			}
								 break;

			case type::control_event: {
				window::t_bindHandlerToControlEvent(this->poSource, this->uiId, po->poHandlerObject, po->poMsgHandlerFunc);
			}
									  break;
									  /*case type::menu_event: {
										  window::t_bindHandlerToMenuEvent(this->uiId, po->poHandlerObject, po->poHandlerFunc);
									  }
									  break;*/
			}








			return *po;
		}



		_wm_handler  operator>>(_wm_handler  _handlerWM)
		{
				poSource->bindHandlerToWM(poSource, uiId, _handlerWM.PObject, _handlerWM.pmf);

			return _handlerWM;

		}
		
		operator csz()
		{
			return "Test";
		}

		static class type {
			public:
			static constexpr int invalid = 0;
			static constexpr int wm_event = 1;
			static constexpr int menu_event = 2;
			static constexpr int control_event = 3;
			static constexpr int notify_event = 4;
		};		
		
		int type = type::invalid;

		window* poSource = nullptr;
		HWND hwndSource = NULL;

		
		UINT uiId = 0;

		
	

	event_info m_event_info_temp;

	

	//event_info _wm_handlder = event_info(this, event_info::type_wm_event);
	event_info m_menu_event_info;
	event_info m_ctrl_event_info;
	event_info m_wm_event_info;

	// returns info on a window message

	event_info & sys_menu_event(UINT _MenuItemId)
	{
		m_menu_event_info.type = event_info::type::menu_event;
		m_menu_event_info.poSource = NULL;
		m_menu_event_info.uiId = _MenuItemId;

		return m_wm_event_info;



	event_info & menu_event(UINT _MenuItemId)
	{
		m_menu_event_info.type = event_info::type::menu_event;
		m_menu_event_info.poSource = NULL;
		m_menu_event_info.uiId = _MenuItemId;

		return m_wm_event_info;
	}



	event_info & WM_Event(UINT _uiMessageId)
	{
		

		m_wm_event_info.type = event_info::type::wm_event;
		m_wm_event_info.poSource = this;
		m_wm_event_info.uiId = _uiMessageId;


		

		return m_wm_event_info;
	}

	event_info & operator()(UINT _uiMessageId)
	{

		m_wm_event_info.type = event_info::type::wm_event;
		m_wm_event_info.poSource = this;
		m_wm_event_info.uiId = _uiMessageId;


 		return m_wm_event_info;
	}
	
	
	event_info & ctrlEvent(UINT _uiId)
	{
		m_ctrl_event_info.type = event_info::type::control_event;
		m_ctrl_event_info.poSource = this;
		m_ctrl_event_info.uiId =_uiId;

		return m_ctrl_event_info;
	}

	event_info & Clicked()
	{
		m_ctrl_event_info.type = BN_CLICKED;
		m_ctrl_event_info.poSource = this;

		return m_ctrl_event_info;
	}



	
	
	public:
		LRESULT test_func(window* _poWndCtrl, UINT uiEventId);
	

	

	


protected:	
	//static map<window*, map<UINT, _control_event_handler*>> sm_mapControlEventHandlers;

	



	// TODO: make suer this works
	std::vector<window*> m_vecChildren;

	// TODO: make suer this works
	std::vector<window*> m_vecChildrenToBeCreated;
	// The callback function  that handles messages
	//static LRESULT CALLBACK W�ndowProcedure(HWND hWindow, UINT message, WPARAM wParam, LPARAM lParam);;
	
	// a mao that connect 
	//static map<hwnd, windows*> sm_mappHandleTOWindowss:

	static window* sm_pCurrentThis;
	static window* sm_pTempThis;
	static bool sm_bThreadLocked;

	WNDPROC ptrNewWindowProcedure;
	static LRESULT CALLBACK _WndProc(HWND hWindow, UINT message, WPARAM wParam, LPARAM lParam);

	// the redefineable window proceure called from the static one
	virtual LRESULT CALLBACK ClassWindowProcedure(HWND _HWND, UINT message, WPARAM wParam, LPARAM lParam);
/********************************************************************************************
	Internal window message handlers
*********************************************************************************************/
protected: // TODO: maybe make public, so I can be reached by pointer from a base class object
	public:
	// handles its own notification, that is sent back to it
	virtual LRESULT processOwnNotification(UINT uiNotificationCode);		


	
protected:
	/* if relevant redirect to control's caseWM_COMMAND or caseWM_NOTIFY, it will check if the conmtrol hwnd is the same as its own,
	 and if so know that the command/notifications is itself for it and handle it.*/	
		
	

	

	virtual LRESULT case_WM_CREATE(CREATESTRUCT* pCS);	
	

	

	//virtual LRESULT case_WM_PAINT();

	virtual LRESULT case_WM_COMMAND(word wCode, word wId, HWND hwndCtrl);
	
	virtual LRESULT case_WM_MOVE(WPARAM wParam, LPARAM lParam);
	
	virtual LRESULT case_WM_NOTIFY(NMHDR* pmnh);

	virtual LRESULT case_WM_SIZE(WPARAM wParam, LPARAM lParam);	
	
	virtual LRESULT case_WM_CLOSE();
	
	virtual LRESULT case_WM_CHAR(WPARAM wParam, LPARAM lParam);

	virtual LRESULT case_WM_PAINT();

	virtual LRESULT message_handler(WM_ERASEBKGND, HDC hdc);

	

//*********************************************************************************************************
//		Virtual Window creation, error and destruction methods
//**********************************************************************************************************
protected:
	static void displayErrorBoxAndQuit(int _exit_code = -1, const string _strTitle = "", const string _strDescription = "");
	virtual bool onCreated();
	virtual bool setupMenu();
	virtual bool setupHandlers();
	virtual bool onClose();
	virtual void onQuit();

	virtual void onError();

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//		Send Messages, set LONG
////////////////////////////////////////////////////////////////////////////////////////////////////////////
public:
	LONG setLongPtr(int index, LONG _value);
	LONG getLongPtr(int index);
	// Set the font for the witn

	font & operator()(font & _roFont, bool bResizeToText = false, int x_offset = 0, int y_offset = 0);
	
	bool setFont(HFONT hFont = NULL, bool nRedraw = true);
	// sends a message to the message loop
	LRESULT sendMessage(UINT uiMsg, WPARAM wParam, LPARAM lParam);
	
	// Sends a message and return without wait for the klmessage to be processed
	LRESULT postMessage(UINT uiMsg, WPARAM wParam, LPARAM lParam);
	LRESULT postQuitr(int _exit_code);

protected:
	window_message m_oLastMessage;
	CREATESTRUCT m_oLastCreateStruct;

public:
	font* m_poFont;
	
	

	menu* pMenu1 = nullptr;
	menu* pMenu2 = nullptr;
	menu* pMenu3 = nullptr;

	//menu_item m_file = { "File" };
	// Get the SCREEN dimensions of the window
	bool getScreenRect(RECT* pRECT);
	// get the screen x, y for the window
	POINT getScreenPos();

public:

	number_property<int> X = decl_number_property_2(int, getX(), setX(_int));
	number_property<int> Y = decl_number_property_2(int, getY(), setY(_int));
	
	number_property<int> Width = decl_number_property_2(int, getWidth(), setWidth(_int));
	number_property<int> Height = decl_number_property_2(int, getHeight(), setHeight(_int));
	
	
	/*number_property<int> X = number_property<int>(
		[this]() {return getX(); },
		[this](int x) {setX(x); }
	);
*/
	//number_property<int> Y = number_property<int>(
	//	[this]() {return getY(); },
	//	[this](int y) {setY(y); }
	//);

	//number_property<int> Width = number_property<int>(
	//	[this]() {return getWidth(); },
	//	[this](int _width) {setWidth(_width); }
	//);
/*
	number_property<int> Height = number_property<int>(
		[this]() {return getHeight(); },
		[this](int _height) {setHeight(_height); }
	);
*/








	decl_number_property(bool, Enabled, isEnabled, enable);


	number_property<RECT> WindowRect = number_property<RECT>(
		[this]() {return getWindowRect(); },
		[this](RECT rc) {setWindowRect(rc); }
	);



	_string_property Caption = _string_property(
		[this]() { return getText(); },
		[this](csz _csz) { setText(_csz); }
	);

	number_property<HDC> hDC = number_property<HDC>(
		[this]() { return getDC(); },
		[this](HDC h) { int i = 0; }
	);




};

// TODO: Make this work as collection of window you group togethter, that has the same parent, and can be created, drawn and changed together
struct window_collection
{
	window_collection(window* PWindowThis)
	{
		PParent = &PWindowThis;	
	}

	//window* pw = PParent;

protected:

	// TODO: use this pointer to pointer to make sure your have the right pointer even if it changes value
	window** PParent = NULL;
private:
	window_collection() {};



};


//window_collection a(NULL);




template <class T>
class thread_safe_variable
{
public:
	T read()
	{
		if (m_bIsLocked)
			while (m_bIsLocked);

		m_bIsLocked = true;
		return m_varible;
		m_bIsLocked = false;	
	}


protected:
	bool m_bIsLocked;
	T m_varible;


	
};

// TODO: make this work !!!!



template<class C>
inline void window::t_bindHandlerToControlEvent(window * _poSource, uint uiEventId, C * _po, typename tpmf<C>::MsgFunc pmfHandlerFunc)
{

	t_handler < C, tpmf<C>::MsgFunc> * pceh = new t_handler<C, tpmf<C>::MsgFunc>;

	pceh->poMsgHandlerFunc = pmfHandlerFunc;
	pceh->poHandlerObject= _po;


	map<window*, map<UINT, _handler_base*>>::iterator it1 = sm_t_mapControlEventHandlers.find(_poSource);
	if (it1 == sm_t_mapControlEventHandlers.end()) // is the control already in the map?
	{ // no, so put it there
		sm_t_mapControlEventHandlers[_poSource][uiEventId] = pceh;
	}
	else
	{
		// add this new event to handler
		it1->second[uiEventId] = pceh;
	}


	// Check if the control is in the first map, if yes, put this new event int the second map
	// if not add it to a temp 2nd map
	// and add that temp 2nd map to the first map

	





}

template<class C>
inline void window::t_bindHandlerToWM(window * _poSource, uint uiMsg, C * _po, typename tpmf<C>::MsgFunc _pmfHandlerFunc)
{
	t_handler<C, tpmf<C>::MsgFunc> * pceh = new t_handler<C, tpmf<C>::MsgFunc>;

	pceh->poMsgHandlerFunc = _pmfHandlerFunc;
	pceh->poHandlerObject = _po;
	pceh->poWindowSource = _poSource;
	

	map<window*, map<UINT, _handler_base*>>::iterator it1 = sm_t_mapWmEventHandlers.find(_poSource);	
	if (it1 == sm_t_mapWmEventHandlers.end()) // is the window already in the map?
	{ // no, so put it there
		sm_t_mapWmEventHandlers[_poSource][uiMsg] = pceh;
	}
	else
	{
		// yes, so add this new event to handler
		it1->second[uiMsg] = pceh;
	}



}

template<class C>
inline void window::t_bindHandlerToMenuEvent(uint _Id, C * _po, typename tpmf<C>::MsgFunc _pmfHandlerFunc)
{
	t_handler < C, tpmf<C>::MsgFunc> * pceh = new t_handler<C, tpmf<C>::MsgFunc >;
	
 	pceh->poHandlerObject = _po;
	pceh->poMsgHandlerFunc = _pmfHandlerFunc;

	sm_t_menuEventHandlers[_Id] = pceh;

}

static window* g_pWin;
