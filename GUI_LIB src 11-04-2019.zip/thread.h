#pragma once

// #include "stdafx.h"
#include "base.h"

class runnable : public base
{
public:
	virtual DWORD run() = 0;
};

template <class T, DWORD ID>
struct thread_local_storage
{
	thread_local_storage(ID)
	{
		dwId = ID;
	}
	
private: // make sure the default constructor is not used
	thread_local_storage() {};
public:	
	const DWORD dwId;
	map<DWORD, T> m_IDToStorage;
};

 
class thread : public runnable
{
public:

	thread();

	void _captureCurrentThread();

	bool _createEx(runnable* PRunnable, DWORD dwFlags = 0,
						SIZE_T dwStackSize = 0, LPSECURITY_ATTRIBUTES pThreadAttributes = NULL);
	
	bool _createEx(base * PObject, pmf::ThreadHandlerFunc pmf, DWORD dwFlags = 0,
						SIZE_T dwStackSize = 0, LPSECURITY_ATTRIBUTES pThreadAttributes = NULL);	
	
	bool _createEx(DWORD dwFlags = 0, SIZE_T dwStackSize = 0, LPSECURITY_ATTRIBUTES pThreadAttributes = NULL);

	static thread* getPtrFromCurrentId();

	static thread* getPtrFromId(dword);
	static thread* getPtrFromHandle(dword);

public:
	window * m_mainWindow = nullptr;


	virtual DWORD run();

protected:

	static DWORD WINAPI  _winapi_thread_funct�on(LPVOID pVOID); 	
	
	LPSECURITY_ATTRIBUTES   m_pThreadAttributes;
	
	
	bool m_bRunInternalFunction = false;
	// run this if not null
	runnable* m_pRunnable = NULL;
	
	// else run this if not null
	base* m_PFMObjec = NULL;
	pmf::ThreadHandlerFunc m_pmfFunc = NULL;;
public:
	DWORD getId();
	HANDLE getHandle();
	
	// handler_function<WPARAM, LPARAM> HWindowMessage;
	operator DWORD();

	operator HANDLE();


	static DWORD getCurrentId();
	
	static HANDLE getCurrentHandle();
protected:
	static map<HANDLE, thread*>* sm_pmapHanndToPtr;
	static map<DWORD, thread*>* sm_pmapIdToPtr;

private:
	HANDLE m_hHandle;
	DWORD  m_dwId;
};

//DWORD WINAPI __winapi_thread_funct�on(LPVOID pVOID);

class test_thread : public thread
{
public:
	DWORD run()
	{
		Sleep(10 * 1000);
		bGo = true;
		return 0;
	}

	bool bGo = false;

	int counter;
};
