// #include "stdafx.h"
#include "Definitions.h"


int exitProgram(string message, int exit_code);

int writeDebugMessage(string message);




int writeDebugMessage(string message)
{
	OutputDebugStringA(message.c_str());

	return 1;
}




void _CopySZ(char * dest, const char * source)
{	
	// TODO check at dette virke
	asm_mem_copy(dest, source, strlen(source)+1);
	//memcpy(dest, source, strlen(source));
}

std::string _IntoStr(long l)
{
	std::string strTemp;
	char buffer[255];
	strTemp = _itoa_s(l, buffer, 10);
	
	return strTemp;

}
