// #include "stdafx.h"
#include "static_text.h"



static_text::static_text()
{
}

/*tatic_text::static_text(window * _pPparent, string strStatic, string strDescription,int x, int y, int width, int height)
  : window(_pPparent, WC_EDIT, strStatic.c_str(), 0, WS_DISABLED, NULL, x, y, width, height)
{
}*/


static_text::~static_text()
{
}



csz static_text::setText(const string strText)
{
	SIZE size;

	HDC hdc = GetDC(*this);

	SelectObject(hdc, m_hFont);

	if (strText.size() == 1)
	{
		string strTemp = strText;
		strTemp += ' ';
		GetTextExtentPoint32(hdc, strTemp.c_str(), strTemp.size(), &size);
	}
	else
		GetTextExtentPoint32(hdc, strText.c_str(), strText.size(), &size);

	m_cx = size.cx;
	m_cy = size.cy;

	move(m_x, m_y, m_cx+6, m_cy+4);

	return window::setText(strText);
}

bool static_text::create(window * _poPparent, string strStatic, string strDescription, int x, int y, bool bDescritpionOntop, uint styles)

{
	// create the disbaled edit boc with info
	
	//(*this)(m_oFont);
	bool b = (0 != _createChildEx(_poPparent,WC_EDIT, strStatic.c_str(),  WS_EX_STATICEDGE, WS_DISABLED, NULL, x, y, 80, 180));
	if (!b)
		return  b;
	

	// selec the default font
	


	SIZE size;

	HDC hdc = GetDC(*this);

	
	setFont(DefaultFont);
	

	SelectObject(hdc, DefaultFont);

	this->setText(strStatic.c_str());

	if (strDescription.size() > 0)
		b = createDescription(_poPparent, strDescription.c_str(), bDescritpionOntop);

	return b;

}

bool static_text::createDescription(window * _poPparent, string strDescription, bool bOnTop, int x_offset, int y_offset)
{ 
	bool b = (0 != Describtion._createChildEx(_poPparent, WC_EDIT, strDescription.c_str(), WS_EX_STATICEDGE , WS_DISABLED, NULL,
						m_x + x_offset, m_y + y_offset, m_width, m_height));
	if (!b)
		return  b;

	HDC hdc = Describtion.hDC;

	

	SIZE size;
	
	SelectObject(hdc, DefaultFont);

	GetTextExtentPoint32(hdc, strDescription.c_str(), strDescription.size()+1, &size);

	SIZE size2;
	GetTextExtentPoint32(hdc, strDescription.c_str(), strDescription.size()+1, &size2);

	if (bOnTop)
		return Describtion.move(m_x, m_y - (m_cy), size.cx, size.cy+4);	
	return  Describtion.move(m_x - (size2.cx), m_y, size.cx, size.cy+4);
}

