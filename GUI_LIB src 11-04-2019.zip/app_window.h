#pragma once
// #include "stdafx.h"
#include "frame_window.h"

class app_window :
	public window
{

	friend class app;
public:

	
	

	app_window(string strCpation, dw dwExStyle, dw dwStyle,
		int x = CW_USEDEFAULT, int y = CW_USEDEFAULT,
		int width = CW_USEDEFAULT, int height = CW_USEDEFAULT, bool bFollowParent = false

	) : window(NULL, WC_DEFAULT, strCpation.c_str(), dwExStyle, dwStyle, NULL, x, y, width, height, bFollowParent)
	{
		  
		 
	};
	
	app_window* operator()(string strCpation, dw dwExStyle, dw dwStyle,
		int x = CW_USEDEFAULT, int y = CW_USEDEFAULT,
		int width = CW_USEDEFAULT, int height = CW_USEDEFAULT);

	bool create(const string strCaption, int x = CW_USEDEFAULT, int y = CW_USEDEFAULT, int width = CW_USEDEFAULT, int height = CW_USEDEFAULT);

	
	static app_window* f;

	virtual LRESULT onSystemClose() override
	{
		destroy();
		return postQuit(4);
	}

	virtual ~app_window() {};

	app_window();
};
//app_window* app_window::sm_PMainWindow = nullptr;
;