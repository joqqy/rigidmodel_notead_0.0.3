// #include "stdafx.h"
#include "tree_view.h""
#include <commctrl.h>

#define WS_TVSTYLE1 WS_VISIBLE | WS_CHILD | WS_BORDER | TVS_HASLINES | TVS_EDITLABELS

//bool tree_view::create(RECT rcClientArea)
//{
//	InitCommonControls();
//	HWND hwnd1;
//	//*this = hwnd;
//}

bool tree_view::_createEx(window * PParentWindow, int x, int y, int width, int height)
{
//void delteItem(hitem, HTREEITEM);{

	//m_hHwnd = CreateWindowEx(0,
	//	WC_TREEVIEW,
	//	"test",
	//	WS_VISIBLE | WS_CHILD | WS_BORDER | TVS_HASLINES | TVS_EDITLABELS,
	//	0,
	//	0,
	//	400,
	//	400,
	//	*PParentWindow,
	//	(HMENU)m_uiId,
	//			H_INST,
	//			NULL);
	
	window::_createEx(PParentWindow, NULL, "Child1", WS_EX_COMPOSITED, WS_CHILD  | WS_CAPTION | WS_THICKFRAME | WS_HSCROLL | WS_VSCROLL | WS_CLIPCHILDREN, NULL, 50, 50, 250, 250);
	
	m_tree_view_window._createEx(this,  WC_TREEVIEW, "test", WS_EX_WINDOWEDGE | TVS_EX_DOUBLEBUFFER,  WS_CHILD  | TVS_EDITLABELS | WS_BORDER  | TVS_TRACKSELECT | WS_THICKFRAME |  LVS_EX_DOUBLEBUFFER,
		NULL,
		30,
		30,
		width-30,
		height-30);

	
	



	

	//pMenu1->TrackPopup(*PParentWindow, 200, 200);

	//TVINSERTSTRUCT tv;
	//tv.hParent = TVI_ROOT;
	//tv.hInsertAfter = TVI_ROOT;
	//
	//tv.itemex.mask = TVIF_TEXT;
	//tv.itemex.pszText = new char[5];
	//strcpy(tv.itemex.pszText, "Test");
	//tv.itemex.cchTextMax = 5;

	//tv.itemex.mask = TVIF_TEXT;
	//
	//tv.itemex.hItem = TreeView_InsertItem(m_hHwnd, &tv);


	//tv.hParent = TVI_ROOT;
	//tv.hInsertAfter = TVI_ROOT;

	//tv.itemex.mask = TVIF_TEXT;
	//tv.itemex.pszText = new char[5];
	//strcpy(tv.itemex.pszText, "Test");
	//tv.itemex.cchTextMax = 5;



	//tv.itemex.mask = TVIF_TEXT;

	//tv.itemex.hItem = TreeView_InsertItem(m_hHwnd, &tv);
	//
	//
	//TVITEM tvi;

	//tvi.mask = TVIF_STATE;  
	//tvi.stateMask = TVS_CHECKBOXES;
	////TreeView_SetItem(m_hHwnd, &tvi);





	//
	//tv.hParent = tv.itemex.hItem;
	//tv.hInsertAfter = TVI_FIRST;


	//
	//

	//tv.itemex.mask = TVIF_TEXT;
	//tv.itemex.pszText = new char[5];
	//strcpy(tv.itemex.pszText, "Hest");
	//tv.itemex.cchTextMax = 5;



	//tv.itemex.mask = TVIF_TEXT;

	//tv.itemex.hItem = TreeView_InsertItem(m_hHwnd, &tv);



	return true;
}

HTREEITEM tree_view::inserItem(HTREEITEM hParent, HTREEITEM hInsertAfter, string strText, LPARAM lParam)
{

	//TVINSERTSTRUCT tv;
	//tv.hParent = TVI_ROOT;
	//tv.hInsertAfter = TVI_ROOT;
	//
	//tv.itemex.mask = TVIF_TEXT;
	//tv.itemex.pszText = new char[5];
	//strcpy(tv.itemex.pszText, "Test");
	//tv.itemex.cchTextMax = 5;
		

	TVINSERTSTRUCT tv;
	tv.hParent = hParent;
	tv.hInsertAfter = hInsertAfter;
	
	tv.itemex.mask = TVIF_TEXT;
	tv.itemex.pszText = new char[5];
	strcpy_s(tv.itemex.pszText, 4, "Test");
	tv.itemex.cchTextMax = 5;

	tv.itemex.mask = TVIF_TEXT; // | ( lparam ? TVIF_PARAM : 0 );
	tv.itemex.pszText = new char[strText.length() + 1];
	strcpy_s(tv.itemex.pszText, strlen(tv.itemex.pszText), strText.c_str());
	tv.itemex.cchTextMax = strText.length() + 1;	

	tv.itemex.hItem = TreeView_InsertItem(m_tree_view_window, &tv);	

	

	

	
	return tv.itemex.hItem;

}

LRESULT tree_view::case_WM_NOTIFY(NMHDR * pNMHDR)
{

	//LPNMHDR pNMHDR = reinterpret_cast<LPNMHDR>(lParam);
	if (pNMHDR->code == NM_RCLICK) 
	{
	}

	switch (pNMHDR->code)
	{

	case TVN_ENDLABELEDIT:
	{

		LPNMTVDISPINFO ptvdi = reinterpret_cast<LPNMTVDISPINFO>(pNMHDR);

		if (ptvdi->item.pszText)
			return true;

		break;
	}

	case TVN_BEGINLABELEDIT:
	{
		return TRUE;

	}
	case NM_RCLICK:
	{
		TreeView_SelectItem(m_tree_view_window, NULL);
		/*HTREEITEM hItem = TreeView_GetNextItem(pNMHDR->hwndFrom, 0, TVGN_DROPHILITE);
		if (hItem)
			TreeView_SelectItem(pNMHDR->hwndFrom, hItem);
*/


		RECT rcScreen;

		POINT ptScreen = m_tree_view_window.getScreenPos();
		POINT ptCurcor;
		TVHITTESTINFO hit;


		GetCursorPos(&ptCurcor);




		hit.pt.x = ptCurcor.x - ptScreen.x;
		hit.pt.y = ptCurcor.y - ptScreen.y;

		ScreenToClient(m_tree_view_window, &ptCurcor);
		hit.pt.x = ptCurcor.x;
		hit.pt.y = ptCurcor.y;

		//hit.flags = TVHT_ONITEMLABEL;  // TVHT_ONITEM; // | TVHT_ONITEM | TVHT_ONITEMICON;// | TVHT_ONITEMINDENT;
		HTREEITEM hti_hit = TreeView_HitTest(m_tree_view_window, &hit);
		if (hti_hit && hit.flags == TVHT_ONITEMLABEL && hit.flags != TVHT_ONITEMRIGHT)
		{

			TreeView_SelectItem(m_tree_view_window, hit.hItem);
			char sz[255];
			TVITEM tvi;
			tvi.hItem = hit.hItem;
			tvi.pszText = sz;
			tvi.cchTextMax = 255;
			tvi.mask = TVIF_HANDLE | TVIF_TEXT;
			TreeView_GetItem(m_tree_view_window, &tvi); 

			GetCursorPos(&ptCurcor);
			//m_popup_menu = { 12342, sz, MF_STRING };
			m_popup_menu.TrackPopup(m_tree_view_window, ptCurcor.x, ptCurcor.y);
		}
		else
			TreeView_SelectItem(m_tree_view_window, NULL);
	
		//TreeView_SelectItem(m_tree_view_window, hit.hItem);

/*

		TVITEM tvi;
		
		char sz[255];



		tvi.hItem = hit.hItem;
		tvi.pszText = sz;
		tvi.cchTextMax = 255;
		tvi.mask = TVIF_HANDLE | TVIF_TEXT;
		TreeView_GetItem(m_tree_view_window, &tvi);*/

		return 1;


	}



	}
	return 0;

};



