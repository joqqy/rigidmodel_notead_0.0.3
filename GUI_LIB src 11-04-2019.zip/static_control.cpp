// #include "stdafx.h"
#include "static_control.h"



static_control::static_control()
{
}


static_control::~static_control()
{
}
