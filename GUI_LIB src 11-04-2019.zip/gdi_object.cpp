// #include "stdafx.h"
#include "gdi_object.h"

