#include "menu.h"
#include <winuser.h> 


struct __menu_item_input1
{
	UINT id;
	string strText;
	UINT flags;
};

struct __menu_item_input2
{
	string strText;
	UINT flags;
};





//map<string, menu_item*> menu::sm_mapStringIdToMenuItem;

//
//
//bool menu_item::create()
//{
//	if (m_hHandlePopup = CreateMenu())
//		return true;
//	else
//		return false;
//
//}
//
//bool menu_item::create(UINT uiFlags, UINT_PTR uIdorHandle, csz pNewItem, string strID)
//{
//	return false;
//}
//
//menu_item::menu_item()
//{
//	m_hHandleDropDown = CreateMenu();
//	m_hHandleMenu = CreateMenu();
//
//}
//
//bool menu_item::appendItem(UINT uiFlags, UINT_PTR uIdorHandle, csz pNewItem, string strID)
//{
//	AppendMenu(m_hHandleItem, uiFlags, m_uIDorHandle, pNewItem);
//}
//
//bool menu_item::appendTo(UINT uiFlags, UINT_PTR uIdorHandle, csz pNewItem, string strID)
//{
//	m_uiFlags = uiFlags;
//	m_uIDorHandle = uIdorHandle;
//	m_strMenuItem = pNewItem;
//
//	
//	m_mapStringToMenu.insert(pair<string, menu_item*>(strID, this));
//
//	AppendMenu(m_hHandlePopup, m_uiFlags, m_uIDorHandle, m_strMenuItem.c_str());
//
//	return false;
//}
//
//
//menu_item::operator HMENU()
//{
//	return m_hHandlePopup;
//}
//map<string, menu_item*> menu_item::sm_mapMenuBar;
//menu_item* menu_item::sm_PMenu;








menu::menu()
{
}

menu::~menu()
{
	if (m_hHandle)
		DestroyMenu(m_hHandle);
}

bool menu::createBar()
{
	bool b = (m_hHandle = CreateMenu()) != NULL ? true : false;
	return b;
}

bool menu::createPopUp()
{
	return (m_hHandle = CreatePopupMenu()) != NULL ? true : false;
}

bool menu::destroy()
{
	if (m_hHandle)
		return DestroyMenu;

	return true;	
}
//
//bool menu::appendItem(UINT uiFlags, UINT_PTR uIdorHandle, csz cszItemText, string strID)
//{
//	menu* PItem = new menu;
//
//	PItem->m_uiFlags = uiFlags;
//	PItem->m_uIDorHandle = (UINT_PTR)uIdorHandle;
//	PItem->m_strItemText = cszItemText;
//	PItem->m_strID = strID;	
//
//	m_mapStringToMenuItem.insert(pair<string, menu*>(PItem->m_strID, PItem));
//
//	DWORD size = m_mapStringToMenuItem.size();
//
//	//sm_mapStringIdToMenuItem.insert(pair<string, menu*>(PItem->m_strID, PItem));
//		
//	return true;
//}

bool menu::append(UINT uiFlags, UINT_PTR uIdorHandle, csz cszItemText)
{

	return true;
}
	
bool menu::insertItem(UINT uiFlags, UINT_PTR uIdorHandle, csz cszItemText)
{
	MENUITEMINFO mi;

	mi.cbSize = sizeof(MENUITEMINFO);
	mi.fMask = MIIM_ID | MIIM_STRING | MIIM_BITMAP;
	mi.fType = MFT_STRING;
	mi.fState = MFS_ENABLED;
	mi.wID = uIdorHandle;
	mi.hSubMenu = NULL;
	mi.hbmpChecked = NULL;
	
	// create a new string
	mi.dwTypeData = new char[strlen(cszItemText) + 1];
	

	strcpy_s(mi.dwTypeData, strlen(cszItemText),  cszItemText);
	

	//strcpy(mi.szTypeData, cszItemText);
	
	mi.cch = strlen(cszItemText) + 1;
	
	//mi.hbmpItem = (HBITMAP)LoadImage(H_INST, MAKEINTRESOURCE(IDB_BITMAP3), IMAGE_BITMAP, 16, 16, 0);
		
	mi.hbmpChecked = NULL; // LoadBitmap(H_INST, MAKEINTRESOURCE(IDB_BITMAP3));
	mi.hbmpUnchecked = NULL; // LoadBitmap(H_INST, MAKEINTRESOURCE(IDB_BITMAP3));
	bool b = InsertMenuItem(*this, uIdorHandle, false, &mi);
	return false;
}

//
//bool menu::updateBar(UINT uiFlags, csz cszItemText, string strID)
//{
//	m_hHandleBar = CreateMenu();
//	m_hHandleItem = CreateMenu();
//
//	m_uiFlags = MF_POPUP | uiFlags;
//	m_uIDorHandle = (UINT_PTR)m_hHandleItem;
//	m_strItemText = cszItemText;
//	m_strID = strID;
//
//	map<string, menu*>::iterator it = m_mapStringToMenuItem.begin();
//	
//	bool b;
//	while (it != m_mapStringToMenuItem.end())
//	{		
//		b = AppendMenu(m_hHandleItem, it->second->m_uiFlags, (UINT_PTR) it->second->m_uIDorHandle, it->second->m_strItemText.c_str());
//		if (!b) return b;
//
//		it++;
//	}
//	
//	b = AppendMenu(m_hHandleBar, m_uiFlags, (UINT_PTR) m_hHandleItem, m_strItemText.c_str());
//	if (!b) return b;
//
//
//}
//
//bool menu::updateItem(UINT uiFlags, csz cszItemText, string strID)
//{
//	//m_hHandleBar = CreateMenu();
//	m_hHandleItem = CreateMenu();
//
//	m_uiFlags = MF_POPUP | uiFlags;
//	m_uIDorHandle = (UINT_PTR)m_hHandleItem;
//	m_strItemText = cszItemText;
//	m_strID = strID;
//
//	map<string, menu*>::iterator it = m_mapStringToMenuItem.begin();
//
//	bool b;
//	while (it != m_mapStringToMenuItem.end())
//	{
//		b = AppendMenu(m_hHandleItem, it->second->m_uiFlags, (UINT_PTR)it->second->m_uIDorHandle, it->second->m_strItemText.c_str());
//		if (!b) return b;
//
//		it++;
//	}
//
//
//
//
//	/*b = AppendMenu(m_hHandleBar, m_uiFlags, (UINT_PTR)m_hHandleItem, m_strItemText.c_str());
//	if (!b) return b;
//*/
//
//}




bool menu::TrackPopup(HWND hwnd, int x, int y, UINT uiFlags, LPTPMPARAMS ptp)
{
	return TrackPopupMenuEx(*this, uiFlags,x, y, hwnd, ptp);
}


menu::operator HMENU()
{
	return m_hHandle;
}

bool menu::insertItem(menu_item * _pMenuItem)
{	_pMenuItem->m_hParentMenu = m_hHandle;
	_pMenuItem->m_oMenuItemInfo.cbSize = sizeof(IMEMENUITEMINFO);	
	
	
	
	
	
	
	_pMenuItem->m_oMenuItemInfo.fType = MFT_STRING;
	_pMenuItem->m_oMenuItemInfo.fState = MFS_ENABLED;




	MENUITEMINFO mi;
	mi.cbSize = sizeof(IMEMENUITEMINFO);
	mi.fMask = MIIM_ID | MIIM_STRING;
	mi.wID = 100;
	mi.dwTypeData = _pMenuItem->m_oMenuItemInfo.dwTypeData;
	//mi.cch = strlen(mi.dwTypeData) + 1;
	
	//text::makeCopyOfSZ();

	
	bool b = InsertMenuItem(m_hHandle, m_next_item_pos++, true, &_pMenuItem->m_oMenuItemInfo);


	string str = process::getLastErrorString();


	return  b;
}

bool menu::insertItem(uint _pos, menu_item * _pmenu)
{
	return InsertMenuItem(*this, _pos, true, &_pmenu->m_oMenuItemInfo);
}




// ***************************************** static members **********************************************

bool menu::sm_bMenuItemCreated = false;

uint menu::sm_uiNumberOfMenus = 0;


