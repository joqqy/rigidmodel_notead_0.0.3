#pragma once
// #include "stdafx.h"
#include "check_box.h"

class check_box_group :
	public check_box
{
public:
	check_box_group();
	check_box_group(window* pParentWindow, LPCSTR szCaption,

		DWORD dwExstyle, DWORD dwStyle, int x = CW_USEDEFAULT, int y = CW_USEDEFAULT,
		int  width = CW_USEDEFAULT, int height = CW_USEDEFAULT, bool bFollowParent = false

	);

	bool create(window* pParentWindow, LPCSTR szCaption,

		DWORD dwExstyle, DWORD dwStyle, int x = CW_USEDEFAULT, int y = CW_USEDEFAULT,
		int  width = CW_USEDEFAULT, int height = CW_USEDEFAULT, bool bFollowParent = false

	);


	virtual ~check_box_group();

	virtual LRESULT processOwnNotification(u32 uiID) override;


	void setAllChildren();
	
	void addChild(check_box* _poCheckBox);	
	
	u32 getCheckedNumber();
	
	virtual LRESULT case_WM_NOTIFY(NMHDR* pmnh) override;

	virtual LRESULT case_WM_COMMAND(word wCode, word wId, HWND hwndCtrl) override;


	

	virtual void onClick(check_box* _poCheckBox) override;



protected:
	vector<check_box*> m_vecCheckBoxList;

};

