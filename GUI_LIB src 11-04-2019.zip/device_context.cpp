// #include "stdafx.h"
#include "device_context.h"



device_context::device_context()
{
}


device_context::~device_context()
{
}
