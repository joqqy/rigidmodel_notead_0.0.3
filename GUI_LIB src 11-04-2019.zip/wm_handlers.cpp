// #include "stdafx.h"
#include "window.h"
#include "wm_handlers.h"
/**********************************************************************************************************
	[File:]		wm_handlers.h
	[Author:]	phazer
	[Created:]	02/11/2018 18:00
	[Edited:]	02/01/2019 20:17

	[Description:]
	External implementation of the of WM_ handlers of the class window

***********************************************************************************************************/

#define DefaultAction DefWindowProc(olast_msg._HWND, olast_msg.uiMsg, olast_msg.wParam, olast_msg.lParam)
#define _CASE(msg) case_##msg




////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	The methods called from witch the OOP WindowProcedure switch statement
////////////////////////////////////////////////////////////////////////////////////////////////////////////
//LRESULT window::_CASE(WM_CLOSE)()
//{
//
//	
//
//}

LRESULT window::case_WM_CREATE(CREATESTRUCT * pCS)
{
	return  DEF_WIN_PROC;
}


lr window::window_message_handler(WM_NCACTIVATE, bool state, LPARAM lp)
{
	return  DEF_WIN_PROC;
}

lr window::window_message_handler(WM_ACTIVATE, UINT state,  UINT min_state, HWND hwnd)
{
	HWND hwnd_source = m_oLastMessage.hwndSource;

		window* po = nullptr;
		if (hwnd_source)
		{
			po = _getWindowPtrFromHandle(hwnd_source);

			/*if (po)
				window::onActivate(state, min_state, hwnd);
			*/
			return DEF_WIN_PROC;
				/*if (po == thread::getPtrFromCurrentId()->m_mainWindow)
				{
					if (state)
						po->Caption = "Activated";
					else
						po->Caption = "Deactivated";
					
				
				
				}*/

				
				
						

		}
		return DEF_WIN_PROC;
	
}



LRESULT window::onNotify(NMHDR * pmnh)
{
	return LRESULT();
}

LRESULT window::onSystemClose()
{
	return  DEF_WIN_PROC;
}

LRESULT window::onMove(int x, int y)
{
	 return DEF_WIN_PROC; 
}

LRESULT window::onMoving(RECT * _pRectDrag)
{
	return DEF_WIN_PROC;
}

LRESULT window::onSize(DWORD dwSizeCpde, int width, int)
{
	return DEF_WIN_PROC;
}

LRESULT window::onSizing(dword _dwSizingEdge, RECT * _pRectDrag)
{
	 return DEF_WIN_PROC;
}

LRESULT window::case_WM_COMMAND(word wCode, word wId, HWND hwndCtrl)
{
	if (wCode == 0 && hwndCtrl == 0)
			t_process_MenuEvent(wId);

	// ************** Accelerators *****************
	if (wCode == 1 && hwndCtrl == 0)
	{
	/*if (sm_poMainWindow)
		return sm_poMainWindow->t_process_AcceleratorEvent(wId);
	*/	
		return t_process_MenuEvent(wId);
	}
	
	
	window* po = _getWindowPtrFromHandle(hwndCtrl);
	
	if(po)
		po->processOwnNotification(wId);

	onNotify(po, wCode);

	m_oWmMessage.uiMessage = WM_COMMAND;

	// if not any of two first, it has to be this
 	return t_process_ControlEvent(wCode, wId, hwndCtrl);
}

LRESULT window::case_WM_SYSCOMMAND(dword dwCode, int mouse_x, int mount_y)
{
	LRESULT lrRet;
	switch (dwCode)
	{
		case SC_CLOSE: lrRet = onSystemClose();
		break;
	
		default:
			lrRet = DEF_WIN_PROC;
	}
	t_process_SysMenuEvent(this, dwCode);


	return lrRet;
	
}

LRESULT window::case_WM_MOVE(WPARAM wParam, LPARAM lParam)
{
	if (!m_bCoordinatesValid)
		return 1;
	RECT rcClient;
	RECT rcWin;

	//POINTS pt = MAKEPOINTS(lParam);

	GetClientRect(*this, &rcClient);
	GetWindowRect(*this, &rcWin);

	int borderWidth = ((rcWin.right - rcWin.left) - (rcClient.right - rcClient.left)) / 2;

	
	POINT ptClientPos = PosFromRect(rcClient);
	
	POINT ptClientDim = DimFromRect(rcClient);
	POINT ptWinPos = PosFromRect(rcWin);
	POINT ptWinTest = PosFromRect(rcWin);


	//POINT ptWinDim = DimFromRect(srcWin);
	
	ScreenToClient(*this, &ptWinTest);
	/*POINT ptDiff;

	ptDiff.x = (rcWin.right - rcWin.left - m_x) - rcClient.right;
	ptDiff.y = (rcWin.bottom - rcWin.top - m_x) - rcClient.bottom;*/

	POINT ptTemp = ptWinPos;

	POINT pt1[1] = { ptTemp };
							
	//MapWindowPoints(NULL, NULL, pt1, 1);

	//m_dwTextLengthMoveWindow(*this, 0, 0, 400, 300, true);		

	// for windows with no parent
	if (m_poParentWindow && *m_poParentWindow != GetDesktopWindow())
	{
		if (!m_poParentWindow->m_bCoordinatesValid)
			return 1;

		m_x = ptWinPos.x - m_poParentWindow->m_x + ptWinTest.x;
		m_y = ptWinPos.y - m_poParentWindow->m_y +ptWinTest.y;


		//m_x = ptWinPos.x - m_PParentWindow->m_x - pt1->x;
		//m_y = ptWinPos.y - m_PParentWindow->m_y - pt1->y;
		//m_width = ptWinDim.x - ptWinPos.x;
		//m_height = ptWinDim.y - ptWinPos.y;
		//setPos(m_x, m_y, m_width, m_height);
		
		//updateDimensions();
		//InvalidateRect(*this, NULL, true);
		RECT rc = { 0,0, 100, 20 };
	//	InvalidateRect(*this, &rc, true);
	}
	else {

		m_x = ptWinPos.x;
		m_y = ptWinPos.y;
		//m_x = ptWinPos.x;// -pt1->x;;
		//m_y = ptWinPos.y;// -pt1->y;;
//		 m_width = ptWinDim.x - ptWinPos.x;
	//	m_height = ptWinDim.y - ptWinPos.y;
		//setPos(m_x, m_y);
		updateDimensions();
		RECT rc = { 0,0, 200, 40 };
		InvalidateRect(*this, &rc, true);
		//DEBUG;
	}

	
	return 0;
	//if (rcTemp.right > 0)
	//{
	//	m_client_x = (int)(short)LOWORD(lParam);   // horizontal position 
	//	m_client_y = (int)(short)HIWORD(lParam);   // vertical position 

	//	RECT rcTemp;
	//	GetWindowRect(*this, &rcTemp);
	//	m_x = rcTemp.left;
	//	m_y = rcTemp.top;
	//	m_width = rcTemp.right - rcTemp.left;
	//	m_height = rcTemp.bottom - rcTemp.top;
	//}
	//return case_WM_MOVE(wParam, lParam);
}

LRESULT window::case_WM_NOTIFY(NMHDR* pmnh)
{


	m_oWmMessage.type = window::event_info::type::notify_event;

	// TODO: check if this does what it is supposed to
	t_process_ControlEvent(pmnh->code, pmnh->idFrom, pmnh->hwndFrom);
	return onNotify(pmnh);
}


LRESULT window::case_WM_SIZE(WPARAM wParam, LPARAM lParam)
{
	return 1;
}



LRESULT window::case_WM_CLOSE()
{
	return 1;
}

LRESULT window::case_WM_CHAR(WPARAM wParam, LPARAM lParam)
{
	return DEF_WIN_PROC;
}

LRESULT window::case_WM_PAINT()
{
	return DEF_WIN_PROC;
}



LRESULT window::window_message_handler(WM_ERASEBKGND, HDC hdc)
{
	return DEF_WIN_PROC;
}

