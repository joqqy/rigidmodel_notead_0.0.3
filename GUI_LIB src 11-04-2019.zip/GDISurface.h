#pragma once
#include "Definitions.h"


class GDISurface
{
public:
	GDISurface();
	virtual ~GDISurface();



	bool create(u32 width, u32 height);

	operator HDC();
	operator HBITMAP();



	
	// TODO: hexa nap: Define dx
	//TODO: hexa map: use TranparentBitBlit for blitting hexagons

	// draw the contents of h_hDC in another DC
	bool copyToTransparent(const GDISurface* POSurfaceDest, u32 destX, u32 desty, u32 destwidth, u32 destheight);

//	bool copyToTransparent(const GDISurface* POSurfaceDest, u32 destX, u32 desty, u32 destwidth, u32 destheight);


	

protected:
	HBITMAP		m_hBitmnp;
	HDC			m_hDC;
	dword		dwWidth, dweight;


};

