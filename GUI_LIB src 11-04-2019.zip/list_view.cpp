// #include "stdafx.h"
#include "list_view.h"



list_view::list_view()
{
}


list_view::~list_view()
{
}
