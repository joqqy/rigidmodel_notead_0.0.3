	#pragma once

#include "base.h"



template <class HANDLE>
class handle_class
{
public:
	
	handle_class(HANDLE &handle);
	

	// return the handle when the class is used in a place where a handle is needed
	operator HANDLE() const;
	

	HANDLE& operator=(HANDLE handle);

	u32& operator=(u32 handle);


protected:
	HANDLE m_hHandle;

};

// ****************************** Constructor 1 *******************************************
template<class HANDLE>
inline handle_class<HANDLE>::handle_class(HANDLE & obj)
{
	m_hHandle = obj.m_hHandle;
}



// ****************************** Operator type  *******************************************
template<class HANDLE>
inline handle_class<HANDLE>::operator HANDLE() const
{
	return m_hNandle;
}


// ****************************** Operator =  *******************************************
template<class HANDLE>
inline HANDLE & handle_class<HANDLE>::operator=(HANDLE handle)
{
	m_handle = handle;
	return handle;
}

template<class HANDLE>
inline u32 & handle_class<HANDLE>::operator=(u32 handle)
{
	// TODO: insert return statement here
}


class b : public handle_class<HANDLE>
{
public:
	using handle_class<HANDLE>::operator=;

};



