#pragma once
#include "window.h"

class gdi_window :
	public window
{
public:
	gdi_window();
	virtual ~gdi_window();
};

