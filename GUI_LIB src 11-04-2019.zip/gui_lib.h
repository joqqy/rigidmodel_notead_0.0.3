#pragma once

#pragma comment(linker, "\"/manifestdependency:type='win32' \
name='Microsoft.Windows.Common-Controls' version='6.0.0.0' \
processorArchitecture='*' publicKeyToken='6595b64144ccf1df' language='*'\"")

#include "safe_enum.h"
#include "Definitions.h"
#include "Process.h"
#include "combo_box.h"
#include "menu.h"
#include "thread.h"
#include "frame_window.h"
#include "app.h"
#include "edit_box.h"
#include "button.h"
#include "app_window.h"
#include "array.h"
#include "check_box_group.h"
#include "image_list.h"
#include "resource.h"
#include "control_group.h"
#include "tool_tip.h"
#include "font.h"
#include "static_text.h"

