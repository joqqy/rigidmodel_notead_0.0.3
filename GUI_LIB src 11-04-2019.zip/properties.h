#pragma once
#include "Definitions.h"
#include <functional>
#include "event_handler.h"

#define decl_number_property(type, name, get, set)\
	number_property<##type> ##name = number_property<##type>(\
		[this]() {return spc( ) ##get (); },\
		[this](##type spc ( )_ ##type) {##set (_ ##type); }\
	);\


#define decl_number_property_1(type, get, set)\
	number_property<##type>(\
		[this]() {return spc( ) ##get (); },\
		[this](##type spc ( )_ ##type) {##set (_ ##type); }\
	);\


#define decl_number_property_2(type, get, set)\
	number_property<##type>(\
		[this]() {return spc( ) ##get; },\
		[this](##type spc ( )_ ##type) {##set; }\
	);\

//template <class C>
struct _property_base
{
	//C _poObject;


	

protected:
	
};


struct test
{
	LRESULT test_func(int i)
	{
		return 1;
	}
};

template <class T>
class number_property : public _property_base
{
public:
	number_property() { }

	number_property(function<T()> _get, function<void(T)> _set)
		: m_get(_get), m_set(_set) {}

	operator T()
	{
		return m_get();
	}

	T & operator=(const T & t)
	{
		m_t = t;
		m_set(t);
		return m_t;
	}

	function<T()> m_get;
	function<void(T)> m_set;

	T m_t;
};


#define decl_bool_property_1(get, set, invert)\
	 bool_property(\
		[this]()					{ return spc( ) ##get (); },\
		[this](bool spc ( )_bState) { ##set (_bState); }, \
		##invert \
	);


#define decl_bool_property_2(get, set, inv) \
	 bool_property(\
		[this]()					{ ##get; },\
		[this](bool spc ( )_bState) { ##set; }, \
		##inv ); 



class bool_property
{
public:
	bool_property() { }

	bool_property(function<bool()> _get, function<void(bool)> _set, bool _bInvertFunction = false)
		: m_get(_get), m_set(_set), m_bInvertFunction(_bInvertFunction) {}

	operator bool()
	{
		return m_get();
	}

	bool & operator=(const bool & _bState)
	{
		m_bState = _bState;

		m_set(m_bInvertFunction ? !m_bState : m_bState);
		
		return m_bState;
	}

	function<bool()> m_get;
	function<void(bool)> m_set;

	bool m_bState;	
	bool m_bInvertFunction = false;
};




class _string_property
{
public:
	
	
	
	

	string m_str;

	_string_property() { }
	virtual ~_string_property() { if (m_szBuffer) delete[] m_szBuffer; }

	_string_property(function<csz()> _get, function<void(csz)> _set)
		: m_get(_get), m_set(_set) {}

	operator string()
	{
		return m_get();
	}

	operator sz()
	{
		csz cszTemp = m_get();


		//if (m_szBuffer)
		//	delete[] m_szBuffer;

		//m_szBuffer = new char[strlen(cszTemp) + 1];
		strcpy_s(m_szBuffer, strlen(cszTemp) + 1, cszTemp);

		return m_szBuffer;
	}

	operator csz()
	{
		return m_get();
	}


	sz & operator=(csz & _csz)
	{
		/*if (m_szBuffer)
			delete[] m_szBuffer;

		m_szBuffer = new char[strlen(_csz) + 1];*/
		strcpy_s(m_szBuffer, strlen(_csz) + 1, _csz);

		m_str = m_get();
		m_set(_csz);

		return m_szBuffer;
	}

	sz & operator=(csz _csz)
	{
		/*if (m_szBuffer)
			delete[] m_szBuffer;

		m_szBuffer = new char[strlen(_csz) + 1];
		*/strcpy_s(m_szBuffer, strlen(_csz) + 1, _csz);

		m_str = m_get();
		m_set(_csz);

		return m_szBuffer;
	}




	string & operator=(const string & _str)
	{
		m_str = _str;
		m_set(_str.c_str());

		return m_str;
	}

	string & operator=(uint32_t & _int)
	{

		_itoa_s(_int, m_szBuffer, 256, 10);

		m_set(m_szBuffer);

		m_str = m_szBuffer;

		return m_str;
	}


	string & operator=(int & _int)
	{
		
		_itoa_s(_int, m_szBuffer, 256, 10);

		m_set(m_szBuffer);

		m_str = m_szBuffer;

		return m_str;
	}



	function<csz()> m_get;
	function<void(csz)> m_set;

	
	sz m_szBuffer = new char[256];
};
