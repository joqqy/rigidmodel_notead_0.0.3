#pragma once
#include "base.h"
class list_view :
	public base
{
public:
	//bool create(window * PParentWindow, int x, int y, int width, int height);


	list_view();
	virtual ~list_view();
};

