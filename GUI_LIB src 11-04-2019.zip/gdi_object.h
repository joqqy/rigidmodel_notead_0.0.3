#pragma once
// #include "stdafx.h"
#include "Definitions.h"
#include "base.h"

class window;

#define _protected protected:





class gdi_object : public base
{

public:
	virtual operator HGDIOBJ() = 0;
	virtual operator int() = 0;
	virtual bool delete_object() = 0;

};

template <class _HANDLE>
class gdi_object_handle : public gdi_object
{
public:
	gdi_object_handle();
	
	gdi_object_handle(_HANDLE _handle);
	
	
	virtual ~gdi_object_handle();


	virtual operator HGDIOBJ() override
	{		
		return m_hGDIObjHandle;		
	}

	virtual operator int() override
	{
		return reinterpret_cast<int>(m_hGDIObjHandle);
	}


	bool delete_object();

	// use to "do something" with the GDI object and one or more windows
	_protected virtual void linkWindow(window * _poWin) {}
	
	
	// update the window(s) linked to the object when something changes
	virtual void updateWindow() {};

	
	
	
	
protected:
	_HANDLE m_hGDIObjHandle;
};

template<class _HANDLE>
inline gdi_object_handle<_HANDLE>::gdi_object_handle()
{
}

template<class _HANDLE>
inline gdi_object_handle<_HANDLE>::gdi_object_handle(_HANDLE _handle)
{
}


template<class _HANDLE>
inline gdi_object_handle<_HANDLE>::~gdi_object_handle()
{
	if (m_hGDIObjHandle)
		delete_object();
}



template<class _HANDLE>
inline bool gdi_object_handle<_HANDLE>::delete_object()
{
	return DeleteObject(*this);
	
};


