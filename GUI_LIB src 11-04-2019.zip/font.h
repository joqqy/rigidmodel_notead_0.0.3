#pragma once
#include "gdi_object.h"
class font :
	public gdi_object_handle<HFONT>
{
public:
	font();
	virtual ~font();
	
	HFONT create(int _size = 10, int width = 10, const char _cszTypeFaceName[32] = "Tahoma", int _boldness = 300, BYTE _quality = DEFAULT_QUALITY, bool _bItalic = false, bool _bUnderline = false, bool _bStrikOut = false);


	bool setFont(const font* _poFont);
	
	font(const HFONT _font);

	void setWidth(LONG width);
	void setHeight(uint height);
	

	HFONT createIndirect();

	

	operator HFONT();
	
	HFONT &  operator=(const HFONT & _font);

	int height();
	int width();


	// use to "do something" with the GDI object and one or more windows
	virtual void linkWindow(window * _poWin);


		// update the window(s) linked to the object when something changes
	virtual void updateWindow();

	int m_width, m_height;
	int    m_escapement;
	int    m_orientation;
	int    m_weight = 300;
	DWORD  m_bItalic;
	DWORD  m_bUnderline;
	DWORD  m_bStrikeOut;
	DWORD  m_iCharSet;
	DWORD  m_iOutPrecision;
	DWORD  m_iClipPrecision;
	DWORD  m_iQuality;
	DWORD  m_iPitchAndFamily;
	string m_strFaceName;
	LPSTR m_szFaceName;

	LOGFONT m_oLogFont = { 
		-10,
		0, 
		0, 
		9, 
		300, 
		FALSE, 
		FALSE, 
		FALSE, 
		DEFAULT_CHARSET, 
		OUT_TT_PRECIS,
		CLIP_DEFAULT_PRECIS, 
		CLEARTYPE_QUALITY, 
		FIXED_PITCH, 
		TEXT("Tahoma") 
	};
};

