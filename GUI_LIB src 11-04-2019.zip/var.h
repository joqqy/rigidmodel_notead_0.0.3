#pragma once

#include <unordered_map>

using namespace std;

//
//#include <unordered_map>
//
//
//struct var
//{
//public:
//	var()
//	{
//
//	}
//
//	/*var(const var& _var)
//	{
//		m_value = _var.m_value;
//		data = _var.data;
//		type = _var.type;
//	}
//
//
//	_var(T _input)
//	{
//		m_value = _input;
//	}*/
//	var(long long _ll) { data._longlong = _ll; };
//	var(uint _ui) { data._uint = _ui; };
//	var(int _i) { data._int = _i; }
//	var(char _ch) { data._char = _ch; };
//
//	var(bool _b) { data._bool = _b; };
//	var(long _l) { data._long = _l; };
//	var(float _f) { data._float = _f; }
//	var(double _d) { data._double = _d; };
//	var(const char* _csz) { data._csz = _csz; };
//	var(void* _vp) { data._void_ptr = _vp; };
//
//	operator long long() { return data._longlong; };
//	operator uint		() { return data._uint; };
//	operator int() { return data._int; };
//
//	operator char() { return data._char; };
//	operator bool() { return data._bool; };
//	operator long() { return data._long; };
//	operator float() { return data._float; }
//	operator double() { return data._double; };
//	operator const char*() { return data._csz; };
//	operator void*		() { return data._void_ptr;; };
//	   	  
//	/*int&	operator=(const int& other);
//	uint&	operator=(const uint& other);
//	float&	operator=(const float& other);
//	double& operator=(const double& other);
//*/
//
//
//protected:
//
//
//	union types
//	{
//		void* _void_ptr;
//		char _char;
//		bool _bool;
//		int		_int;
//		uint	_uint;
//		long long _longlong;
//		unsigned long long _Ulonglong;
//		long _long;
//		unsigned long _ulong;
//		float	_float;
//		double	_double;
//		csz		_csz;
//	} data;
//};
//
//// ----------------------------------------------------------------------------------




struct variadic_function_base
{



}; 




template<class... Args>
struct variadic_function : variadic_function_base
{
	

	



	//Functor
	
		function<LRESULT(Args...)> _function;

	
	//typename typedef R (C::*func_pmf)(Args... args);
	
	// C* _pOwner;

//	func_pmf _func;


public:
	//variadic_function() {};
	
	
	template <class C>	
	void  bind(LRESULT(C::*function)(Args... args), C* ownerPtr)
	{
		

		LRESULT L = 0;
		//_func = function;
		////Saved via lambda to avoid generic placeholders with std::bind
		_function = [function, ownerPtr](Args... args)
		{	
			return (ownerPtr->*function)(args...);			
		


		};	

		//static_cast<Message<Args2...>*(static_cast< Message<Args...>*>(Message<Args...>* > )->broadcast(std::forward<Args>(Args)...);

		//return 1;
	};
	
	
	
	LRESULT exec(Args&&... args)
	{ 
		
//		return ((*_pOwner).*(_func))(args ...);
		//{
	//	int i = sizeof...(args);
		if (_function)
		{	// return the value from the handler
			// TODO: edit so it only is a return statement
			return _function(std::forward<Args>(args)...);

			//return 1; 


		}
		return 0;

	};
	
	


	
};

//
//
//class base_param_pack {};
//
////Variadic parameter pack
//template<class... Args>
//class param_pack {};
//
//
//struct message_base
//{
//
//	int f()
//	{
//		return i;
//	}
//
//	int i;
//};
//
//template <class... Args>
//struct derived_message : public message_base
//{
//	variadic_function<Args...> _func;
//	//message_base *p;
//	
//
//
//
//	
//
//	//unique_ptr<message_base> p = std::make_unique< Message<Args...> >;
//
//	
//	//Broadcasting the message - no check if the parameter pack sets the hash
//	
//	
//	void exec(Args&... args)
//	{
//	
//		
//		_func.exec(std::forward<Args>(args)...);
//
//		//_fucntion.exec(std::forward<Args>(args)...);
//		//static_cast<Message<args...>*>(p)->bind(args);
//	}
//
//	//Binding the function listener - no check if the parameter pack sets the hash
//	template<class T>
//	void bind(void(T::*function)(Args... args), T* ownerPtr)
//	{
//		
//		//_fucntion.bind(function, ownerPtr);
//		
//
//		//p = new derived_message<Args...>;
//
//		_func.bind(function, ownerPtr);
//
//
//		//_listeners.back().second.bindFunction
//	};
//
//
//};
//
//
//
//
////


struct message
{
	virtual ~message()
	{

	}



	
	/*template <class... Args>
	void f(Args&&... args);*/

	//variadic_function<int> f2;
	

	std::unique_ptr<variadic_function_base> un;	
	
	//typedef void(T::*func_type)(Args... args);
	

	
	template<class ... Args>
	LRESULT exec(Args&&... args)
	{
		
		//un.get()->
		return static_cast<variadic_function<Args...>*>( un.get() )->exec(std::forward<Args>(args)...);
		

		//_fucntion.exec(std::forward<Args>(args)...);
		//static_cast<Message<args...>*>(p)->bind(args);
	}

	//template<class ... Args>
	//void operator()(Args&&... args)
	//{

	//	static_cast<variadic_function<Args...>*>(un.get())->exec(std::forward<Args>(args)...);


	//	//_fucntion.exec(std::forward<Args>(args)...);
	//	//static_cast<Message<args...>*>(p)->bind(args);
	//}

	//Binding the function listener - no check if the parameter pack sets the hash
	template<class C, class ... Args>
	void bind(LRESULT(C::*function)(Args... args), C* ownerPtr)
	{

		//typedef void(T::*func_type)(Args... args);

		un = make_unique<variadic_function<Args...> >();
		//_fucntion.bind(function, ownerPtr);

		static_cast<variadic_function<Args...>*>( un.get() )->bind(function, ownerPtr);


		//variadic_function_base* un2 = new variadic_function<Args...>;


		//p = new derived_message<Args...>;

		//_func.bind(function, ownerPtr);


		//_listeners.back().second.bindFunction
	}
	
};

class message_handler
{
public:

	message_handler()
	{

	}

	virtual ~message_handler()
	{
		int size = m_maUINTToHandler.size();
		for (int i = 0; i < size; i++)
		{
			delete m_maUINTToHandler[i];			
		}
	}

	
	
	template<class C, class ... Args>
	void bind(UINT key, LRESULT(C::*function)(Args... args), C* ownerPtr)
	{
		message* pm = new message;
		pm->bind(function, ownerPtr);
		
		m_maUINTToHandler[key] = pm;


	}

	template<class C, class ... Args>
	void bind(HWND hwnd, UINT key, LRESULT(C::*function)(Args... args), C* ownerPtr)
	{
		//message* pm = new message;
		//pm->bind(function, ownerPtr);

		//m_maUINTToHandler[key] = pm;


	}



	template<UINT key, class ... Args>
	LRESULT exec(Args&&... args)
	{

		unordered_map<UINT, message*>::iterator it = m_maUINTToHandler.find(key);
		if (it == m_maUINTToHandler.end())
			return -1;

		return it->second->exec(args ...);

		//un.get()->
		//return static_cast<variadic_function<Args...>*>( un.get() )->exec(std::forward<Args>(args)...);


		//_fucntion.exec(std::forward<Args>(args)...);
		//static_cast<Message<args...>*>(p)->bind(args);
	}
private:
	unordered_map<UINT, message*> m_maUINTToHandler;
	unordered_map<string, message*> m_mapStringToHandler;
};
//
////	
////
////	typedef variadic_function<Args...> handler;
////	handler m_handler;
////
////	template<class T, class... Args2>
////	void bindFunction(int(T::*function)(Args2... args), T* ownerPtr)
////	{
////		m_handler.bind(function);
////	}
////
////};
////
//////typedef unordered_map<std::string, std::unique_ptr<message_base>> MessageMap;
////
////typedef std::unordered_map<std::string, std::unique_ptr<message_base>> MessageMap;
////
////struct message_handler
////{
////	variadic_function_base * pbase;
////	
////
////	MessageMap _messages;
////
////	template<class... Args>
////	 void raise(Args... args)
////	{
////		 auto it = _messages.find(messageName);
////
////		 if (it == _messages.end())
////			 return;
////
////		 static_cast<variadic_function<Args...>*>(variadic_function<Args>::bind(function, ownerPtr));
////		// variadic_function<Args...>* p= static_cast<variadic_function<Args...>*>;
////		 //p->exec(1, 2);
////		 
////		 int i = 0;
////	}
////
////	template<class T, class... Args>
////	void bind(int(T::*function)(const std::string& messageName, Args... args), T* ownerPtr)
////	{
////
////		_messages[messageName] = std::make_unique<Message<Args...>>(messageName);
////
////		variadic_function<Args...>* p = new variadic_function<Args...>;
////		p->bind(function, ownerPtr);
////		pbase = p;
////
////	}
////};
