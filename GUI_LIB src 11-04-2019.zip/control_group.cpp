// #include "stdafx.h"
#include "control_group.h"



//control_group::control_group()A
//{
//}
//
//
//control_group::control_group(window * _pPparent, int x, int width, int height)
//{
//}

control_group::control_group()
{
}

control_group::control_group(window * _pPparent, int style_ex, int style, int x, int y, int width, int height)
	: window(_pPparent, WC_DEFAULT, "Group1", style_ex, style, NULL, x, y, width, height)
{
	//m_poParent = _pPparent;
}
//
//bool control_group::create(window * _pPparent, int style_ex, int style, int x, int y, int width, int height)
//{
//	return ( 0 != _createEx(_pPparent, WC_DEFAULT, "CONTROL_GROUP", style_ex, WS_CHILD | style, NULL, x, y, width, height) );
//}
//
//bool control_group::create(window * _pPparent, csz szCpation, int style_ex, int style, int x, int y, int width, int height)
//{
//	return(0 != _createEx(_pPparent, WC_STATIC, szCpation , style_ex, WS_CHILD | style, NULL, x, y, width, height));
//}

bool control_group::create(window * _pPparent, csz cszWindowClass, csz szCpation, int style_ex, int style, int x, int y, int width, int height)
{
	WNDCLASSEX wcex;
	wcex.cbSize = sizeof(WNDCLASSEX);

	GetClassInfoEx(H_INST, cszWindowClass, &wcex);
	
	string strTemp = wcex.lpszClassName;
	strTemp += "_MODDED";
	wcex.lpszClassName = strTemp.c_str();

	sm_oldWinProc = wcex.lpfnWndProc;
	wcex.lpfnWndProc = control_group::WindowProc;


	ATOM a = RegisterClassEx(&wcex);
	
	
	bool b = _createEx(_pPparent, wcex.lpszClassName, szCpation, style_ex, WS_CHILD | style, NULL, x, y, width, height);
	
	

	return b;
}

//bool control_group::create(window * _pPparent, int x, int y, int width, int height)
//{
//	return (0 != _createEx(_pPparent, WC_BUTTON, "", WS_EX_TRANSPARENT, WS_CHILD | BS_GROUPBOX, NULL, x, y, width, height));	
//}

control_group::~control_group()
{
}

LRESULT control_group::case_WM_NOTIFY(NMHDR * pmnh)
{
	window::case_WM_NOTIFY(pmnh);
	
	if (m_poParentWindow)
		return m_poParentWindow->case_WM_NOTIFY(pmnh);
}

LRESULT control_group::case_WM_COMMAND(word wCode, word wId, HWND hwndCtrl)
{
	window::case_WM_COMMAND(wCode, wId, hwndCtrl);

	if (m_poParentWindow)
		return m_poParentWindow->case_WM_COMMAND(wCode, wId, hwndCtrl);
}


LRESULT control_group::WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{

	switch (uMsg)
	{
		case WM_COMMAND:
		{
					
			HWND hwndParent = GetParent(hwnd);
			if (hwndParent == NULL)
				break;

			SendMessage(hwndParent, uMsg, wParam, lParam);

		}
		break;

		case WM_NOTIFY:
		{
			HWND hwndParent = GetParent(hwnd);
			if (hwndParent == NULL)
				break;

			SendMessage(hwndParent, uMsg, wParam, lParam);

		}
		break;

	
default:
		CallWindowProc(sm_oldWinProc, hwnd, uMsg, wParam, lParam);
	}
	
	return CallWindowProc(sm_oldWinProc, hwnd, uMsg, wParam, lParam);
}

WNDPROC control_group::sm_oldWinProc = NULL;