#pragma once
#include "base.h"
//#include "var.h"

#define InvokePMF(pobj, pfunc, ...) ((* ##pobj ).*##pfunc)(__VA_ARGS__)		



template <class T>
struct var_T {
public:
	csz type = typeid(T).name();
	T	m_value;

	var_T()
	{

	}
	
	var_T(const var_T& _var)
	{
		m_value = _var.m_value;
		data = _var.data;
		type = _var.type;
	}


	var_T(T _input)
	{
		m_value = _input;
	}
	//var(long long) ;
	//var(uint);
	//var(int);
	//var(char);

	//var(long) {};
	//var(float);
	//var(double) {};
	//var(const char*);
	//var(void* _vp)
	//{
	//	data._void_ptr = _vp;
	//}
	
	T&	operator=(const T& _t);
	
	/*int&	operator=(const int& other);
	uint&	operator=(const uint& other);
	float&	operator=(const float& other);
	double& operator=(const double& other);
*/


protected:	
	

	union types
	{
		void* _void_ptr;
		char _char;
		long long _longlong;
		int		_int;
		uint	_uint;
		float	_float;
		double	_double;
		csz		_csz;
	} data;
};







template <
	class T1 = int,
	class T2 = int,
	event_type type = event_type::wm_event,
	UINT _message = WM_CREATE
	
>
struct _simple_event_handler_base
{
	
	function < LRESULT(WPARAM, LPARAM)> m_invoker;
		
	template <
		class T1 = int,
		class T2 = int,
		class T3 = int,
		class T4 = int,
		class T5 = int,
		class T6 = int,
		class T7 = int,
		class T8 = int,
		class T9 = int,
		class T10 = int>
	
	int invoke(void* poThis,
		var_T <T1>	_1	= (T1)0,
		var_T <T2>	_2	= (T2)0,
		var_T <T3>	_3	= (T3)0,
		var_T <T4>	_4	= (T4)0,
		var_T <T5>	_5	= (T5)0,
		var_T <T6>	_6	= (T6)0,
		var_T <T7>	_7	= (T7)0,
		var_T <T8>	_8	= (T8)0,
		var_T <T9>	_9	= (T9)0,
		var_T	<T10>	_10	= (T10)0
	)
	{
		LRESULT lr = 0;

		__asm
		{
			push	pothis
			call	code;
			mov		lr, EAX
		}

		return lr;

	}
	/*
	virtual	RESULT run(
		var <T1>	_1 = (T1)0,
		var <T2>	_2 = (T2)0
		*var <T3>	_3	= (T3)0,
		var <T4>	_4	= (T4)0,
		var <T5>	_5	= (T5)0,
		var <T6>	_6	= (T6)0,
		var <T7>	_7	= (T7)0,
		var <T8>	_8	= (T8)0,
		var <T9>	_9	= (T9)0,
		var	<T10>	_10	= (T10)0
	) = 0;*/

	


}; 


struct _pmf_base
{

	
		
	/*virtual LRESULT _invoke(var _1 = 0, var _2 = 0, var _3 = 0)
	{
		return 1;
	
	};
	function <LRESULT(void)> m_invoker;	*/
};



template <class C, class ... types>
struct _pmf : public _pmf_base
{
	C* po;

	static const std::size_t m_size = sizeof...(types);

	//typedef int (MyClass::*MyTypedef)(int);
	
	typedef LRESULT (C::*__pmf)(types...);
	
	__pmf m_pmf;
	
	

	void assign(C* _po, __pmf _input)
	{
		//m_invoker = _func;
		po = _po;
		m_pmf = _input;
		
	}
	
	
	LRESULT invoke(types... T)
	{
		
		return (*po.*m_pmf)(T...);	
		
	}

	void f()
	{
		int i = 0;//s.invoke(1, 3, "test", 'char');
	}

	//_simple_event_handler_base s;
};

template <class C, class ... types>
struct _pmf_ : public _pmf_base
{
	C* po;
	
	//types...;

	static const std::size_t m_size = sizeof...(types);

	//typedef int (MyClass::*MyTypedef)(int);
	
	typedef LRESULT (C::*__pmf)(types...);
	
	__pmf m_pmf;
	
	

	void assign(C* _po, __pmf _input)
	{
		//m_invoker = _func;
		po = _po;
		m_pmf = _input;
		
	}
	
	
	LRESULT invoke(types... T)
	{
		
		return (*po.*m_pmf)(T...);	
		
	}

	
	//_simple_event_handler_base s;
};






//template<class ... types> struct C {};
//C<int, int> x; // OK



struct event_handler_base
{
	//_test_ bb;
	virtual LRESULT invoke3(LPARAM hwndParam, WPARAM wParam, LPARAM lParam) = 0;

	virtual void handler1() {};
	virtual LRESULT handler2() { return 1; };
	virtual LRESULT handler3(LPARAM hwndParam, WPARAM wParam, LPARAM lParam) { return 1; };

	virtual void setData3(LPARAM hwndParam, WPARAM wParam, LPARAM lParam)
	{
//		bb.a<window, int>();


		_hwndParam = hwndParam;
		_wParam = wParam;
		_lParam = lParam;
	}

	LPARAM _hwndParam;
	WPARAM _wParam;
	LPARAM _lParam;
};


template <class CLASS>
struct event_handler : public event_handler_base
{

	typedef void (CLASS::*classMeberFunction1)();

	typedef LRESULT(CLASS::*classMeberFunction2)();
	
	typedef LRESULT(CLASS::*classMeberFunction3)(LPARAM, WPARAM, LPARAM);

	

	void assign3(CLASS* pC, classMeberFunction3 pmf)
	{
		pCurentClass = pC;
		pMemberFunction = pmf;		
	}
	
	virtual LRESULT invoke3(LPARAM hwndParam, WPARAM wParam, LPARAM lParam)
	{
		setData3(hwndParam, wParam, lParam);
		
	

		return InvokePMF(pCurentClass, pMemberFunction, _hwndParam, _wParam, _lParam);



	}	

	CLASS* pCurentClass;
	classMeberFunction3 pMemberFunction;

};