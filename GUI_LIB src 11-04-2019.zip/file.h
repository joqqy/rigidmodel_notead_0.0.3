#pragma once
// #include "stdafx.h"
#include "base.h"
#include <fstream>
#include "window.h""


#define FILE_BUFFERSIZE 1000

class file :
	public base
{
	


public:
	file();
	virtual ~file();



	




	//  opens a file dialog
	LRESULT openFileDialog(window* PWinOwner);
	
	LRESULT saveFileDialog(window* PWinOwner);

	/*bool openFile(string strFileName)
	{
		m_file.open(strFileName, ios_base::binary | ios_base::in);
	}
*/

	operator string();		
	//operator sz();
	operator csz();


	TCHAR m_pstrFilter[FILE_BUFFERSIZE] = "RMV2 Files\0*.rigid_model_v2\0All Files\0*.*\0\0";
protected:
	string m_strDir;
	string m_strFile1;
	string m_strPath;


	TCHAR m_szFileBuffer[FILE_BUFFERSIZE];
	ifstream m_ofsFile;
	OPENFILENAME m_ofn;
};

