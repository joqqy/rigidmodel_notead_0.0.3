#pragma once
#include "control_group.h"
#include "static_control.h"


namespace desc_placement
{
	const uint hide = 0;
	const uint on_top = 1;
	const uint in_front = 2;

}


class static_text :
	public window
{ // TODO: finish this
public:
	
	static_text();
	/*static_text(window *_pPparent, string strStatic, string strDescription,
		int x, int y, int width = CW_USEDEFAULT, int height = CW_USEDEFAULT);
	*/
	
	virtual ~static_text();

	bool create(window *_pPparent, string strStatic, string strDescription, int x, int y, bool bDescritpionOntop = false, uint styles = ES_CENTER);


	
	virtual csz setText(const string strText) override;


	static_control Describtion;

protected:
	bool createDescription(window *_pPparent,  string strDescription, bool bOnTop = false, int x_offset = 0, int y_offset = 0);
	int m_cx;
	int m_cy;

	uint m_uiDescrptionPlacement = desc_placement::in_front;

};

