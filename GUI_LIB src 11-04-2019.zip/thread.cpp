// #include "stdafx.h"
#include "thread.h"


thread::thread()
{
	if (sm_pmapIdToPtr == nullptr)
		sm_pmapIdToPtr = new map<DWORD, thread*>;

	_captureCurrentThread();
}

void thread::_captureCurrentThread()
{
	m_dwId = GetCurrentThreadId();
	
	if (m_dwId)
		(*sm_pmapIdToPtr)[m_dwId] = this;

//	m_hHandle = GetCurrentThread();
	//if (m_hHandle)
		//(*sm_pmapHanndToPtr)[m_hHandle] = this;


}

bool thread::_createEx(base * PObject, pmf::ThreadHandlerFunc pmf, DWORD dwCreationFlags, SIZE_T dwStackSize, LPSECURITY_ATTRIBUTES pThreadAttributes)
{
	m_hHandle = CreateThread(
		pThreadAttributes,
		dwStackSize,
		_winapi_thread_funct�on,
		reinterpret_cast<LPVOID>(this),
		dwCreationFlags,
		&m_dwId
	);	
	
	if (!m_hHandle)
		return false;

	m_PFMObjec = PObject;
	m_pmfFunc =  pmf;

	return true;
}

bool thread::_createEx(DWORD dwFlags, SIZE_T dwStackSize, LPSECURITY_ATTRIBUTES pThreadAttributes)
{
	
	m_bRunInternalFunction = true;

	m_hHandle = CreateThread(
		pThreadAttributes,
		dwStackSize,
		_winapi_thread_funct�on,
		this,
		dwFlags,
		&m_dwId
	);
	
	if (!m_hHandle)
		return false;

	m_pThreadAttributes = pThreadAttributes;

	return true;
}

thread * thread::getPtrFromCurrentId()
{
	DWORD dwId = thread::getCurrentId();
	   	
	map<DWORD, thread*>::iterator it = sm_pmapIdToPtr->find(dwId);
	if (it == sm_pmapIdToPtr->end())
		return nullptr;

	return it->second;
}

DWORD thread::getId()
{
	return m_dwId;
}

HANDLE thread::getHandle()
{
	return m_hHandle;
		 
}

thread::operator DWORD()
{
	return m_dwId;
}

thread::operator HANDLE()
{
	return m_hHandle;
}

DWORD thread::run()
{
	return 0;
}


DWORD WINAPI thread::_winapi_thread_funct�on(LPVOID pVOID)
{
	thread* PTemp = reinterpret_cast<thread*>( pVOID );
		
	if (PTemp->m_bRunInternalFunction)
		return PTemp->run();	

	if (!PTemp)
		return 0;

	if (PTemp->m_pRunnable)
		return PTemp->m_pRunnable->run();


	if (PTemp->m_PFMObjec && PTemp->m_pmfFunc)
		return (PTemp->m_PFMObjec->*PTemp->m_pmfFunc)();

	return 1;
		
}

DWORD thread::getCurrentId()
{
	return GetCurrentThreadId();
}

HANDLE thread::getCurrentHandle()
{
	return GetCurrentThread();
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//								Static member definitions
///////////////////////////////////////////////////////////////////////////////////////////////////////////

map<HANDLE, thread*>* thread::sm_pmapHanndToPtr = nullptr;
map<DWORD, thread*>* thread::sm_pmapIdToPtr = nullptr;