// #include "stdafx.h"
#include "check_box_group.h"



check_box_group::check_box_group()
{
}

check_box_group::check_box_group(window * pParentWindow, LPCSTR szCaption, DWORD dwExstyle, DWORD dwStyle, int x, int y, int width, int height, bool bFollowParent)
	: check_box(pParentWindow, szCaption, dwExstyle, dwStyle, x, y, width, height, bFollowParent)
{
}



bool check_box_group::create(window * pParentWindow, LPCSTR szCaption, DWORD dwExstyle, DWORD dwStyle, int x, int y, int width, int height, bool bFollowParent)
{
	
	return (0 != _createEx(pParentWindow, WC_BUTTON, szCaption, dwExstyle, dwStyle, NULL, x, y, width, height));
}



check_box_group::~check_box_group()
{
}

LRESULT check_box_group::processOwnNotification(u32 uiID)
{
	if (getStyles() & BS_CHECKBOX || getStyles() & BS_3STATE)
	{
		if (uiID == BN_CLICKED)
		{
			m_lrState = sendMessage(BM_GETCHECK, 0, 0);
			if (m_lrState == BST_UNCHECKED)
			{
				if (onCheck())
					m_lrState = sendMessage(BM_SETCHECK, BST_CHECKED, 0);
			}
			else
			{
				if (onUnCheck())
					m_lrState = sendMessage(BM_SETCHECK, BST_UNCHECKED, 0);
			}
			if (m_poGroupParent)
				m_poGroupParent->onClick(this);

			disableWindows();
			setReadOnlyWindows();
		}
		
		
		setAllChildren();
		
	}
	
	// signal to the group parrent (if any) that the check box has been clicked

	return m_lrState;


	/*check_box::processOwnNotification(uiID);
	if (uiID == BN_CLICKED)	{
		if (getState() != BST_CHECKED)
			setState(BST_CHECKED);
		else
			setState(BST_UNCHECKED);
			
		setAllChildren();	
	}

	return 1;*/
}

void check_box_group::setAllChildren()
{
	if (getState() == BST_CHECKED)
	{
		for (uint i = 0; i < m_vecCheckBoxList.size(); i++)
		{
			m_vecCheckBoxList[i]->setState(BST_CHECKED);
			m_vecCheckBoxList[i]->setReadOnly(false);
		}
		



		setState(BST_CHECKED);
	}
	else
	if (getState() == BST_UNCHECKED)
	{
		for (int i = 0; i < m_vecCheckBoxList.size(); i++)
		{
			m_vecCheckBoxList[i]->setState(BST_UNCHECKED);
			m_vecCheckBoxList[i]->setReadOnly(true);
		}
		
	
		//disableWindows();
	}	
}

void check_box_group::addChild(check_box * _poCheckBox)
{
	_poCheckBox->m_poGroupParent = this;
	m_vecCheckBoxList.push_back(_poCheckBox);
}

uint check_box_group::getCheckedNumber()
{
	uint counter = 0;

	for (int i = 0; i < m_vecCheckBoxList.size(); i++)
		if (m_vecCheckBoxList[i]->getState() == BST_CHECKED)
			counter++;

	return counter;
}

void check_box_group::onClick(check_box * _poCheckBox)
{

	uint size = getCheckedNumber();
	if (size == m_vecCheckBoxList.size())
		setState(BST_CHECKED);

	else if (size > 0)
		setState(BST_INDETERMINATE);
	
	else if (size == 0)
		setState(BST_UNCHECKED);

	// TODO: check the status of the clicked check_box if it is check, that check if all are checked
	// and if all are checked, set the parent check box to CHECKED
	// if only SOME of the childred are check, set the parent to UNDETERMINED.
}
LRESULT check_box_group::case_WM_NOTIFY(NMHDR * pmnh)
{
	window::case_WM_NOTIFY(pmnh);

	if (m_poParentWindow)
		return m_poParentWindow->case_WM_NOTIFY(pmnh);
}

LRESULT check_box_group::case_WM_COMMAND(word wCode, word wId, HWND hwndCtrl)
{
	window::case_WM_COMMAND(wCode, wId, hwndCtrl);

	if (m_poParentWindow)
		return m_poParentWindow->case_WM_COMMAND(wCode, wId, hwndCtrl);
}