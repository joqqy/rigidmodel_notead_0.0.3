// #include "stdafx.h"
#include "base.h"


base::base()
{
	
}


base::~base()
{
}

const char * base::getTypeName()
{
	return typeid(*this).name();
}
