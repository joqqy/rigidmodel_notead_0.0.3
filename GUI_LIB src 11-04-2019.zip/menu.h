#pragma once
/**********************************************************************************************************
	[File:]
	menu.h

	[Author]
	phazer

	[Created]
	15/11/2018 00:00

	[Edited]
	18/12/2018 01:34

	[Description:]
	Win32 api menu wrapper


***********************************************************************************************************/

// #include "stdafx.h"
#include "base.h"
#include "Process.h"
#include "properties.h"
#include "menu_item.h"

#define MENU_POPUP_BEGIN(_menu)\
	spc( ) ##_menu.createPopUp();\
	 ##_menu.addItems( {

#define MENU_POPUP_END \
});\
;\



#define MENU_BAR_BEGIN(_menu)\
	menu* ___p = &##_menu;\
	spc( ) ##_menu.createBar();\
	 ##_menu.addItems( {

#define MENU_BAR_END spc( )\
});\
;\
setMenu(___p);\
drawMenu();\

class menu : public base
{
public:	
	menu();
	virtual ~menu();
	
	bool createBar();
	
	bool createPopUp();

	bool destroy();

	operator HMENU();


	operator menu_item*()
	{
		return &m_mi;
	}

	HMENU getHandle()
	{
		return m_hHandle;
	}	

	bool insertItem(menu_item * _pMenuItem);

	bool insertItem(uint _pos, menu_item* _pmenu);


	/*bool addItems(initializer_list <menu_item>input)
	{
		initializer_list<menu_item>::iterator it = input.begin();
		
		while (it != input.end())
		{		
			it->update();

			if (!insertItem(*it))
				return false;

			it++;
		}

		return true;
	}*/


	bool addItems(vector <menu_item*>input)
	{
		bool bRet;
		for (uint i = 0; i < input.size(); i++)
		{
			insertItem(input[i]);
			input[i]->m_hParentMenu = m_hHandle;
		}

		/*initializer_list<menu_item>::iterator it = input.begin();

		while (it != input.end())
		{
			it->update();

			if (!insertItem(*it))
				return false;

			it++;
		}*/

		return true;
	}


	
	
	
	
	bool appendItem(UINT uiFlags, UINT uiID, csz cszItemText);
	bool appenPopuip(UINT uiFlags, const menu* _poMenu, csz cszItemText);
	
	bool append(UINT uiFlags, UINT_PTR uIdorHandle, csz cszItemText);
	
	
	bool insertItem(UINT uiFlags, UINT_PTR uIdorHandle, csz cszItemText);
	bool changeItem(UINT uiID, UINT uiMask, UINT uiType, UINT state, HMENU hSubMenu = NULL, HBITMAP hBimapUnchecked = NULL);
	

	

	//MID operator=(MID mid);


	

	bool appendItemVecPopup(UINT uiFlags, UINT_PTR uIdorHandle, csz cszItemText, string strID);
	bool appendItemVecSeparator(UINT uiFlags, UINT_PTR uIdorHandle, csz cszItemText, string strID);
	
	bool updateBar(UINT uiFlags, csz cszItemText, string strID);
	
	bool TrackPopup(HWND hwnd, int x, int y, UINT uiFlags = TPM_RIGHTALIGN | TPM_LEFTBUTTON, LPTPMPARAMS ptp = NULL);
	bool updateItem(UINT uiFlags, csz cszItemText, string strID);
	

	// TODO put bitmps ind
	menu_item * operator()(string strText, uint _flags = 0)
	{
		m_mi.m_oMenuItemInfo.cbSize = sizeof(MENUITEMINFO);
		m_mi.m_oMenuItemInfo.fMask = MIIM_STRING | MIIM_SUBMENU | MIIM_ID;
		//m_mi.m_oMenuItemInfo.wID = menu_item::getNextId();

		m_mi.m_oMenuItemInfo.hSubMenu = m_hHandle;

		if (m_mi.m_oMenuItemInfo.dwTypeData)
			delete [] (m_mi.m_oMenuItemInfo.dwTypeData);

		
		uint len = strText.size() + 1;
		m_mi.m_oMenuItemInfo.dwTypeData = new char[len];
		m_mi.m_oMenuItemInfo.cch = len;
		strcpy_s(m_mi.m_oMenuItemInfo.dwTypeData, len, strText.data());

		return &m_mi;
	}


	//operator HMENU();
	

// Data for everu menu item
	
protected:
		
		
	static uint sm_uiNumberOfMenus;

	// item data
	HMENU		m_hHandle = NULL;
	menu_item	m_mi;
	

	DWORD		m_dwNumberId;
	string		m_strID;
	UINT		m_uiFlags;
	UINT_PTR	m_uIDorHandle;
	string		m_strItemText;
	
	uint		m_next_item_pos = 0;

	// Find the menu item with the strId, and then uuse it to change the menu;
	static menu* findMenuItem(string strId);
	static void  applyChangedToMenuItem();

	static map<HMENU, UINT> sm_mapMenuToItemNumber;

	bool setCheckedStatus(UINT uiState);
	bool setEnabledStatus(UINT uibState);
	   	 
protected:	

	// Map for all item in this object fx key = "FILE_NEW"
	//static map<string, menu*> m_mapStringToMenuItem;
	

	
	// Map for all items in all menu_item objects
//	static map<string, menu_item*> sm_mapStringIdToMenuItem;

	

	static bool sm_bMenuItemCreated;
	
	//static menu_item* sm_PMenuItem;
protected:
	vector<menu*> m_vectorMenuItems;
	

	//hMenubar = CreateMenu();	
	//hMenu = CreateMenu();

	//AppendMenuW(hMenu, MF_STRING, IDM_FILE_NEW, L"&New");
	//AppendMenuW(hMenu, MF_STRING, IDM_FILE_OPEN, L"&Open");
	//AppendMenuW(hMenu, MF_SEPARATOR, 0, NULL);
	//AppendMenuW(hMenu, MF_STRING, IDM_FILE_QUIT, L"&Quit");
	//AppendMenuW(hMenubar, MF_POPUP, (UINT_PTR)hMenu, L"&File");
public:
	class item
	{
	public:
		item();
		
		item(UINT _id, string strText, UINT uiFlags = 0);
		
		item(string strText, UINT uiFlags = 0);

		UINT getId();

		operator UINT();
	
	protected:
		UINT m_uiItemId;
		sz m_szItemText;
		UINT m_uiItemFlags;
		menu* m_poMenu;

		

		MENUITEMINFO m_ItemInfo;
	};

	


};


