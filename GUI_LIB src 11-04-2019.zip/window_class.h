#pragma once
/**********************************************************************************************************
	[File:]
	base.h

	[Author]
	phazer

	[Created]
	15/11/2018 00:00

	[Edited]
	06/12/2018 18:16

	[Description:] Base class defintionion for the entire GUI lib. Provides the functions that are
	common far all derived classes.
***********************************************************************************************************/

// #include "stdafx.h"
#include "base.h"
#include "process.h"

#define WC_DEFAULT "DEFAULT"


using namespace std;


struct window_class_struct {
	
	WNDCLASSEX m_sWindowClass;
	string m_strClasnName;
	ATOM m_atmAtomID;

	
};




class window_class final : public base
{
public:
	/*window_class();
	window_class(string strDefaultClassName);

	window_class(string strName, WNDPROC wndproc, UINT uiWmdExtra = 0);*/

	operator WNDCLASSEX*()
	{
		return &m_sClassInfo.m_sWindowClass;
	}

	operator WNDCLASSEX()
	{
		return m_sClassInfo.m_sWindowClass;
	}


	

	operator string()
	{		
		return m_sClassInfo.m_sWindowClass.lpszClassName;
	}
	
	operator LPCSTR()
	{
		return m_sClassInfo.m_sWindowClass.lpszClassName;
	}

	

	bool create_default(string strName, WNDPROC wndproc, UINT uiWmdExtra = 0);

	operator ATOM();

	WNDCLASSEX wcex;


	


	void copy(WNDCLASSEX* pSource);

public:
	static window_class* DefaultWindowClass;
	static constexpr char  DefaultWinowClassName[] = WC_DEFAULT;

protected:
	window_class_struct m_sClassInfo;

		
	
	
};
