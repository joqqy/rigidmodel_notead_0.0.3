// #include "stdafx.h"
#include "window.h"

/******************************************************************************************************************
*
*	The OOP window procecdure - called from the object ptr
*
******************************************************************************************************************/
LRESULT window::WindowProcedure(HWND _hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	//ZeroMemory(&m_poWmMessage, sizeof(wm_message));



	window* poWindow = _getWindowPtrFromHandle(_hwnd);

	// Set the last message info
	m_oLastMessage.poSourceWindwow = poWindow;
	m_oLastMessage.hwndSource = _hwnd;
	m_oLastMessage.uiMessage = message;
	m_oLastMessage.wParam = wParam;
	m_oLastMessage.lParam = lParam;
	m_oLastMessage.wHIWORD = HIWORD(wParam);
	m_oLastMessage.wLOWORD = LOWORD(wParam);

	LRESULT lrDynamicMesageHandlerReturn = t_processMessageEvent(_hwnd, message, _getWindowPtrFromHandle(_hwnd), wParam, lParam);

	window * temp = NULL;
	RECT rcTemp;

	///////////////////////////////////////////////////////////////////////////////
	//	The main "switch" statement for the event driven action of the program
	///////////////////////////////////////////////////////////////////////////////
	switch (message)
	{

	case WM_HOTKEY:
		
		
		

		break;

		/*{
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hwnd, &ps);
	*/


	//	ostringstream convert;

//		
//		convert << "<" << m_x << ", " << m_y << ">  <" << m_width << ", " << m_height << ">";
//		string strX = convert.str();
//		
//		
//
//		/*convert << m_y;
//		string strY = convert.str();
//*/
//		
//		int len = strX.length();
//
//		/*SetBkColor(hdc, RGB(252, 255, 252));
//		Rectangle(hdc, ps.rcPaint.left, ps.rcPaint.top, ps.rcPaint.right, ps.rcPaint.bottom);*/
//		TextOut(hdc, 0, 0, strX.c_str(), len );
//		//TextOut(hdc, 10, 30, strY.c_str(), strlen(strY.c_str() + 1));
//		
//

	/*	EndPaint(hwnd, &ps);
		return 1L;
	}
	break;*/
	_case_(WM_CREATE, reinterpret_cast<CREATESTRUCT*>(lParam));
		
	
	_case(WM_NCACTIVATE, (bool)wParam, lParam);
	
	_case(WM_ACTIVATE, LOWORD(wParam), HIWORD(wParam),(HWND)(lParam));

	_case(WM_SYSCOMMAND, wParam, LOWORD(lParam), HIWORD(lParam));
	
	_case(WM_COMMAND, HIWORD(wParam), LOWORD(wParam), (HWND)lParam);

	_case(WM_NOTIFY, reinterpret_cast<NMHDR*>(lParam));

	_case(WM_ERASEBKGND, reinterpret_cast<HDC>(wParam));

	
	//_case_int(WM_PAINT);


	

	
		_case(WM_MOVE, wParam, lParam);

		_case(WM_CLOSE);

		CASE_WL(WM_SIZE);



	default:
		return DefWindowProc(_hwnd, message, wParam, lParam);

	}
	return 0;
}



/*****************************************************************************************************************
	The static/global callback WndProc, that the API needs
*******************************************************************************************************************/
LRESULT CALLBACK window::_WndProc(HWND hWindow, UINT uiMessage, WPARAM wParam, LPARAM lParam)
{

	window* temp = getThisFromWindowMemory(hWindow);

	if (temp == nullptr)
	{
		temp = sm_pTempThis;
		putThisIntoWindowMemory(hWindow, temp);

	}
	else
	{
		return temp->WindowProcedure(hWindow, uiMessage, wParam, lParam);

	}

}



