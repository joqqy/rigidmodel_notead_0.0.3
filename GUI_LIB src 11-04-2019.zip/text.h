#pragma once
// #include "stdafx.h"
#include "base.h"






class text : public base
{
public:
	text();	
	text(char const * _cszInput);
	text(char * _szInput);
	
	

	static sz createNewBufferFromSZ(csz _szText);
	static sz makeCopyOfSZ(csz _szText);


	operator text() { return *this; }
	operator text&() { return *this; }
	operator sz() { return m_szBuffer; }
	operator csz() { return m_szBuffer; }
	operator std::string() { return m_szBuffer; };
	

	//text & operator=(const char*& );	
	//sz operator+=(csz cszInput);
	//
	//const char & operator=(const text&);	
	////csz operator=(csz cszInput);

	////text&  operator+=(const text&);	

	//const char* operator=(text&);
	//
	//text & operator=(const char*);
	//
	//text& operator+(char const* _cszinput);

	//text operator+(char const*& _cszinput);
	//

	

	csz operator<<(sz cszInput)
	{
		csz s = add(cszInput);
		return text(s);
	}

	text operator<<(csz cszInput)
	{
		csz s =  add(cszInput);
		return text(s);		
	}

	
	

	
	//{
	//	/*size_t old_size = m_buffer_size;
	//	sz temp_buffer = new char[m_buffer_size];

	//	memcpy(temp_buffer, m_szBuffer, m_buffer_size);

	//	allocate(m_szBuffer, m_buffer_size + strlen(txt.m_szBuffer) - 1);
	//	memcpy(m_szBuffer, temp_buffer, old_size);
	//	memcpy(&m_szBuffer[old_size - 1], txt.m_szBuffer, strlen(txt.m_szBuffer) + 1);*/

	//	add(_cszinput);

	//	m_poTxtTemp = new text(_cszinput);

	//	return *m_poTxtTemp;
	//}

	//const text&  operator+=(const char*  cszInput);
	
	/*text& operator=(text const& _oInput)
	{
		assign(_oInput.m_szBuffer);

		m_poTxtTemp = new text(_oInput.m_szBuffer);

		return *m_poTxtTemp;

	}
*/
	
	csz assign(csz _cszInput);


	//text & operator+(const char*);
	//text & operator+(const text&);

	//const char * operator+(text&);

	//csz operator+(text & cszInput);

	//csz operator+(csz & cszInput);

	//char & operator[](int index);
	//const char & operator[](int index) const;
	
	//static sz operator+(text, text);

	//static sz operator+(text, csz);
	
	
	

protected:

	void deallocate(sz &_szBuffer);
	

	sz  allocate(sz & _szBuffer, dw dwSize);

	
	
	
	void deallocate();




//	csz  assign(csz szInput);
	
	csz add(csz _cszInput);


protected:
	static  sz sm_szStaticBuffer;
	sz		m_szBuffer			= NULL;
	sz		m_szNewBuffer		= NULL;
	sz		m_szTempBuffer		= NULL;	

	static sz sm_szGlobal;

	size_t	m_buffer_size		= 0;
	char	m_chError			= '\0';
	text*	m_poTxtTemp = NULL;

	
	
};


//
//void d()
//{
//	text t = "Test12" + "etsetss";
//
//	t = "test1" "Test2" +  "sdfsdgsdg" ;
//}