// #include "stdafx.h"
#include "font.h"
#include "window.h"


font::font()
{
	m_hGDIObjHandle = NULL;
}

font::font(const HFONT _font)
{
	m_hGDIObjHandle = _font;
}

void font::setWidth(LONG width)
{
	m_oLogFont.lfWidth = width;
	//_delete();
	createIndirect();
}



font::~font()
{
}

HFONT font::create(int _size, int _width, const char _cszTypeFaceName[32], int _boldness, BYTE _quality, bool _bItalic, bool _bUnderline, bool _bStrikOut)
{
	if (m_hGDIObjHandle)
		DeleteObject(m_hGDIObjHandle);

	BYTE  bItalic = _bItalic;
	BYTE  bUnderline = _bUnderline;
	BYTE  bStrikeOut = _bStrikOut;

	/*m_oLogFont.lfHeight	= -MulDiv(_size, GetDeviceCaps(_hdc, LOGPIXELSY);
	m_oLogFont.lfWidth	= 0;
	m_oLogFont.lfEscapement = 0;
	m_oLogFont.lfOrientation = 0;
	m_oLogFont.lfWeight = _boldness;
	m_oLogFont.lfItalic = bItalic;
	m_oLogFont.lfUnderline = bUnderline;
	m_oLogFont.lfStrikeOut = bStrikeOut;
	m_oLogFont.lfOutPrecision = */

	


/*
	m_oLogFont = { -MulDiv(-((int)_size), GetDeviceCaps(_hdc, LOGPIXELSY), 72), 0, 0, 9, _boldness, bItalic, bUnderline, bStrikeOut, DEFAULT_CHARSET, OUT_TT_PRECIS,
		CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, FIXED_PITCH, TEXT("Tahoma") };
	*/

	HDC _hdc = GetDC(GetDesktopWindow());


	
	//LONG font_size = -(_size);
	m_oLogFont = {
		-MulDiv(_size, GetDeviceCaps(_hdc, LOGPIXELSY), 72),
		_width,
		0,
		9,
		_boldness,
		FALSE,
		FALSE,
		FALSE,
		DEFAULT_CHARSET,
		OUT_DEFAULT_PRECIS	,
		CLIP_DEFAULT_PRECIS,
		_quality,
		DEFAULT_PITCH | FF_ROMAN,
		
	};

	memcpy(m_oLogFont.lfFaceName, _cszTypeFaceName, 32);

	m_hGDIObjHandle = CreateFontIndirect(&m_oLogFont);

	return m_hGDIObjHandle;
}

HFONT font::createIndirect()
{
	
	m_hGDIObjHandle = CreateFontIndirect(&m_oLogFont);

	return m_hGDIObjHandle;
}

font::operator HFONT()
{
	return m_hGDIObjHandle;;
}

HFONT & font::operator=(const HFONT & _font)
{
	m_hGDIObjHandle = _font;

	return m_hGDIObjHandle;
}

void font::linkWindow(window * _poWin)
{
	_poWin->setText("Test");
}

void font::updateWindow()
{
	
}
