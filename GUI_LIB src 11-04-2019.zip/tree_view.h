#pragma once

#include "window.h"
#include <CommCtrl.h>






	



//
//struct tree_view_vitem
//{
//	// use this the pointers to struct or any than will be stored within the item
//	void setParam(LPARAM lParam);
//	void setSelectedImage(int iImage);
//	void setImage(int iImage);
//
//	void update();
//
//	window* m_PParentWindow;
//	TVITEMEX TreeItemEx;	
//};

class tree_window_parent : public window
{

	public:
	

	protected:
	//	virtual LRESULT case_WM_NOTIFY(NMHDR* pmnh);
		
		
};




class tree_view : public window
{
public:
	bool _createEx(window * PParentWindow, int x, int y, int width, int height);
	HTREEITEM inserItem(HTREEITEM hParent, HTREEITEM hIsertAfter, string strText, LPARAM = NULL);
	
	void setItem(	string strKey, UINT uiMask = 0, UINT uiStateMask = 0, LPSTR szItemText = NULL, int iBufferLength = 0,
					int iImage = 0);
	void delteItem(HTREEITEM hItem);	
	

	

	void setImageList(HIMAGELIST hImageList);
	
protected:
	virtual LRESULT case_WM_NOTIFY(NMHDR* pmnh);
	//static HTREEITEM m_hPrevious = (HTREEITEM)TVI_FIRST;
protected:

	TVITEMEX m_tvItem;

//	window* m_PParentWindow;
	tree_window_parent m_parent_window;
	
	window  m_tree_view_window;

	menu m_hMwnu;


	UINT m_uiId;

	menu m_popup_menu;
}; 
 


//
//
//struct StrInt 
//{
//
//	string strKey;
//	int iValue;
//};
//
//StrInt si1;
//
//
//
//class SafeEnum
//{
//public:
//	
//	SafeEnum(const StrInt &str_int)
//	{
//		m_mapValue[str_int.strKey] = str_int.iValue;
//	}
//
//
//	StrInt operator=(const StrInt &str_int)
//	{
//		m_mapValue[str_int.strKey] = str_int.iValue;
//		return str_int;
//		
//	}
//	map<string, int> m_mapValue;
//
//
//	
//};
//
//
//
//HWND CreateATreeView(HWND hwndParent)
//{
//	RECT rcClient;  // dimensions of client area 
//	HWND hwndTV;    // handle to tree-view control 
//
//	// Ensure that the common control DLL is loaded. 
//	InitCommonControls();
//
//	// Get the dimensions of the parent window's client area, and create 
//	// the tree-view control. 
//	GetClientRect(hwndParent, &rcClient);
//	hwndTV = CreateWindowEx(0,
//		WC_TREEVIEW,
//		TEXT("Tree View"),
//		WS_VISIBLE | WS_CHILD | WS_BORDER | TVS_HASLINES,
//		0,
//		0,
//		rcClient.right,
//		rcClient.bottom,
//		hwndParent,
//		(HMENU)ID_TREEVIEW,
//		g_hInst,
//		NULL);
//
//	// Initialize the image list, and add items to the control. 
//	// InitTreeViewImageLists and InitTreeViewItems are application- 
//	// defined functions, shown later. 
//	if (!InitTreeViewImageLists(hwndTV) ||
//		!InitTreeViewItems(hwndTV))
//	{
//		DestroyWindow(hwndTV);
//		return FALSE;
//	}
//	return hwndTV;
//}