#pragma once
#include "base.h"
class device_context :
	public base
{
public:
	device_context();
	virtual ~device_context();

	
	void selectObject(const HGDIOBJ _hObj);;

	

protected:
	HGDIOBJ m_hOldObject = NULL, m_hCurreentObject = NULL;

};

