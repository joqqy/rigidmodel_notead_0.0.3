#pragma once
#include "base.h"


template <class T>
class tree
{
public:
	void insertItem(tree* PParent, const tree Item, string strID)
	{
		m_vecChidren.push_back(Item)
		sm_mapAllItems[strdId] = Item;
	}
	
	tree* getParent()
	{
		return m_PParentTree;
	}

	uint getNumberOfChildren()
	{
		return m_vecChildren.size();
	}

	tree getChild(uint uiChildNUmber)
	{
		return m_vecChildren[uiChildNUmber];
	}

	// each call get the next child, until no more then returns NULL
	bool getChildren(tree* PDest)
	{		
		if (m_dwChildLoopCounter = > m_vecChildren.size())
		{
			m_dwChildLoopCounter = 0;
			return false;
		}

		*PDest = vector[m_dwChildLoopCounter++];
		return true;
	}


protected:
	T m_value;
	tree* m_PParent;
	tree* m_PRoot;
	
	uint m_uiNumberofChildren = 0;		
	DWORD m_dwChildLoopCounter = 0;

	vector<tree> m_vecChildren;
	static map<string, tree> sm_mapAllItems;
};

template <class T>
map<string, tree<T>> tree<T>::sm_mapAllItems;


