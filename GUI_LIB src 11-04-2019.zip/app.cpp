// #include "stdafx.h"
#include "app.h"



app* app::CurrentApp = NULL;

LRESULT app::createMainWindow()
{
	
	return LRESULT();
}
