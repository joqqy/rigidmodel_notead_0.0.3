#pragma once
#include "window.h"
class tool_tip :
	public window
{
public:
	tool_tip();
	virtual ~tool_tip();
	bool create(window *_poParent, int style);

	void addTool(window* _poParent, window* _poTool, csz _cszText); //TODO: make this work

};

