#pragma once
/**********************************************************************************************************
	[File:]
	base.h

	[Author]
	phazer

	[Created]
	15/11/2018 00:00

	[Edited]
	06/12/2018 18:16

	[Description:] Base class defintionion for the entire GUI lib. Provides the functions that are
	common far all derived classes.
***********************************************************************************************************/




// #include "stdafx.h"
#include "base.h"
#include "thread.h"


using namespace std;

class window;

#define H_INST *process::sm_poCurrentProcess
#define wm(msg) virtual LRESULT   on##msg(window * PWin, WPARAM wParam, LPARAM lParam) 


class process :
	public base
{

public:



	friend
		int CALLBACK APIENTRY WinMain(_In_ HINSTANCE hInstance,
			_In_opt_ HINSTANCE hPrevInstance,
			_In_ LPSTR    lpCmdLine,
			_In_ int       nCmdShow);


	// start this program
	process();

	process(UINT uiAccelId);

	// starts en external .exe or .com file
	//process(string strEx, string strCmdline);

	virtual ~process();

	// returns the HINSTANCE of the current module
	operator HINSTANCE();

	virtual LRESULT setupHandlers();

	// Sets up the event handler before any windows are created to be able to process the earliest messages
	//virtual LRESULT setupHandlers();


	// Overideable: This is the OOP wrappers entrypoint, the messageloop starts immediately after

	// create the main window
	virtual LRESULT createMainWindow();



	// Do program initialization here 
	virtual LRESULT onCreated();
	virtual int onQuit(int _exit_code);

	static bool initialize();


	//Do cleanup here
	virtual LRESULT onExit();

	virtual LRESULT onIdle();

	virtual int onError(int);

	static void error_kill(int ret);

	static string getLastErrorString();

	static void quit(int);

public:

#define COLOR_LEN 7
	CONST INT m_I[COLOR_LEN] = { COLOR_BTNTEXT, COLOR_ACTIVECAPTION, COLOR_BTNFACE, COLOR_BACKGROUND, COLOR_BTNHIGHLIGHT, COLOR_BTNTEXT, COLOR_ACTIVECAPTION };
	COLORREF m_crOld[COLOR_LEN];
	COLORREF m_crNew[COLOR_LEN] = { RGB(0x0, 0x80, 0x0), RGB(0x0, 0x00, 0x80), RGB(130,130,130), RGB(10,100,50), RGB(200,00,00), RGB(0,0,100), RGB(200,100,100) };



protected:
	static LRESULT loadAccelerators(UINT uiID);

	static int MessageLoop();



	static int APIENTRY WinMain(_In_ HINSTANCE hInstance,
		_In_opt_ HINSTANCE hPrevInstance,
		_In_ LPSTR    lpCmdLine,
		_In_ int       nCmdShow);

	string m_strExeFile;
	string m_strCommandLine;
	
//	static string strCommandLine;





public:
	static		string strCommandLine;
	static		HACCEL m_hAcceleratorTableHandle;

	static thread	sm_mainThread;


	static process* sm_poCurrentProcess;
	int			m_iCmdShow;
	bool		m_bRunIdle = false;

	HINSTANCE	m_hInstance;
	HINSTANCE	m_hPrevInstance;
};



