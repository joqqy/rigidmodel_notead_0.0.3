// #include "stdafx.h"
#include "file.h"



file::file()
{
	ZeroMemory(m_szFileBuffer, FILE_BUFFERSIZE);
}


file::~file()
{
}



// // open a file dialog
LRESULT file::openFileDialog(window* _poWinOwner)
{	
	      // if using TCHAR macros

	// Initialize OPENFILENAME
	ZeroMemory(&m_ofn, sizeof(m_ofn));
	m_ofn.lStructSize = sizeof(m_ofn);
	m_ofn.hwndOwner = *_poWinOwner;
	m_ofn.hInstance = H_INST;
	m_ofn.lpstrFile = m_szFileBuffer;
	m_ofn.lpstrFile[0] = '\0';
	m_ofn.nMaxFile = FILE_BUFFERSIZE;
	m_ofn.lpstrFilter = "Text Files (*.rigid_model_v2)\0*.rigid_model_v2\0All Files (*.*)\0*.*\0";
	m_ofn.nFilterIndex = 1;
	m_ofn.lpstrFileTitle = NULL;
	m_ofn.nMaxFileTitle = 0;
	m_ofn.lpstrInitialDir = NULL;
	m_ofn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST | OFN_ALLOWMULTISELECT | OFN_EXPLORER;


	if (GetOpenFileName(&m_ofn) == TRUE)
	{
		m_strFile1 = &m_ofn.lpstrFile[strlen(m_ofn.lpstrFile)+1];

		if (m_strFile1 == "")
		{
			m_strPath = m_ofn.lpstrFile;
			return 1;
		}

		m_strDir = m_ofn.lpstrFile;
		
		m_strPath = m_strDir;
		m_strPath += "\\";
		m_strPath += m_strFile1;
		

		return 1;
	}

	
	return 0;
	
}

LRESULT file::saveFileDialog(window * PWinOwner)
{
	ZeroMemory(&m_ofn, sizeof(m_ofn));

	m_ofn.lStructSize = sizeof(m_ofn);
	m_ofn.hwndOwner = NULL;
	m_ofn.lpstrFilter = "Text Files (*.rigid_model_v2)\0*.rigid_model_v2\0All Files (*.*)\0*.*\0";
	m_ofn.lpstrFile = m_szFileBuffer;
	m_szFileBuffer[0] = '\0';
	m_ofn.nMaxFile = MAX_PATH;
	m_ofn.Flags = OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_HIDEREADONLY;
	m_ofn.lpstrDefExt = (LPCSTR)"txt";

	

	LRESULT lr = GetSaveFileName(&m_ofn);

	m_strPath = m_ofn.lpstrFile;

	return lr;
}

file::operator string()
{
	return m_strPath;
}

//file::operator sz()
//{
//	return m_strPath.c_str();
//}

file::operator csz()
{
	return m_strPath.c_str();
}

