// #include "stdafx.h"
#include "text.h"



//text::text()
//{
//}

//text::text(sz _szInput)
//{
//	assign(_szInput);
//}
//
//text::text(size_t size, bool bCreatNewBuffer)
//{
//	if (bCreatNewBuffer)
//	{
//		m_szNewBuffer = new char[size];
//		m_bReturnNewBuffer = true;
//	}
//	else
//	{
//		allocate(m_szBuffer, size);
//		m_bReturnNewBuffer = false;
//	}
//}





//
//text::text(const text & refText)
//{
//	deallocate();
//
//	allocate(strlen(refText.m_szBuffer));
//	strcpy_s(m_szBuffer, strlen(refText.m_szBuffer), refText.m_szBuffer);
//
//}

text::text()
{

}

text::text(char const * _cszInput)
{
	assign(_cszInput);
}

//
//text::~text()
//{
//	deallocate();
//}

sz text::createNewBufferFromSZ(csz _cszText)
{
	sz szTemp = new char[strlen(_cszText) + 1];
	return szTemp;
}

sz text::makeCopyOfSZ(csz _cszText)
{
	// save lenth, so that the costly strlen does not need to be called TWICE
	uint len = strlen(_cszText) + 1;

	// create new buffer and copy the SZ
	sz szTemp = new char[len];
	strcpy_s(szTemp, len, _cszText);

	return szTemp;
}


csz text::assign(csz _cszInput)
{

	allocate(m_szBuffer, 100);

	if (m_szBuffer)
		delete[] m_szBuffer;

	m_buffer_size = strlen(_cszInput) + 1;
	m_szBuffer = new char[m_buffer_size];


	memcpy(m_szBuffer, _cszInput, m_buffer_size);
	return m_szBuffer;
}

void text::deallocate(sz &_szBuffer)
{
	if (_szBuffer)
		delete _szBuffer;
}
sz text::allocate(sz & _szBuffer, dw dwSize)
{
	deallocate(_szBuffer);
	m_buffer_size = dwSize;
	sz szTemp = new char[m_buffer_size];

	_szBuffer = szTemp;
	return szTemp;
}
void text::deallocate()
{
	deallocate(m_szBuffer);
	deallocate(m_szTempBuffer);
	deallocate(m_szNewBuffer);
}
csz text::add(csz _cszInput)
{
	if (m_szBuffer == NULL)
	{
		assign(_cszInput);
	}




	if (m_szTempBuffer)
		delete m_szTempBuffer;

	if (_cszInput == NULL)
	{
		//assign("ERROR: text::add. param = NULL.");
	}

	// create buffer that is large enough for both the old and the new
	uint len = strlen(_cszInput) + strlen(sm_szGlobal) + 2;
	m_szTempBuffer = new char[len];


	// copy the old to the start of the buffer

	memcpy(m_szTempBuffer, m_szBuffer, strlen(m_szBuffer) + 1);

	// copy the just after the old in the buffer

	//memcpy(&m_szTempBuffer[strlen(m_szBuffer)-1], _cszInput, strlen(_cszInput));

	/*if (m_szBuffer)
		delete m_szBuffer;*/
	m_szBuffer = m_szTempBuffer;


	return sm_szGlobal;
}
// szInput
//text& text::operator+(char const* _cszinput)
//{
//	/*size_t old_size = m_buffer_size;
//	sz temp_buffer = new char[m_buffer_size];
//	
//	memcpy(temp_buffer, m_szBuffer, m_buffer_size);
//	
//	allocate(m_szBuffer, m_buffer_size + strlen(txt.m_szBuffer) - 1);
//	memcpy(m_szBuffer, temp_buffer, old_size);
//	memcpy(&m_szBuffer[old_size - 1], txt.m_szBuffer, strlen(txt.m_szBuffer) + 1);*/
//
//	add(_cszinput);
//
//	return *this;
//}

//text & text::operator=(class text const& _oInput)
//{
//	assign(_oInput.m_szBuffer);
//
//	return *this;
//}

//char & text::operator[](int index)
//{
//	if (index < 0 || index >= m_buffer_size-1)
//		return m_chError;
//
//	return 	m_szBuffer[index];
//}

//text::text(char * _szInput)
//{
//	assign(_szInput);
//}





//csz text::add(csz _cszInput)
//{
//	if (m_szBuffer == NULL)
//	{
//		//assign(_cszInput);
//		return "ERROR";
//	}
//
//	//if (m_szTempBuffer)
//	//	delete m_szTempBuffer;
//
//	if (_cszInput == NULL)
//	{
//		//assign("ERROR: text::add. param = NULL.");
//	}
//
//	// create buffer that is large enough for both the old and the new
//	uint len = strlen(_cszInput) + strlen(m_szBuffer);
//	//szTempBuffer = new char[len];
//	
//	
//	// copy the old to the start of the buffer
//
//	//memcpy(m_szTempBuffer, m_szBuffer, strlen(m_szBuffer)+1);
//
//	// copy the just after the old in the buffer
//	
//	//memcpy(&m_szTempBuffer[strlen(m_szBuffer)-1], _cszInput, strlen(_cszInput));
//	
//	/*if (m_szBuffer)
//		delete m_szBuffer;*/
//	m_szBuffer = m_szTempBuffer;
//
//}


char* text::sm_szGlobal = NULL;

