// #include "stdafx.h"
#include "edit_box.h"



edit_box::edit_box()
{
}


bool edit_box::create(window * pParentWindow, LPCSTR szContent, DWORD dwExstyle, DWORD dwStyle, LPVOID pParam, int x, int y, int width, int height, bool bFollowParent)
{
	return (0 != _createEx(pParentWindow, WC_EDIT, szContent, dwExstyle, dwStyle, NULL, x, y, width, height));
}

edit_box::~edit_box()
{
}

edit_box::edit_box(window * _PParentWindow, window_template _wt, int _x_offset, int _y_offset, int _width_offset, int _height_offset)
{

	m_template = _wt;
	m_template.PParentWindow = _PParentWindow;
	m_template.x += _x_offset;
	m_template.y += _y_offset;
	m_template.width += _width_offset;
	m_template.height += _height_offset;
	m_template.height += _height_offset;

	if (_PParentWindow == NULL)
		return;
		

	((edit_box*)_PParentWindow)->_addChildToCreate(this);
	((edit_box*)_PParentWindow)->m_bCreateFromInternalTamplate = true;

}

//LRESULT edit_box::create(window * PParent, int x, int y)
//{	
//	// TODO: finish this
//	return LRESULT();
//}

LRESULT edit_box::create(window * PParent, window_template wt, int x_offset, int y_offset, int width_offset, int height_offset)
{
	// TODO: Write the method
	return LRESULT();
}

LRESULT edit_box::create(window * PParent, int x, int y, int width, int height, uint uiExStyles, uint uityles)
{// TODO: Write the method
	return LRESULT();
}

LRESULT edit_box::processOwnNotification(UINT id)
{
	if (EN_CHANGE)
	{

	}
	
	return LRESULT();
}

sz & edit_box::operator=(const sz)
{
	m_strTemp = getText();                       


	cond_del(m_szTemp);

	return m_szTemp;

}
string & edit_box::operator=(const string str)
{
//	cond_del(m_szText);
	//m_szText = new char[strlen(str.c_str()) + 1];
	//strcpy_s(m_szText, strlen(str.c_str()) + 1, str.c_str());
	
	setText(str.c_str());
	
	m_strTemp = str;
	return m_strTemp;

}



char & edit_box::operator[](uint index)
{
	cond_del(m_szTemp);
	m_szTemp = getText();

	if (index < 0 || index >(strlen(m_szTemp) - 1))
		return m_szText[0];

	return m_szText[index];
}

bool edit_box::setReadOnly(bool bState = true)
{	
	return sendMessage(EM_SETREADONLY, bState ? 1 : 0, 0);
}

bool edit_box::isReadOnly()
{
	return (getLongPtr(GWL_STYLE) & ES_READONLY) == 0 ? false : true;
}

sz edit_box::getSelection()
{
	dword dwStart, dwEnd;
	   
	_sendMessage(EM_GETSEL, &dwStart, &dwEnd);

	if (dwStart == dwEnd)
	{
		m_szText = new char[1];
		m_szText[0] = '\0';
		return m_szText;
	}


	string strTemp = Caption;

	dword len = dwEnd - dwStart;
	m_szText = new char[len + 1];
	
	ZeroMemory(m_szText, len + 1);
	char a = strTemp.c_str()[dwStart];
	
	
	memcpy_s(m_szText, len, &strTemp.data()[dwStart], len);



	return m_szText;
}

bool edit_box::hasChanged()
{
	return m_bHasChanged;
}

void edit_box::resetChangedStatus()
{
	m_bHasChanged = false;
}



