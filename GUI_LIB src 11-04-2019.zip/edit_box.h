#pragma once

// #include "stdafx.h"
#include "control_window.h"



struct edit_box_template : public window_template
{

};


//window_template default_button = {WC_BUTTON, "Empty...", WS_EX_STATICEDGE, 0, NULL, 0, 0, 10, 15, false};


class edit_box :
	public control_window
{
public:
	
	edit_box();

	edit_box(window* pParentWindow,
		LPCSTR szContent, DWORD dwExstyle, DWORD dwStyle, LPVOID pParam = NULL, int x = CW_USEDEFAULT, int y = CW_USEDEFAULT,
		int  width = CW_USEDEFAULT, int height = CW_USEDEFAULT, bool bFollowParent = false
	) 
		: control_window(pParentWindow, WC_EDIT, szContent, dwExstyle, dwStyle, pParam, x, y, width, height, bFollowParent)
	{
	}

	virtual bool create(window* pParentWindow,
		LPCSTR szContent, DWORD dwExstyle, DWORD dwStyle, LPVOID pParam = NULL, int x = CW_USEDEFAULT, int y = CW_USEDEFAULT,
		int  width = CW_USEDEFAULT, int height = CW_USEDEFAULT, bool bFollowParent = false
	);

	virtual ~edit_box();

	edit_box(window* PParent, window_template wt, int x_offset = 0, int y_offset = 0,
		int width_offset = 0, int height_offset = 0);
	

	virtual LRESULT create(	window* PParent, window_template wt, int x_offset = 0, int y_offset = 0, 
							int width_offset = 0, int height_offset = 0);

	virtual LRESULT create(window* PParent, int x, int y, int width, int height, uint uiExStyles, uint uityles);

	

	virtual LRESULT processOwnNotification(UINT id) override;

	sz & operator= (const sz );
	string & operator= (const string);
	int & operator= (const int &) { return m_iValue; };
	uint & operator= (const uint &) { return m_uiValue; };

	char & operator[] (uint index);

	virtual bool setReadOnly(bool bState);
	virtual bool isReadOnly();

	sz getSelection();
	bool hasChanged();
	void resetChangedStatus();

protected:
	string m_strTemp = "";
	sz m_szTemp = nullptr;
	int m_iValue;
	uint m_uiValue;
	bool m_bHasChanged = false;


};

// TODO: check this
//edit_box EBLine_1 = window{}

