#pragma once
#include "base.h"


using namespace std;

template <class T>
class array {

public:
	array(T* pt)
	{

	}


	array()
	{

	}

	array(u32 size, string init = "")
	{
		allocate(size);
	}


	T & operator[](int index)
	{
		return m_pBuffer[index];

	}


	void * operator new(size_t size)
	{
		array<T> * ptemp = new array<T>;
		ptemp->allocate(size);
		return ptemp;
	}

	array* allocate(size_t size, bool delete_array = false)
	{
		if (m_pBuffer) // already allocated?
		{
			m_pTempBuffer = new T[m_dwBufferSize];   // crete temp buffer for old dawta
			m_dwTempufferSize = m_dwBufferSize;

			memcpy(m_pTempBuffer, m_pBuffer, m_dwBufferSize * sizeof(T)); // copy old data to temp buffer

			delete[] m_pBuffer; // delete old buffer

			m_dwBufferSize = size;   // allocate new buffer and copy the old data into it
			m_pBuffer = new T[m_dwBufferSize];

			memcpy(m_pBuffer, m_pTempBuffer, m_dwTempufferSize * sizeof(T));

		}
		else
		{
			m_dwBufferSize = size;
			m_pBuffer = new T[m_dwBufferSize];

		}

		return this;
	}


	

protected:
	T* m_pBuffer = nullptr;
	dword m_dwBufferSize = 0;

	T* m_pTempBuffer = nullptr;;
	dword m_dwTempufferSize = 0;

};

