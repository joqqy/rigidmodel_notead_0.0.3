#pragma once
#pragma once

/**********************************************************************************************************
	[File:]		windows.h
	[Author:]	phazer
	[Created:]	15/11/2018 00:00
	[Edited:]	02/01/2019 20:15

	[Description:]
	Window Class declartion for GUI LIB

***********************************************************************************************************/

// #include "stdafx.h"
#include "window_base.h"
#include "process.h"
#include "menu.h"
#include "event_handler.h"
#include "window_class.h"
#include "thread_local_data.h"
#include "font.h"
#include "properties.h"
#include <vector>
#include "event.h"
#include "internal_message_handlers.h"
#include "var.h"
class window;



//#include <resource1.h>
#include <Commctrl.h>

#define _hwnd m_hHandle 
#define space(T) T

#define _case(msg, ...)\
	case space( ) ##msg: return this->case_##msg(__VA_ARGS__); break;

#define _case_(msg, ...) case space( ) ##msg: \
		m_window_message_handler.exec<##msg>(__VA_ARGS__);\
		return this->case_##msg(__VA_ARGS__); break;\


#define _case_int(msg, ...)\
	case space( ) ##msg: return this->m_internal_message_handlers.case_##msg(__VA_ARGS__); break;


#define CALL_CASE(msg, ...)\
	return this->case_##msg(__VA_ARGS__); break;


#define CASE2(func, msg, ...) case space( ) ##msg:func; return this->case_##msg(__VA_ARGS__); break;

#define CASE_WL(msg) case space( ) ##msg: return this->case_##msg(wParam, lParam ); break;

#define DECL_WM_HANDLER(msg, ...) virtual LRESULT case_##msg(__VA_ARGS__)
#define DEF_WM_HANDLER(msg, ...)  LRESULT window::case_##msg(__VA_ARGS__)
#define DEF_WM_HANDLER(msg, ...)  LRESULT window::case_##msg(__VA_ARGS__)

#define wu�ndow_message_handler(msg, ...) case_##msg(__VA_ARGS__)
#define lr LRESULT

//#define WMH(msg, ...) virtual inline LRESULT case_##msg(__VA_ARGS__)
#define WMH_DECL virtual inline LRESULT
#define WMH_DEF  inline LRESULT

#define _CASE(msg) case_##msg

// Adds assignment operators to derivatives of window
#define WIN_ASSIGN\
	sz & operator=(const sz _csz)\
	{\
		setText(_csz);\
		return m_szText;\
	}\
	string & operator=(const string _str)\
	{\
		setText(_str.c_str());\
		string strret = _str;\
		return strret;\
	}\
	long & operator=(const long _l)\
	{\
		cond_del_al(m_pszTempText, char, 255);\
		_ltoa_s(_l, m_pszTempText, 255, 10);\
		setText(m_pszTempText);\
		long lRet = _l;\
		return lRet;\
	}\
	int & operator=(const int _i)\
	{\
		cond_del_al(m_pszTempText, char, 255);\
		_itoa_s(_i, m_pszTempText, 255, 10);\
		setText(m_pszTempText);\
		int iRet = _i;\
		return iRet;\
	}\

//#define WMH virtual LRESULT 


#define DEF_WM_HANDLER(msg, ...) LRESULT window::case_##msg(__VA_ARGS__)

#define CALL_WM_HANDLER(msg, ...) case_##msg(__VA_ARGS__)

#define _decl_wn_handler(msg, ...) virtual LRESULT WM_HANDLER_##msg(__VA_ARGS__)

#define WS_DEFAULT			WS_OVERLAPPEDWINDOW | WS_BORDER | WS_CAPTION
#define WS_EX_DEFAULT		WS_EX_CLIENTEDGE

#define WINDOW_DESKTOP		GetDesktopWindow()

#define W					(*this)
#define _HWND				m_hHandle
#define THIS_WINDOW			(*this)




#define _sendMessage(msg, wParam, lParam) sendMessage(##msg, reinterpret_cast<WPARAM>(##wParam), reinterpret_cast<LPARAM>(##lParam))



extern POINT g_Point;
extern POINT& DimFromRect(RECT & rc);
extern POINT& PosFromRect(RECT & rc);



//
//class event_type
//{
//	static constexpr int type_invalid = 0;
//	static constexpr int type_wm_event = 1;
//	static constexpr int type_menu_event = 2;
//	static constexpr int type_control_event = 3;
//};



struct _event
{
	constexpr static int TYPE_WM_EVENT = 0;
	constexpr static int TYPE_MENU_EVENT = 1;
	constexpr static int TYPE_CTRL_EVENT = 2;
	constexpr static int TYPE_ACCELL_EVENT = 2;

	uint type;
	uint id;
	window* source;

};




struct menu_handler : public _handler<pmf::MenuItemHandlerFunc>
{
	virtual LRESULT invoke(WPARAM wParam, LPARAM lParam)
	{
		return InvokePMF(PObject, pmf, LOWORD(wParam));
	}
};

//struct control_event_handler : public wm_handler<pmf::ConntrolEventHandlerFunc>
//{
//	virtual LRESULT invoke(WPARAM wParam, LPARAM lParam) override
//	{
//		return InvokePMF(PObject, pmf, reinterpret_cast<window*>(lParam), wParam);
//	}
//
//};

struct msg_handler : public _handler<pmf::WMHandlerFunc>
{
	virtual LRESULT invoke(UINT msg, WPARAM wParam, LPARAM lParam)
	{
		return InvokePMF(PObject, pmf, poWinSource, msg, wParam, lParam);
	}

	window* poWinSource;
};

//struct MsgHandlerInfo
//{
//	virtual LRESULT invoke(WPARAM wParam, LPARAM lParam)
//	{
//		return InvokePMF(PObject, pmf, wParam, lParam);
//	}
//	base *PObject;	
//	pmf::WMHandlerFunc pmf;
//	
//};

struct MenuItemgHandlerInfo
{
	base *PObject;
	pmf::MenuItemHandlerFunc pmf;
	LRESULT invoke(UINT uiID);
};

struct window_template
{
	window_template()
	{};

	window_template(window* _PParent,
		string _strClassName,
		string _strCaption,
		DWORD _dwExstyle, DWORD _dwStyle,
		LPVOID _pParam = NULL,
		int _x = CW_USEDEFAULT,
		int _y = CW_USEDEFAULT,
		int _width = CW_USEDEFAULT,
		int _height = CW_USEDEFAULT,
		bool _bFollowParent = false
	) {
		PParentWindow = _PParent;
		strClassName = _strClassName;
		strCaption = _strCaption;
		dwExStyle = _dwExstyle;
		dwStyle = _dwStyle;
		pParam = _pParam;
		x = _x;
		y = _y;
		width = _width;
		height = _height;
		bFollowParent = _bFollowParent;
	};

	window* PParentWindow;
	string strClassName;
	string strCaption;
	DWORD dwExStyle, dwStyle;
	LPVOID pParam = NULL;
	int x = CW_USEDEFAULT;
	int y = CW_USEDEFAULT;
	int width = CW_USEDEFAULT;
	int height = CW_USEDEFAULT;
	bool bFollowParent = false;

};

#define __handler LRESULT



class _window_events1
{
public:
	__event int test_event(int i);

	int m_i;

};



class window :
	public window_base
{
	
public:
	static _window_events1 m_oWindowEvents;

	

////////////////////////////////////////////////////////////////////////////////
//
//	** HWND **: and other variables
//
/////////////////////////////////////////////////////////////////////////////////
protected:
	string	m_strText;
	// Handle to Win32 Window Object
	sz		m_szText = NULL;;





	friend class control_group;
	friend class check_box_group;
	friend class event_handler_base;
	friend class dialog_box;
	friend class process;

public:
	window()
	{

	}

	window(HWND hwnd)
	{
		m_hHandle = hwnd;
	}


	window(window* PParentWindow, window_template, int x_offset = 0, int y_offset = 0, int width_offset = 0, int height_offset = 0);






	// TODO: make so you can declare child windows with all parameteres in the parent class definition, 
	// TODO: set some (maybe temp) member vars and use the "createFromCopiedValues()" in children  and "createChildren()" in parent

	// fills the relevant variables with the needed info for when it should be created
	window(window* pParentWindow, LPCSTR szClassName,
		LPCSTR szCaption, DWORD dwExstyle, DWORD dwStyle, LPVOID pParam = NULL, int x = CW_USEDEFAULT, int y = CW_USEDEFAULT,
		int  width = CW_USEDEFAULT, int height = CW_USEDEFAULT, bool bFollowParent = false);


	virtual ~window();


	// creates a window object from an existing hwnd and extract all data from the HWND



	// cntrol_event_hanlder handlewr(buttom1, BN_CLICKED, DEST(process1, button1_handler));

	// DEST is macro that make dealing with member funtion pointers more straight forward.

	virtual LRESULT _createEx(window* pParentWindow, LPCSTR szClassName,
		LPCSTR szCaption, DWORD dwExstyle, DWORD dwStyle, LPVOID pParam, int x = CW_USEDEFAULT, int y = CW_USEDEFAULT,
		int  width = CW_USEDEFAULT, int height = CW_USEDEFAULT, bool bFollowParent = false);


	virtual LRESULT _createChildEx(window* pParentWindow, LPCSTR szClassName,
		LPCSTR szCaption, DWORD dwExstyle, DWORD dwStyle, LPVOID pParam, int x = CW_USEDEFAULT, int y = CW_USEDEFAULT,
		int  width = CW_USEDEFAULT, int height = CW_USEDEFAULT, bool bFollowParent = false);

	struct NotifyHandler_Base
	{
		virtual LRESULT invoke(UINT uiId) = 0;
	};

	NotifyHandler_Base* m_poNotifyHandler = NULL;

	template <class C>
	struct NotifyHandler : public NotifyHandler_Base
	{
		virtual ~NotifyHandler() {
			cond_del(m_po);
		}

		virtual LRESULT invoke(UINT uiId) {
			return m_funcNotifyHandler(*m_po, 123);
		}
		// function data
		function<LRESULT(C&, UINT)> m_funcNotifyHandler;
		C* m_po = NULL;
	};

	template <class C>
	void addNotifyHandler(C* _po, function<LRESULT(C&, UINT)> _func)
	{
		NotifyHandler<C>* N = new NotifyHandler<C>;
		N->m_funcNotifyHandler = _func;
		N->m_po = _po;
		m_poNotifyHandler = N;
	}



	////////////////////////////////////////////////////////////////////////////////////////////
	//	Window Template functions
	////////////////////////////////////////////////////////////////////////////////////////////
public:
	// create the window from the INTERNAL template data without any changes
	virtual bool createFromInternalTemplate();

	// create the window from the INTERNAL template data BUT change the parent window pointer
	virtual bool createFromInternalTemplate(window* _PParent, int x = 0, int y = 0);


	// create the window from the EXTERNAL template data without any changes
	//bool _createFromTemplate(window_template wt);

	// create the window from the template data BUT change the parent window pointer
	//bool _createFromTemplate(window_template wt, window* _PParent);


	// TODO: Make sure this works, and does not interfere the core in _createEx()
	//bool _addToParentChildList();

	// TODO: finsish this, and make sure all children are created = it works
	// call the onCreate on the children
//	bool _createChildWindow();



	// TODO: write these:
	//virtual LRESULT _createFromCopiedValues() ;
	//virtual LRESULT _createChildren();

	// create the child windows with proper offset, if any


	//virtual LRESULT create_with_unique_wndproc(window* pParentWindow, LPCSTR szClassName,
	//	LPCSTR szCaption, DWORD dwExstyle, DWORD dwStyle, LPVOID pParam, int x = CW_USEDEFAULT, int y = CW_USEDEFAULT,
	//	int  width = CW_USEDEFAULT, int height = CW_USEDEFAULT);
public:	// // destroys the window

	virtual bool isEnabled();
	virtual bool enable(bool _bState, bool _bEnableChildren = true);
	virtual bool enableChildren(bool _bState);

	// disables the window, so that bool enable(bool) can't enable the window
	virtual bool disable(bool bState, bool bDisableChildren = false);
	virtual bool disableChildren(bool _bState);

protected:
	bool m_bDisabled = false;
	bool m_bPrevEnable = true;
public:

	virtual void createMenu();

	bool setMenu(menu *PMenu);
	bool drawMenu();

	bool getYesNoBox(const string & strMessag, const string & strCaption = "Question?");	
	static bool getYesNoBox(window* _poParent, const string & strMessage, const string & strCaption = "Question");

	void getOKErrorBox(const string & strMessag, const string & strCaption = "Error!");	
	static void getOKErrorBox(window* _poParent, const string & strMessage, const string & strCaption = "Error!");
	//static void getOKErrorBox(const string & strCaption, const string & strMessage);
	



	bool setHotKey(int  id, UINT fsModifiers, UINT _key_code);

	virtual void setAllMessageandler()
	{

	}


	//LRESULT createFromHWND(HWND hwnd);

	////////////////////////////////////////////////////////////////////////////////
	//
	//							Operator ovcerloads
	//
	////////////////////////////////////////////////////////////////////////////////
public:
	operator HWND();
	operator POINT();
	operator string();

	//operator string&() {};
	//operator string*() {};
	;
	operator LPSTR();
	operator LPCSTR();

	operator HDC();


	inline operator window*()
	{
		return this;
	}

	csz operator<< (csz szText) {

		return "";
	}


	csz operator>>(csz& szText) {

		return "";
	}

	virtual sz& operator=(csz& cszText);


	virtual string& operator=(const string& strValue);
protected:
	HWND& operator=(const HWND& rc);

	// get window ptr from HWND handle
	static window* _getWindowPtrFromHandle(HWND);

	// map to link HWND to window*
	static map<HWND, window*> sm_mapHandleToWindowPtr;

public:
	void removeDestroyedFromMap(HWND);

protected:

	window* getWindowFromPoint(int x, int y);


public:
	////////////////////////////////////////////////////////////////////////////////
	//
	//							String operat�ons
	//
	////////////////////////////////////////////////////////////////////////////////	
	// set the window's tewxt with variable strText
public:
	virtual csz setText(const string strText);
	virtual sz setText(sz cszText);


	virtual bool setReadOnly(bool bState);
	virtual bool isReadOnly();

	bool addText(const string strText);
	bool addText(csz cszText);
	virtual sz getText();

	void copyTextToClipBoard();

	// Set the text that appears when them mouse hovers
	string & setToolTipText(const string);


	//const string & operator= (const string & strValue);

	HDC getDC();

	window* f();
	/*inline HWND getParentHWND();
	inline window* getParent();*/


	void updateText();

	////////////////////////////////////////////////////////////////////////////////
	//
	//							Window dimension operations
	//
	////////////////////////////////////////////////////////////////////////////////	

	void setPos(int x, int y, int cx, int cy, HWND hwndInsertAfter = HWND_TOP, uint uiFlags = 0);
	void setPos(int x, int y, HWND hwndInsertAfter = HWND_TOP, uint uiFlags = 0);
	int setX(int x);
	int setY(int y);
	int getX();
	int getY();




	// Uses SetWindowLong to change the extended style of the window
	LONG setExStyles(DWORD dwSExStyles);
	LONG getExStyles();

	// Uses SetWindowLong to change the style of the window
	LONG setStyles(DWORD dwStyles);
	LONG getStyles();

	bool update();
	bool show(int iCmdShow = SW_SHOW);

	window* setFocus(bool _bIgnoreKeyStrokes = false);

	bool destroy();


	inline int x();
	inline int y();
	inline int width();
	inline int height();

	inline RECT getRect();


	RECT & getWindowRect();
	bool setWindowRect(RECT rc);


	void calculateExtendsOfChidlren() {
		// TODO get x,y,w,h values of the children that are closest to the edgde, that can be used to adjust the window bases on the child position and size
	}

	inline void setWidth(int width);
	inline void setHeight(int height);
	//inline bool setDim(int width, int height);

	void moveClientArea(int x, int y, int cx, int cy, bool bRepaint = true);
	void resizeClientArea(int cx, int cy, bool _bMenu = false);
	void resizeClientAreaRelatively(int dx, int dy, int dcx, int dcy, bool  bRepaint = true); // resize the from any side a the user can

	const RECT & getClientRect();

	void resize(int cx, int cy, HWND hwndInsertAfter = HWND_TOP, uint uiFlags = 0);
	void resizeRelatively(int dx, int dy, int dcx, int dcy, HWND hwndInsertAfter = HWND_TOP, uint uiFlags = 0);


	// TODO: make this work:
	// call from a child window that recently has been moved and/or resized
	// so the parent window can adjust its "virtual client area size" variables
	//void informOfNewDimensions();



	void followParentDimensions(int offset_x, int offset_y, int offset_width, int offset_height);
	BOOL setPositionAndSize(
		window* pWndInsertAfter,
		int  X,
		int  Y,
		int  wwith,
		int  height,
		UINT uFlags
	);

	//BOOL moveAndResize(bool bRepaint = true);
//	BOOL moveAndResize(RECT_XY PositionAndSize, bool bRepaint = true);

		//void informParrentOnSizeChange(int _x, int _y, int, int _width, int _height_);

	void getDimensions();

	void updateDimensions();

	BOOL moveAndResize(bool bRePaint);

	BOOL move(int x, int y, int width, int height, bool bRepaint = true);

public:
	RECT & getClientRect(RECT* prcClientRect);

	bool getDialogItem(window*, int _id);
	bool exitDialog(INT_PTR);

public:

	// link windows on the "child level) so the reize togethether
	void linkToWindows(window* PWinLeft, window* PWinTop, window* PWinRight, window* PWinBottom);



	////////////////////////////////////////////////////////////////////////////////////
	//	Containter (map/vector)methods
	//////////////////////////////////////////////////////////////////////////////////////////
protected:
	bool addChildWindowPtrToMap(string strId, window* PChild);
	window* getChildWindowPtrFromMap(string strId);



	void _addChildToCreate(window* _PChildWindow);
	void _createChildren(window* PParent = NULL, int x = 0, int y = 0);

public:
	void handleMenuItem(UINT id, base* object, pmf::MenuItemHandlerFunc pmf);



	// uses event_handler class to call any method in any class when a menu item is selected





	//template <class CLASS>
	//void setMenuItemHandler(CLASS* C, LRESULT (CLASS::*classMeberFunction1)(UINT message, WPARAM wPAram, LPARAM lParam));


	//static window* getWindowObjectFromHWND(HWND hHandle);
	//static bool setAssociateHWNDWithWindowObject(�INT uiMenItemnId, HWND hHandle, window* PWindow);



protected:
	// redefinable methods for processing the WM_ messages
	//virtual bool processWM_COMMAND(WPARAM wParam, LPARAM lParam);	
	//virtual bool processMenuEvents(UINT uiId);
	//virtual bool processControlEvent(word wNotificationCode, word wControlId, window* PControl);	
	//virtual bool processAccellerator(UINT uiId);

protected:
	static LONG putThisIntoWindowMemory(HWND _HWND, window* PWindow);
	static window* getThisFromWindowMemory(HWND h);

public:
	void handleMessage(UINT uiMessage, base* POJect, pmf::WMHandlerFunc);

protected:
	LRESULT invokeMessageHandler(UINT uiMessage, WPARAM wParam, LPARAM lParam);

	static LRESULT CALLBACK SubWindowProc(
		HWND   hwnd,
		UINT   uMsg,
		WPARAM wParam,
		LPARAM lParam
	);
	static WNDPROC sm_oldWinProc;

protected:

	LRESULT processWM_SIZE_linked_windows(WPARAM wParam, LPARAM lParam);




	virtual LRESULT process_MenuEvent(UINT uiID);
	LRESULT t_process_AcceleratorEvent(UINT uiID);

	virtual LRESULT t_process_MenuEvent(UINT uiId);

	static LRESULT t_process_HotKeyEvent(UINT uiId);


	virtual LRESULT t_process_SysMenuEvent(window*, UINT uiId);


	/*************************************************************************************************
	method:		t_process_ControlEvent -		method for processing events from child controls

	parm:		UINT uiNotification -		A code the signal what kins of event (click, ...., etc)
	parm:		UINT uiID -					The id (integer) of the control in questioin (not used)
	parm:		HWND hwndControl		The window handle of the control (used for search/handling)
	*************************************************************************************************/
	virtual LRESULT t_process_ControlEvent(UINT uiNotification, UINT uiID, HWND hwndControl);


	// INTERNAL WM_ command handlers

protected:
	window_class m_wcUsing;

	HWND m_hHandle = NULL;;

	HWND m_hwndInsertAfter = HWND_TOP;
	//PMFMessageHandler m_pmf = &this::case_wm_CREATE();
	static thread_local_data<window*, NULL> sm_PTempThis;

	static map<DWORD, window*> sm_PTempThisList;

public:

protected:
	window_template m_template;

	struct _last_msg
	{
		HWND _HWND;
		UINT uiMsg;
		WPARAM wParam;
		LPARAM lParam;
	} m_last_message;

	bool m_bCreateFromInternalTamplate = false;
	bool m_bCreateByParent = false;
	bool m_bCoordinatesValid = false;
	bool m_bIsDebugguing = false;

	//map < UINT, _wm_handler> m_mapMessagedHandlers;
	map<UINT, MenuItemgHandlerInfo> m_mapMenuEventHandlers;
	static map<UINT, _handler_base*> sm_t_mapAccelEventHandlers;




	sz		m_pszTempText = NULL;;

	dword	m_dwTextLength = 0;
	dword	m_dwTemTextLength = 0;

	window* m_poParentWindow;
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//		Font stuff
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////
	HFONT m_hFont = NULL;
public:
	font oFont;
public:
	static HFONT hDefaultFont;
	static font DefaultFont;
	operator HFONT();
	operator font();
	int getWidth();
	int getHeight();


protected:
	// Used for linking windows in a GUI, when one linkedwindow is resized to the right,
	// tne linked window to its right is reiszed from left to right and so on
	window* m_PLinkedWindowLeft = nullptr, *m_PLinkedWindowTop = nullptr, *m_PLinkedWindowRight = nullptr, *m_PLinkedWindowBottom = nullptr;
	bool m_bControlLeft = false, m_bColtrolTop = false, m_bControlRight = false, m_bControlBotoom = false;
	// list of child window the folow their parent when resizing;
	vector<window*>		m_vecFollowParent;

	int m_x, m_y, m_width, m_height;
	int m_client_x, m_client_y, m_client_width, m_client_height;

	int m_offset_x, m_offset_y, m_offset_width, m_offset_height;
	bool m_bFolowParentDimensions = false;

	RECT m_rcClienRect;
	RECT m_rcWindowRect;

	//virtual LRESULT WM_TEST(WPARAM wParam, LPARAM lParam);


	//static map<HWND, window*> m_mapHWNDToWindowPtr;	
	//static map<string, window*> m_mapStringToWindowPtr;

	map<string, window*> m_mapString_ChildWindowPtr;

	map<UINT, bool> m_mapMesagToBool;

	// is this map tne derived form "template <clasa C > event_handler {}" is added,
	// so that the handler can call any method in any class
	//map<UINT, event_handler_base*> m_mapMenuEventHandlers;

	map<HWND, window*> m_mapChildHandleToWindowPtr;

	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//
	//		Dynamic message handler stuff
	//
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

public:
	static void bindHandlerToControlEvent(window* _poSource, uint uiEventId, base* _po, pmf::ControlEventHandler pmfHandlerFunc);

	template <class C>
	static void t_bindHandlerToControlEvent(window* _poSource, uint uiEventId, C* _po, typename tpmf<C>::MsgFunc pmfHandlerFunc);

	template <class C>
	void t_bindHandlerToWM(window* _poSource, uint uiMsg, C* _po, typename tpmf<C>::MsgFunc pmfHandlerFunc);

	template <class C>
	static void t_bindHandlerToMenuEvent(uint _Id, C * _po, typename tpmf<C>::MsgFunc _pmfHandlerFunc);

	template <class C>
	static void t_bindHandlerToHotKey(uint _Id, C * _po, typename tpmf<C>::MsgFunc _pmfHandlerFunc);

	/*template <class C>
	void t_bindHandlerToAccelEvent(uint _Id, C * _po, typename tpmf<C>::MsgFunc _pmfHandlerFunc);
	*/
	//maC>p<UINT, _handler_base*> m_t_AccelEventHandlers;




	void bindHandlerToWM(window* _poSoucrl, uint uiMesageId, base* _po, pmf::WMHandlerFunc _pmf);

protected:
	// map-map to connent a control event to a function
	static map<window*, map<UINT, _handler_base*>> sm_t_mapControlEventHandlers;

	map<window*, map<UINT, _handler_base*>> sm_t_mapWmEventHandlers;

	static map<window*, map<UINT, _handler_base*>> sm_t_mapSysMenuHandlers;

	static map<UINT, _handler_base*> sm_t_menuEventHandlers;
	static map<UINT, _handler_base*> sm_t_mapHotKeyHandlers;

public:

	bool useDynCtrlRetVal(bool bState = true);
	bool isUsingDynCtrlRetVal();

	bool useDynMsgRetVal(bool btate = true);
	bool isUsingDynMsgRetVal();

protected:
	bool m_bUseDynamicMsgHandleValue = false;
	bool m_bUseDynamicCtrlHandleValue = false;


	map<UINT, _handler_base*> m_t_mapSystemCommmands;

	template<class C>
	static inline void t_bindHandlerToSysMenuEvent(window* _poSource, uint _Id, C * _po, typename tpmf<C>::MsgFunc _pmfHandlerFunc)
	{
		t_handler < C, tpmf<C>::MsgFunc> * pceh = new t_handler<C, tpmf<C>::MsgFunc >;

		pceh->poHandlerObject = _po;
		pceh->poMsgHandlerFunc = _pmfHandlerFunc;



		map<window*, map<UINT, _handler_base*>>::iterator it = sm_t_mapSysMenuHandlers.find(_poSource);
		if (it == sm_t_mapSysMenuHandlers.end()) // is windows in list
		{
			// no so put it there along with id and handler
			sm_t_mapSysMenuHandlers[_poSource][_Id] = pceh;
		}
		else
		{
			// winow IS in list, so add id and handler
			it->second[_Id] = pceh;
		}

	}


	LRESULT t_processMessageEvent(HWND hwndDest, UINT msg, window* _poWIndDest, WPARAM wParam, LPARAM lParam)
	{
		/*m_oWmMessage.hwndSource = *this;
		m_oWmMessage.type = event_info::type::wm_event;
		m_oWmMessage.uiMessage = msg;
		m_oWmMessage.poSourceWindwow = this;
		m_oWmMessage.wParam = wParam;
		m_oWmMessage.lParam = lParam;
		m_oWmMessage.uiNotifyCode = 0;*/

		uint m = WM_COMMAND;
		map<HWND, window*>::iterator it_window = sm_mapHandleToWindowPtr.find(hwndDest);

		if (it_window == sm_mapHandleToWindowPtr.end())
			return  0;

		window* poWindowSource = it_window->second;

		map<window*, map<UINT, _handler_base*>>::iterator it_msg_map = sm_t_mapWmEventHandlers.find(it_window->second);

		if (it_msg_map == sm_t_mapWmEventHandlers.end())
			return  0;

		map<window*, map<UINT, _handler_base*>>::iterator it = sm_t_mapSysMenuHandlers.find(_poWIndDest);

		map<UINT, _handler_base*>::iterator it_msg_handler = it_msg_map->second.find(msg);
		if (it_msg_handler == it_msg_map->second.end())
			return  0;






		return it_msg_handler->second->invoke_WM(&m_oLastMessage);
	}


	// Button1.ctrlEvent(BN_CLICKED) >> this_app(&test_app::button1_clicked);
	//
	// event_info & window::ctrlEvent(UINT uiId);
	//
	// wm_handler_base & base::operator()(pmf::ctrlHandler)
	//
	// wm_handler_base & event_info::operator>>(wm_handler_base & wmhb)

	window_message m_oWmMessage;
	static window_message sm_oWindowMessage;


public:

	struct event_info
	{
	public:
		event_info();

		event_info(window* _poSoure, int _type, UINT  _uiId);

		event_info(window* _poSoure, UINT window_message);


		//
		//template <class T>
		//__handler<T>  operator>>(__handler<T>  _handlerCtrlEvent)
		//{

		//	//window* pSource = this->poSource;
		//	//UINT ID = uiId;

		//	TODO: tidy up this

		//	window::bindHandlerToControlEvent(poSource, uiId, _handlerCtrlEvent.PObject, _handlerCtrlEvent.pmf);

		//	return _handlerCtrlEvent;
		//}

		template <class C>
		_handler_base bindTo(t_handler<C, typename tpmf<C>::MsgFunc> * po)
		{



			//window* pSource = this->poSource;
			//UINT ID = uiId;

			// TODO: tidy up this

			// TODO: make this work for all event types
			switch (this->_type)
			{
			case type::wm_event: {
				this->poSource->t_bindHandlerToWM(this->poSource, this->uiId, po->poHandlerObject, po->poMsgHandlerFunc);
			}
								 break;

			case type::control_event: {
				window::t_bindHandlerToControlEvent(this->poSource, this->uiId, po->poHandlerObject, po->poMsgHandlerFunc);
			}
									  break;
									  /*case type::menu_event: {
										  window::t_bindHandlerToMenuEvent(this->uiId, po->poHandlerObject, po->poHandlerFunc);
									  }
									  break;*/
			case type::sys_menu_event: {
				t_bindHandlerToSysMenuEvent(this->poSource, this->uiId, po->poHandlerObject, po->poMsgHandlerFunc);
			}
									   break;
			case type::hotkey_event: {
				t_bindHandlerToHotKey(this->uiId, po->poHandlerObject, po->poMsgHandlerFunc);
			}
									 break;

			}









			return *po;
		}


		//_handler_base  operator>>(_control_event_handler  _handlerCtrlEvent)
		//{

		//	//window* pSource = this->poSource;
		//	//UINT ID = uiId;

		//	// TODO: tidy up this

		//	window::bindHandlerToControlEvent(poSource, uiId, _handlerCtrlEvent.PObject, _handlerCtrlEvent.pmf);

		//	return _handlerCtrlEvent;
		//}

		template <class C>
		_handler_base operator>>(t_handler<C, typename tpmf<C>::MsgFunc> * po)
		{



			//window* pSource = this->poSource;
			//UINT ID = uiId;

			// TODO: tidy up this

			// TODO: make this work for all event types
			switch (this->_type)
			{
			case type::wm_event: {
				this->poSource->t_bindHandlerToWM(this->poSource, this->uiId, po->poHandlerObject, po->poMsgHandlerFunc);
			}
								 break;

			case type::control_event: {
				window::t_bindHandlerToControlEvent(this->poSource, this->uiId, po->poHandlerObject, po->poMsgHandlerFunc);
			}
									  break;
									  /*case type::menu_event: {
										  window::t_bindHandlerToMenuEvent(this->uiId, po->poHandlerObject, po->poHandlerFunc);
									  }
									  break;*/
			case type::sys_menu_event: {
				t_bindHandlerToSysMenuEvent(this->poSource, this->uiId, po->poHandlerObject, po->poMsgHandlerFunc);
			}
									   break;
			case type::hotkey_event: {
				t_bindHandlerToHotKey(this->uiId, po->poHandlerObject, po->poMsgHandlerFunc);
			}
									 break;

			}









			return *po;
		}

		template <class C>
		_handler_base operator=(t_handler<C, typename tpmf<C>::MsgFunc> * po)
		{



			//window* pSource = this->poSource;
			//UINT ID = uiId;

			// TODO: tidy up this

			// TODO: make this work for all event types
			switch (this->_type)
			{
			case type::wm_event: {
				this->poSource->t_bindHandlerToWM(this->poSource, this->uiId, po->poHandlerObject, po->poMsgHandlerFunc);
			}
								 break;

			case type::control_event: {
				window::t_bindHandlerToControlEvent(this->poSource, this->uiId, po->poHandlerObject, po->poMsgHandlerFunc);
			}
									  break;
									  /*case type::menu_event: {
										  window::t_bindHandlerToMenuEvent(this->uiId, po->poHandlerObject, po->poHandlerFunc);
									  }
									  break;*/
			case type::sys_menu_event: {
				t_bindHandlerToSysMenuEvent(this->poSource, this->uiId, po->poHandlerObject, po->poMsgHandlerFunc);
			}
									   break;
			case type::hotkey_event: {
				t_bindHandlerToHotKey(this->uiId, po->poHandlerObject, po->poMsgHandlerFunc);
			}
									 break;

			}









			return *po;
		}




		_wm_handler  operator>>(_wm_handler  _handlerWM)
		{
			poSource->bindHandlerToWM(poSource, uiId, _handlerWM.PObject, _handlerWM.pmf);

			return _handlerWM;

		}

		operator csz()
		{
			return "Test";
		}


		enum class type1
		{
			invalid,
			wm_event,
			menu_event,
			control_event,
			notify_event,
			sys_menu_event,
			hotkey_event,
			activate_event,
		};

		struct type {
		public:
			_const int invalid = 0;
			_const int wm_event = 1;
			_const int menu_event = 2;
			_const int control_event = 3;
			_const int notify_event = 4;
			_const int sys_menu_event = 5;
			_const int hotkey_event = 6;
			_const int activate_event = 7;
		};

		int _type = type::invalid;

		window* poSource = nullptr;
		HWND hwndSource = NULL;

		UINT uiTypeId = 0;


		UINT uiId = 0;
	};

	event_info m_event_info_temp;



	//event_info _wm_handlder = event_info(this, event_info::type_wm_event);
	event_info m_menu_event_info;
	event_info m_ctrl_event_info;
	event_info m_wm_event_info;

	// returns info on a window message

	event_info & sys_menu_event(window* _po, UINT _MenuItemId)
	{
		m_event_info_temp._type = event_info::type::sys_menu_event;
		m_event_info_temp.poSource = _po;
		m_event_info_temp.uiId = _MenuItemId;

		return m_event_info_temp;

	}

	event_info & getHotKeyEvent(UINT _id)
	{
		m_event_info_temp._type = event_info::type::hotkey_event;
		m_event_info_temp.poSource = this;
		m_event_info_temp.uiId = _id;

		return m_event_info_temp;

	}

	event_info & menu_event(UINT _MenuItemId)
	{
		m_event_info_temp._type = event_info::type::wm_event;
		m_event_info_temp.poSource = this;
		m_event_info_temp.uiId = _MenuItemId;

		return m_event_info_temp;
	}

	event_info Event_Close = event_info(this, event_info::type::wm_event, WM_CLOSE);
	event_info Event_System = event_info(this, event_info::type::wm_event, WM_SYSCOMMAND);



	event_info & WindowEvent(UINT _uiMessageId)
	{


		m_event_info_temp._type = event_info::type::wm_event;
		m_event_info_temp.poSource = this;
		m_event_info_temp.uiId = _uiMessageId;




		return m_event_info_temp;
	}

	event_info & operator()(UINT _uiMessageId)
	{

		m_event_info_temp._type = event_info::type::wm_event;
		m_event_info_temp.poSource = this;
		m_event_info_temp.uiId = _uiMessageId;


		return m_event_info_temp;
	}


	event_info & ctrlEvent(UINT _uiNotificationId)
	{
		m_event_info_temp._type = event_info::type::control_event;
		m_event_info_temp.poSource = this;
		m_event_info_temp.uiId = _uiNotificationId;

		return m_event_info_temp;
	}

	event_info & getEventInfo(window _poSource, UINT _uiId, int _type)
	{
		m_event_info_temp._type = _type;
		m_event_info_temp.poSource = _poSource;
		m_event_info_temp.uiId = _uiId;

		return m_event_info_temp;
	}




	event_info Clicked = event_info(this, event_info::type::control_event, BN_CLICKED);

	/*{
		m_event_info_temp._type = BN_CLICKED;
		m_event_info_temp.poSource = this;

		return m_event_info_temp;
	}*/





public:
	LRESULT test_func(window* _poWndCtrl, UINT uiEventId);







protected:
	//static map<window*, map<UINT, _control_event_handler*>> sm_mapControlEventHandlers;





	// TODO: make suer this works
	std::vector<window*> m_vecChildren;

	// TODO: make suer this works
	std::vector<window*> m_vecChildrenToBeCreated;
	// The callback function  that handles messages
	//static LRESULT CALLBACK W�ndowProcedure(HWND hWindow, UINT message, WPARAM wParam, LPARAM lParam);;

	// a mao that connect 
	//static map<hwnd, windows*> sm_mappHandleTOWindowss:

public:
	static window* poMainWindow;
protected:
	static window* sm_pCurrentThis;
	static window* sm_pTempThis;
	static bool sm_bThreadLocked;

	WNDPROC ptrNewWindowProcedure;
	static LRESULT CALLBACK _WndProc(HWND hWindow, UINT message, WPARAM wParam, LPARAM lParam);

	// the redefineable window proceure called from the static one
	virtual LRESULT CALLBACK WindowProcedure(HWND _HWND, UINT message, WPARAM wParam, LPARAM lParam);
	/********************************************************************************************
		Internal window message handlers
	*********************************************************************************************/
protected: // TODO: maybe make public, so I can be reached by pointer from a base class object
public:
	// handles its own notification, that is sent back to it
	virtual LRESULT processOwnNotification(UINT uiNotificationCode);



protected:
	/* if relevant redirect to control's caseWM_COMMAND or caseWM_NOTIFY, it will check if the conmtrol hwnd is the same as its own,
	 and if so know that the command/notifications is itself for it and handle it.*/





	virtual LRESULT case_WM_CREATE(CREATESTRUCT* pCS);




	//virtual LRESULT case_WM_PAINT();
	   

	virtual lr window_message_handler(WM_NCACTIVATE, bool, LPARAM);

	virtual lr window_message_handler(WM_ACTIVATE, UINT, UINT, HWND);

	//virtual LRESULT message_handler(WM_SYSCOMMAND, DWORD, int, int);
	
	virtual LRESULT onNotify(NMHDR * pmnh);
	virtual LRESULT onSystemClose();
	virtual LRESULT onMove(int x, int y);
	virtual LRESULT onMoving(RECT* _pRectDrag);
	
	virtual LRESULT onSize(DWORD dwSizeCpde, int width, int);
	virtual LRESULT onSizing(dword _dwSizingEdge, RECT* _pRectDrag);

	

	//internals m_internal_message_handlers;

	message_handler m_window_message_handler;

	template<UINT key, class C, class ... Args>
	void bindWMHandler(LRESULT(C::*function)(Args... args), C* ownerPtr)
	{
		m_window_message_handler.bind<key>(function, ownerPtr);
	};

	virtual LRESULT case_WM_COMMAND(word wCode, word wId, HWND hwndCtrl);

	virtual LRESULT case_WM_SYSCOMMAND(dword swCode, int mouse_x, int mount_y);

	virtual LRESULT case_WM_MOVE(WPARAM wParam, LPARAM lParam);

	virtual LRESULT case_WM_NOTIFY(NMHDR* pmnh);

	virtual LRESULT case_WM_SIZE(WPARAM wParam, LPARAM lParam);

	virtual LRESULT case_WM_CLOSE();

	virtual LRESULT case_WM_CHAR(WPARAM wParam, LPARAM lParam);

	virtual LRESULT case_WM_PAINT();

	virtual LRESULT window_message_handler(WM_ERASEBKGND, HDC hdc);


	//*********************************************************************************************************
	//		Virtual Window creation, error and destruction methods
	//**********************************************************************************************************
protected:
	static void displayErrorBoxAndQuit(int _exit_code = -1, const string _strTitle = "", const string _strDescription = "");
	virtual bool onCreated();
	virtual bool onActivate(uint bState, uint min_state, HWND hwnd);
	virtual bool setupMenu();
	virtual bool setupHandlers();
	virtual bool onClose();
	virtual void onQuit();

	virtual void onNotify(window*, UINT _code);

	virtual void onError();

	////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//		Send Messages, set LONG
	////////////////////////////////////////////////////////////////////////////////////////////////////////////
public:
	LONG setLongPtr(int index, LONG _value);
	LONG getLongPtr(int index);
	// Set the font for the witn

	font & operator()(font & _roFont, bool bResizeToText = false, int x_offset = 0, int y_offset = 0);

	bool setFont(HFONT hFont = DefaultFont, bool nRedraw = true);
	// sends a message to the message loop
	LRESULT sendMessage(UINT uiMsg, WPARAM wParam, LPARAM lParam);

	// Sends a message and return without wait for the klmessage to be processed
	LRESULT postMessage(UINT uiMsg, WPARAM wParam, LPARAM lParam);
	LRESULT postQuit(int _exit_code);

protected:
	
	CREATESTRUCT m_oLastCreateStruct;

public:
	font* m_poFont;



	menu* pMenu1 = nullptr;
	menu* pMenu2 = nullptr;
	menu* pMenu3 = nullptr;

	//menu_item m_file = { "File" };
	// Get the SCREEN dimensions of the window
	bool getScreenRect(RECT* pRECT);
	// get the screen x, y for the window
	POINT getScreenPos();

public:

	number_property<int> X = decl_number_property_2(int, getX(), setX(_int));
	number_property<int> Y = decl_number_property_2(int, getY(), setY(_int));

	number_property<int> Width = decl_number_property_2(int, getWidth(), setWidth(_int));
	number_property<int> Height = decl_number_property_2(int, getHeight(), setHeight(_int));


	/*number_property<int> X = number_property<int>(
		[this]() {return getX(); },
		[this](int x) {setX(x); }
	);
*/
//number_property<int> Y = number_property<int>(
//	[this]() {return getY(); },
//	[this](int y) {setY(y); }
//);

//number_property<int> Width = number_property<int>(
//	[this]() {return getWidth(); },
//	[this](int _width) {setWidth(_width); }
//);
/*
	number_property<int> Height = number_property<int>(
		[this]() {return getHeight(); },
		[this](int _height) {setHeight(_height); }
	);
*/








	decl_number_property(bool, Enabled, isEnabled, enable);


	number_property<RECT> WindowRect = number_property<RECT>(
		[this]() {return getWindowRect(); },
		[this](RECT rc) {setWindowRect(rc); }
	);



	_string_property Caption = _string_property(
		[this]() { return getText(); },
		[this](csz _csz) { setText(_csz); }
	);

	template <class T> 
	struct _a
	{

	};

	

	number_property<HDC> hDC = number_property<HDC>(
		[this]() { return getDC(); },
		[this](HDC h) { int i = 0; }
	);


public:
	static struct win_types
	{
		_const UINT invalid = 0;
		_const UINT window = 1;
		_const UINT button = 2;
		_const UINT edit_box = 3;
		_const UINT combo_box = 4;
		_const UINT check_box = 5;
		_const UINT check_box_group = 6;
	};
	UINT window_type = win_types::invalid;



};

// TODO: Make this work as collection of window you group togethter, that has the same parent, and can be created, drawn and changed together
struct window_collection
{
	window_collection(window* PWindowThis)
	{
		PParent = &PWindowThis;
	}

	//window* pw = PParent;

protected:

	// TODO: use this pointer to pointer to make sure your have the right pointer even if it changes value
	window** PParent = NULL;
private:
	window_collection() {};

};


extern window DesktopWindow;


//window_collection a(NULL);




template <class T>
class thread_safe_variable
{
public:
	T read()
	{
		if (m_bIsLocked)
			while (m_bIsLocked);

		m_bIsLocked = true;
		return m_varible;
		m_bIsLocked = false;
	}


protected:
	bool m_bIsLocked;
	T m_varible;



};

// TODO: make this work !!!!



template<class C>
inline void window::t_bindHandlerToControlEvent(window * _poSource, uint uiEventId, C * _po, typename tpmf<C>::MsgFunc pmfHandlerFunc)
{

	t_handler < C, tpmf<C>::MsgFunc> * pceh = new t_handler<C, tpmf<C>::MsgFunc>;

	pceh->poMsgHandlerFunc = pmfHandlerFunc;
	pceh->poHandlerObject = _po;


	map<window*, map<UINT, _handler_base*>>::iterator it1 = sm_t_mapControlEventHandlers.find(_poSource);
	if (it1 == sm_t_mapControlEventHandlers.end()) // is the control already in the map?
	{ // no, so put it there
		sm_t_mapControlEventHandlers[_poSource][uiEventId] = pceh;
	}
	else
	{
		// add this new event to handler
		it1->second[uiEventId] = pceh;
	}


	// Check if the control is in the first map, if yes, put this new event int the second map
	// if not add it to a temp 2nd map
	// and add that temp 2nd map to the first map







}

template<class C>
inline void window::t_bindHandlerToWM(window * _poSource, uint uiMsg, C * _po, typename tpmf<C>::MsgFunc _pmfHandlerFunc)
{
	t_handler<C, tpmf<C>::MsgFunc> * pceh = new t_handler<C, tpmf<C>::MsgFunc>;

	pceh->poMsgHandlerFunc = _pmfHandlerFunc;
	pceh->poHandlerObject = _po;
	pceh->poWindowSource = _poSource;


	map<window*, map<UINT, _handler_base*>>::iterator it1 = sm_t_mapWmEventHandlers.find(_poSource);
	if (it1 == sm_t_mapWmEventHandlers.end()) // is the window already in the map?
	{ // no, so put it there
		sm_t_mapWmEventHandlers[_poSource][uiMsg] = pceh;
	}
	else
	{
		// yes, so add this new event to handler
		it1->second[uiMsg] = pceh;
	}



}

template<class C>
inline void window::t_bindHandlerToMenuEvent(uint _Id, C * _po, typename tpmf<C>::MsgFunc _pmfHandlerFunc)
{
	t_handler < C, tpmf<C>::MsgFunc> * pceh = new t_handler<C, tpmf<C>::MsgFunc >;

	pceh->poHandlerObject = _po;
	pceh->poMsgHandlerFunc = _pmfHandlerFunc;

	sm_t_menuEventHandlers[_Id] = pceh;

}

template<class C>
inline void window::t_bindHandlerToHotKey(uint _Id, C * _po, typename tpmf<C>::MsgFunc _pmfHandlerFunc)
{
	t_handler < C, tpmf<C>::MsgFunc> * pceh = new t_handler<C, tpmf<C>::MsgFunc >;

	pceh->poHandlerObject = _po;
	pceh->poMsgHandlerFunc = _pmfHandlerFunc;

	sm_t_mapHotKeyHandlers[_Id] = pceh;

}
//template<class C>
//inline void window::t_bindHandlerToAccelEvent(uint _Id, C * _po, typename tpmf<C>::MsgFunc _pmfHandlerFunc)
//{
//	t_handler < C, tpmf<C>::MsgFunc> * pceh = new t_handler<C, tpmf<C>::MsgFunc >;
//
//	pceh->poHandlerObject = _po;
//	pceh->poMsgHandlerFunc = _pmfHandlerFunc;
//
//	m_t_AccelEventHandlers[_Id] = pceh;
//
//}
//
//template<class C>
//inline void window::t_bindHandlerToyusMenuEvent(uint _Id, C * _po, typename tpmf<C>::MsgFunc _pmfHandlerFunc)
//{
//	t_handler < C, tpmf<C>::MsgFunc> * pceh = new t_handler<C, tpmf<C>::MsgFunc >;
//
//	pceh->poHandlerObject = _po;
//	pceh->poMsgHandlerFunc = _pmfHandlerFunc;
//
//	sm_t_menuSysEventHandlers
//
//
//}

static window* g_pWin;

//template<class C>
//inline void window::t_bindHandlerToAccelEvent(uint _Id, C * _po, typename tpmf<C>::MsgFunc _pmfHandlerFunc)
//{
//	t_handler < C, tpmf<C>::MsgFunc> * pceh = new t_handler<C, tpmf<C>::MsgFunc >;
//
//	pceh->poHandlerObject = _po;
//	pceh->poMsgHandlerFunc = _pmfHandlerFunc;
//
//	sm_t_mapHotKeyHandlers[_Id] = pceh;
//
//	
//
//}
//
//
//template <class C>
//struct A
//{
//	function<int(C* pC)> sm_po;
//};
//
//void f3()
//{
//
//}
//
//template <class C>
//void doFunc(function<int(C* pC)> po)
//{
//	
//	function<void(void)> f = f3();
//}