#pragma once
#include "Definitions.h"

class tc
{
public:
	tc() {}
	tc(int _i) { m_i = _i; }

	int m_i;
};


struct refence_base
{

};

template <class T>
struct pointer
{
	pointer(void* _Input)
	{

	}
};


struct MemoryMamanger
{

	template <class T>
	operator T();

	void d()
	{

	}

	void* operator new(size_t);
};


struct reference
{
	void f()
	{
		MemoryMamanger mm;

		string str = mm;

	}


	
};