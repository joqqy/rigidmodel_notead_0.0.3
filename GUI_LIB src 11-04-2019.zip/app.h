#pragma once
#include "Process.h"

#include "app_window.h"

#define onCreateApplication() public: virtual LRESULT _onCreate()
#define _onCreateApplication(cls) LRESULT cls:: _onCreate()
#define runApplication(app)  app  _app;

#define StartApp ___app___
#define _START_APP ___app___

class app :
	public process
{
public:


	app() {};

	app(UINT uiID) {};

	virtual ~app() { };

	virtual LRESULT onCreated(){return 0;}



	virtual LRESULT createMainWindow();
	
	
	
	




public:
	static app* CurrentApp;

protected:
	frame_window* m_PAppWindow = NULL;
};

