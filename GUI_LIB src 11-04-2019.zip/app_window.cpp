// #include "stdafx.h"
#include "app_window.h"



app_window * app_window::operator()(string strCaption, dw dwExStyle, dw dwStyle, int x, int y, int width, int height)
{
	_createEx(DesktopWindow, WC_DEFAULT, strCaption.c_str(), dwExStyle, dwStyle, NULL, x, y, width, height);
	return this;
	
}

bool app_window::create(const string strCaption, int x, int y, int width, int height)
{
	return (0 != (_createEx(DesktopWindow, WC_DEFAULT, strCaption.c_str(), 0, WS_OVERLAPPEDWINDOW, NULL, x, y, width, height)));
}

app_window::app_window()
{
	poMainWindow = this;
	
	//DefaultFont.create(hDC, 13, "Tahoma");
	

}






