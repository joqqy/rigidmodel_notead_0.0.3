#pragma once

#include "definitions.h"

//extern void asm_copy_memory(void* pDest, const void* pSource, dword dwSizeofElement, dword dwNumberofElement);

//extern "C" void tis(void * pDest, const void * pSource, dword size,  dword dwCount);

using namespace std;

//const char src[] =																													"Testint 123.";

class fast_string final
{
public:
	char dest[255];

	fast_string() 
	{

		//asm_mem_copy((void*)dest, (void*)src, strlen(src));

		//DEBUG;

	}

	~fast_string();


	int operator=(int);
	char operator=(char);
	
	//void asm_copy_memory(void* pDest, const void* pSource, dword dwSizeofElement, dword dwNumberofElement);

protected:

	char* m_pchBuffer;
	dword m_dwBufferLength;
};

