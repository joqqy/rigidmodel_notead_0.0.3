#pragma once
#include <control_group.h>
#include <check_box_group.h>
#include "texture_field.h"
#include <rmv2_file.h>

class texture_field_group :
	public control_group
{
public:
	texture_field_group();
	virtual ~texture_field_group();

	virtual bool onCreated() override;

	void updateComboboxes(const rmv2_file*);


	void fillFromLoadedFile(const rmv2_file * _poRMV2_File, uint lod = 0, uint group = 0);

	// Set the number of textures (1-7) and if under 7 disables the rest of the fields
	void setNumberOfTextures(uint _number_of_textures);

public:
	check_box_group	 m_cbgroupLockDir;
	check_box_group	 m_cbgroupLocTextureType;
	check_box m_checkBox;
	texture_field	 m_texture_fields[8];

protected:
	uint m_number_of_textures = 8;

	

};

