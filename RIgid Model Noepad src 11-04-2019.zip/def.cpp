﻿#include "pch.h"
#include "definitions.h"




dword fastcpy(void * dest, const void * src, dword count)
{
	__asm
	{
		
	}



	return dword();
}

float convert16BitFloatTo32Bits(word wInput)
{

	//
	//Sign bit : 1 bit
	//Exponent width : 5 bits
	//Significand precision : 11 bits(10 explicitly stored)
	
	float fTemp = 0.0;;
	

	

	word wMaskSign =		bits<word>("1000000000000000");
	                                    
	word wMaskExp =			bits<word>("0111110000000000");
	                                                 


	word wMaskFraction =	bits<word>("0000001111111111");

	   


	// get the sign, exponent, leadbit and fraction AND bit shift them into them in their right places
	word wSign = wInput & wMaskSign;


	
	wSign = wSign >> 15;

	word wExp = wInput & wMaskExp;

	
	wExp = wExp >> 10;
	
	
	
	
	word wLeadBit;

	if (wExp == 0)
		wLeadBit = 0;
	else wLeadBit = 1;	

	word wFraction = wInput & wMaskFraction;
	//wFraction <<= 6;

	//if (wExp == 0)
	//	wLeadBit = 0;
	//else
	//{
	//	
	//(//	wFraction   or_assign   bits<word>("0000011111111111");
	//	wLeadBit = 1;
	//}
	
	
	float test = 0.0f;
	
	dword* pdw = (dword*) &test;



	



	float sub = 0.0;
	word w1 = bits<word>("00001");
	word w2 = bits<word>("11110");

	float fSign = (float) wSign;
	float fExp = (float) wExp;
	float fFraction = (float) wFraction;
	float fLeadBit = (float) wLeadBit;


	if (wExp >= 1 && wExp  <= 30){
		
		//fFraction = (wFraction << 1) | bits<word>("0000000000000001");
			
			//(float) (wFraction);

		fTemp = powf(-1.0f, fSign) * powf(2.0f, (fExp - 15.0f)) * fFraction;
		return fTemp;
	
	}
	else
	/*
	If the exponent field is 0 (zero), and the mantissa is not zero:
	value = (-1)^s * 2^(-14) ∙ 0.mmmmmmmmmm
	*/
	if (wExp == 0 && wFraction != 0)
	{ 
		fFraction = (float)(wFraction);
		fTemp = powf(-1.0f, fSign) * powf(2.0, -14.0f) * fFraction;
		return fTemp;
	} else
	
	//If the exponent field is zero, and the mantissa is also zero :
	// value = ±0.0
	if (wExp == 0 AND wFraction == 0)
	{
		fTemp = 0.0;
		return fTemp;
	}
	else
	//● If the exponent value is 31, and the mantissa is 0 (zero) :
	//value = ±∞(Infinity)

	if (wExp == 31 AND wFraction == 0)
	{
			fTemp = INFINITY;
			return fTemp;
	}
	else
	//● Finally, if the exponent is 31 and the mantissa is not zero:
	//value = ±NaN(Non a Number)
	if (wExp == 31 AND wFraction != 0)
	{
		fTemp = nan("not a number");
		return fTemp;

	}






	
	wMaskFraction <<= 6;

	

	
	



	return 0.0;

	


		 
	
	
	//get the sign
	//w	word wSign = wInput &			setBits<word>("100000000000000");
	//word wExp = wInput & setBits<word>("0111111110000000");
	//wExp = wExp << 1;

	//word wFraction = wInput & setBits<word>("0000000001111111");
	//wFraction = wFraction << 9;


	//float fSign = wSign;
	//float fFraction = wFraction;
	//float fExp = wExp;

	//int sub = 0;

	//if (wExp > 0x01 && wExp < 0x7f)
	//	sub = -126;

	//if (wExp > 0x7F && wExp < 0xFE)
	//	sub = 127;

	//if (wExp == 0x7F)
	//	sub = 127;


	////

	////(-1)signbit × 2exponent-15 × 1.significantbits
	//fTemp = pow(-1.0, fSign) * pow(2, fExp - sub) * fFraction;






}




float HalfToSingle(word wInput)
{
	dword dw = 0 | (wInput << 16);
	
	float fTemp;

	memcpy(&fTemp, &wInput, 4);
	
	
	return fTemp;
}
