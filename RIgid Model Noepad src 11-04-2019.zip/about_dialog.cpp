#include "about_dialog.h"
#include "resource.h"


about_dialog::about_dialog()
{
}


about_dialog::~about_dialog()
{
}

bool about_dialog::onDialogInit()
{

	m_buttonUpdate.getDialogItem(this, ID_ABOUT_UPDATE);
	m_ButtonClose.getDialogItem(this, IDC_ABOUT_CLOSE);
	m_editCredits.getDialogItem(this, IDC_EDIT_CREDITS);
	m_editVersion.getDialogItem(this, IDC_EDIT_VERSION);
	

	//m_buttonUpdate.ctrlEvent( action(this, &about_dialog::update_clicked);
	
	m_buttonUpdate.ctrlEvent(BN_CLICKED) >> action(this, &about_dialog::update_clicked);
	m_ButtonClose.ctrlEvent(BN_CLICKED) >> action(this, &about_dialog::close_clicked);
	

	
	sys_menu_event(this, SC_CLOSE) >> action(this, &about_dialog::close_clicked);
	

	return true;
}

LRESULT about_dialog::case_WM_PAINT()
{
	
	PAINTSTRUCT ps;
	BeginPaint(*this, &ps);
	m_editCredits.setText("[Coding and desgin:]\r\nPhazer\r\n\r\n[Original research:]\r\nMr.Jox\r\n\r\n[Icons from:]\r\nBomSymbols (https://www.iconfinder.com/korawan_m)");
	m_editVersion.setText("alpha versionj 0.0.1c, test version for limited distribution");




	EndPaint(*this, &ps);
	

	return 1;


}

handler_function about_dialog::update_clicked(pwm)
{
	return 1;
}

handler_function about_dialog::close_clicked(pwm)
{

	exitDialog(1);

	delete this;
	return 1;

}
