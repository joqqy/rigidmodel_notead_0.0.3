#include "main_window.h"
#include "resource.h"
#include <gdi_object.h>
#include <file.h>
#include <Richedit.h>

main_window::main_window()
{
	
	//text txt;

	

}


main_window::~main_window()
{
	
}

bool main_window::setupHandlers()
{
	
	WM_Event(WM_CLOSE) >> action(this, &main_window::onFile_Exit);
		
	return true;
}

bool main_window::onCreated()
{
	LoadLibrary(TEXT("Msftedit.dll"));

	/*HWND hwndEdit = CreateWindowExW(0, MSFTEDIT_CLASS, L"Type here",
		ES_MULTILINE | WS_VISIBLE | WS_CHILD | WS_BORDER | WS_TABSTOP,
		30, 30, 3000, 2000,
		*this, NULL, H_INST, NULL);
*/
	


	



//	m_oABoutDialog.create(this, IDD_ABOUT);

	string strAbc = "a/asd/2123/";

	char ch = strAbc[1];

	Caption = "test";
	m_hBitmap = LoadBitmap(H_INST, MAKEINTRESOURCE(IDB_BITMAP1));
	m_hDC = CreateCompatibleDC(this->getDC());
	SelectObject(m_hDC, m_hBitmap);

	GetObject(m_hBitmap, sizeof(BITMAP), &m_Bitmap);

	gdi_object_handle<HBITMAP> gdiObj;

	int i = gdiObj;

#define ITEM(I) spc( ) ##I

	

	

	MENU_POPUP_BEGIN(m_menuFile) 
			m_mitemFileOpen("&Open \t\t Ctrl + O", this, &main_window::onFile_Open),
			m_mitemFileSaveAs("&Save As...", this, &main_window::onFile_SaveAs),
			m_mitemFileSave("&Save \t\t Ctrl + S", this, &main_window::onFile_Save),
			m_mitemFileClear("Clear...", this, &main_window::onFile_Clear),
			m_mitemFileExit("E&xit \t\t Ctrl + X", this, &main_window::onFile_Exit)
	MENU_END; 


	
	MENU_POPUP_BEGIN(m_menuHelp)
		m_mitemHELP_ABOUT("&About", this, &main_window::onHelp_About)
	MENU_END;


	

	MENU_BAR_BEGIN(m_menuBar)
		m_menuFile("&File"),
		//m_menuEdit("&Edit"),
		m_menuHelp("&Help"),
	MENU_END;
	





	//m_mitemFileOpen.setChecked(true);

	//m_mitemFileOpen.setChecked(false);
	

	

	

	
	SetMenu(*this, m_menuBar);
	DrawMenuBar(*this);

	/*INT I[] = { COLOR_ACTIVECAPTION, COLOR_ACTIVEBORDER};
	COLORREF cr[] = {RGB(60, 0, 60), RGB(0, 160, 60) };
	bool b1 = SetSysColors(2, I, cr);
*/
	BOOL BB = TRUE;
	SystemParametersInfo(SPI_SETFLATMENU,
		0,                 // Not used
		&BB,        // Mouse information
		SPIF_UPDATEINIFILE);  // Update Win.ini

	Caption = "Rigid Model String Editor v0.1 (BETA) --- by phazer";
	
	//	bool b  =m_RM->readFile("RMV2Files\att_spatha_heavy_02.rigid_model_v2");
	
	//txt = txt + "Test 2" + "Test 3";

	oFont.create(hDC);


	m_TextureFieldgroup.create(this, WC_BUTTON, "Textures", 0, WS_CHILD | BS_GROUPBOX, 10, 230, Width - 40, 400);
	
	//m_stattextFileInfo(m_oFont);
	m_stattextFileInfo.create(this, "[no file loaded]", "Open File: ", 10, 30, true, 0);

	
	
	
	m_selectWindow.create(this, WC_BUTTON, "Selecet LOD / Group", 0, WS_CHILD | BS_GROUPBOX, 10, 70, Width - 40, 120);	
	m_selectWindow.m_checkboxLock.Enabled = false;
	m_selectWindow.m_checkboxLock.Enabled = true;

	clearWindow();



	/*for (int i = 0; i < 8; i++)
		m_TextureFieldgroup.m_texture_fields[i].disable(true, true);
*/
	
	//for (int i = 0; i < 8 - m_oRMV2_File.m_File.LodData[0][0]->Header.uiTextureCount; i++)
	//	m_TextureFieldgroup.m_texture_fields[7 - i].disable(true, true);

	//m_oRMV2_File.readFile("E:\\modding\\Extra_v1\\models_extravaganza_v1_part1_0.pack\\VariantMeshes\\_VariantModels\\man\\shield\\_1_scutum_typeA_1.rigid_model_v2");
	
	//m_oRMV2_File.readFile("E:\\s4h_spatha_pb_149_scabbard_01.rigid_model_v2");


	//m_stattextFileInfo.setFont(CreateFont(-10, -4, 0, 9, FW_DEMIBOLD, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_TT_PRECIS,
	//	CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, FIXED_PITCH, TEXT("Tahoma")));
	//m_stattextFileInfo.Caption = m_oRMV2_File.m_strFileName;



	//string strTest = m_stattextFileInfo.Caption;

	//m_TextureFieldgroup.m_texture_fields[3].ebFolder.setFocus();

	


	//uint text_count = m_oRMV2_File.m_File.LodData[0][0]->Header.uiTextureCount;

	//for (int i = 0; i < 8 - m_oRMV2_File.m_File.LodData[0][0]->Header.uiTextureCount; i++)
	//	m_TextureFieldgroup.m_texture_fields[7 - i].disable(true, true);


	//for (int i = 0; i < m_oRMV2_File.m_File.LodData[0][0]->Header.uiTextureCount; i++)
	//{
	//	m_TextureFieldgroup.m_texture_fields[i].ebFolder.Caption = str_info::getDirFromString(m_oRMV2_File.m_File.LodData[0][0]->PTextureData[i]->TextureDirAndFileName.m_szOriginal);
	//	m_TextureFieldgroup.m_texture_fields[i].ebFile.Caption = str_info::getFileFromString(m_oRMV2_File.m_File.LodData[0][0]->PTextureData[i]->TextureDirAndFileName.m_szOriginal);
	//}

	////
	////string strDir = str_info::getDirFromString(m_oRMV2_File.m_File.LodData[0][0]->PTextureData[0]->TextureDirAndFileName.m_szOriginal);
	////
	////string str = str_info::getFileFromString(m_oRMV2_File.m_File.LodData[0][0]->PTextureData[0]->TextureDirAndFileName.m_szOriginal);
	////
	////m_TextureFieldgroup.m_texture_fields[0].ebFolder.Caption = str_info::getDirFromString(m_oRMV2_File.m_File.LodData[0][0]->PTextureData[0]->TextureDirAndFileName.m_szOriginal);
	////m_TextureFieldgroup.m_texture_fields[1].ebFolder.Caption = str_info::getDirFromString(m_oRMV2_File.m_File.LodData[0][0]->PTextureData[1]->TextureDirAndFileName.m_szOriginal);
	////m_TextureFieldgroup.m_texture_fields[2].ebFolder.Caption = str_info::getDirFromString(m_oRMV2_File.m_File.LodData[0][0]->PTextureData[2]->TextureDirAndFileName.m_szOriginal);
	////m_TextureFieldgroup.m_texture_fields[3].ebFolder.Caption = str_info::getDirFromString(m_oRMV2_File.m_File.LodData[0][0]->PTextureData[3]->TextureDirAndFileName.m_szOriginal);
	//
	//m_TextureFieldgroup.m_texture_fields[0].ebFile.Caption = str_info::getFileFromString(m_oRMV2_File.m_File.LodData[0][0]->PTextureData[0]->TextureDirAndFileName.m_szOriginal);
	//m_TextureFieldgroup.m_texture_fields[1].ebFile.Caption = str_info::getFileFromString(m_oRMV2_File.m_File.LodData[0][0]->PTextureData[1]->TextureDirAndFileName.m_szOriginal);
	//m_TextureFieldgroup.m_texture_fields[2].ebFile.Caption = str_info::getFileFromString(m_oRMV2_File.m_File.LodData[0][0]->PTextureData[2]->TextureDirAndFileName.m_szOriginal);
	//m_TextureFieldgroup.m_texture_fields[3].ebFile.Caption = str_info::getFileFromString(m_oRMV2_File.m_File.LodData[0][0]->PTextureData[3]->TextureDirAndFileName.m_szOriginal);

	//m_TextureFieldgroup.setNumberOfTextures(4);

	//m_TextureFieldgroup.fillFromLoadLoadedFile(&m_oRMV2_File);

	//m_TextureFieldgroup.m_texture_fields[4].disable(true, true);
	//m_TextureFieldgroup.m_texture_fields[5].disable(true, true);
	//m_TextureFieldgroup.m_texture_fields[6].disable(true, true);

	//m_TextureFieldgroup.m_texture_fields[4].ebFile.Caption = m_oRMV2_File.m_File.LodData[0][0]->PTextureData[4]->TextureDirAndFileName.m_szOriginal;

	

	//this->Caption = "Rigid Model String Editor v0.1 (BETA) --- by phazer";
	
	/*RegisterNewEditBox(H_INST);
	hwnd = CreateWindowEx(0, WC_NEW_EDIT, "Test", WS_CHILD, 310, 10, 200, 100, *this, NULL, H_INST, NULL);
	ShowWindow(hwnd, SW_SHOW);*/

	///ScrollWindowEx(hwnd, 200, 200, NULL, NULL, NULL, NULL, SW_SCROLLCHILDREN | SW_ERASE | SW_INVALIDATE);
	//ScrollWindowEx(*this, -100, -100, NULL, NULL, NULL, NULL, SW_SCROLLCHILDREN | SW_ERASE | SW_INVALIDATE);
	return true;
	
}



LRESULT main_window::message_handler(WM_ERASEBKGND, HDC hdc)
{
	
	BitBlt(hdc, 0, 0, m_Bitmap.bmWidth, m_Bitmap.bmHeight, m_hDC, 0, 0, SRCCOPY);


	return 1;
}

bool main_window::updateFileInfo()
{
	m_stattextFileInfo.Caption = m_oRMV2_File.m_strFileName;



	return true;
}

bool main_window::clearWindow()
{

	for (int i = 0; i < 8; i++)
	{
		m_TextureFieldgroup.m_texture_fields[i].disable(true, true);
		m_TextureFieldgroup.m_texture_fields[i].ebFile.Caption= "...";
		m_TextureFieldgroup.m_texture_fields[i].ebFolder.Caption = "...";
	}
	
	m_TextureFieldgroup.m_cbgroupLockDir.State = BST_UNCHECKED;
	m_TextureFieldgroup.m_cbgroupLocTextureType.State = BST_UNCHECKED;
	
	m_TextureFieldgroup.m_cbgroupLockDir.enable(false);
	m_TextureFieldgroup.m_cbgroupLocTextureType.enable(false);

	m_stattextFileInfo.Caption = "[no file loaded]";

	m_oRMV2_File.bFIleLoaded = false;

	return true;
}

bool main_window::openFile(const string strFileName)

{
	clearWindow();


	m_TextureFieldgroup.m_cbgroupLockDir.enable(true);
	m_TextureFieldgroup.m_cbgroupLocTextureType.enable(true);


	m_oRMV2_File.readFile(strFileName);

	uint ui = m_TextureFieldgroup.m_texture_fields[0].comboTextureType.findByLPARAM(22);


	m_stattextFileInfo.setFont(CreateFont(-10, -4, 0, 9, FW_DEMIBOLD, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_TT_PRECIS,
		CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, FIXED_PITCH, TEXT("Tahoma")));
	
	m_stattextFileInfo.Caption = m_oRMV2_File.m_strFileName;

	
	string strTest = m_stattextFileInfo.Caption;

	uint text_count = m_oRMV2_File.m_File.LodData[0][0]->Header.uiTextureCount;


	for (int i = 0; i < m_oRMV2_File.m_File.LodData[0][0]->Header.uiTextureCount; i++)
	{
		m_TextureFieldgroup.m_texture_fields[i].disable(false, false);
		

		m_TextureFieldgroup.m_texture_fields[i].ebFile.enable(true);		
		m_TextureFieldgroup.m_texture_fields[i].ebFolder.Caption = str_info::getDirFromString(m_oRMV2_File.m_File.LodData[0][0]->PTextureData[i]->TextureDirAndFileName.m_szOriginal);
		m_TextureFieldgroup.m_texture_fields[i].ebFile.Caption = str_info::getFileFromString(m_oRMV2_File.m_File.LodData[0][0]->PTextureData[i]->TextureDirAndFileName.m_szOriginal);
	}

	m_TextureFieldgroup.updateComboboxes(&m_oRMV2_File);


	m_TextureFieldgroup.m_cbgroupLockDir.State = BST_UNCHECKED;
	m_TextureFieldgroup.m_cbgroupLocTextureType.State = BST_UNCHECKED;

	m_TextureFieldgroup.m_cbgroupLockDir.setAllChildren();
	m_TextureFieldgroup.m_cbgroupLocTextureType.setAllChildren();

	return true;

}
bool main_window::saveFileAs(const string strFileName)
{
	for (int i = 0; i < m_oRMV2_File.m_File.LodData[0][0]->Header.uiTextureCount; i++)
	{
		m_oRMV2_File.m_File.LodData[0][0]->PTextureData[i]->TextureDirAndFileName =
			str_info::getPathFromDirAndFile(m_TextureFieldgroup.m_texture_fields[i].ebFolder.Caption,
				m_TextureFieldgroup.m_texture_fields[i].ebFile);

		m_oRMV2_File.saveToBuffer(&m_oRMV2_File.m_File.LodData[0][0]->PTextureData[i]->TextureDirAndFileName);
	}
	
	bool b = m_oRMV2_File.writeFileAs(strFileName);

	m_stattextFileInfo.Caption = m_oRMV2_File.m_strFileName;

	return b;
}
handler_function main_window::onFile_Open(pwm)
{
	
	file fileTemp;	

	if (!fileTemp.openFileDialog(this))
		return 1;

	openFile(fileTemp);

	return 1;
}

handler_function main_window::onFile_Save(pwm)
{
	if (!m_oRMV2_File.bFIleLoaded)
		return 0;

	if (m_oRMV2_File.m_ifsFile.is_open())
		saveFileAs(m_oRMV2_File.m_strFileName);

	return 1;

}

handler_function main_window::onFile_SaveAs(pwm)
{
	if (!m_oRMV2_File.bFIleLoaded)
		return 0;



	file fileTemp;


	if (!fileTemp.saveFileDialog(this))
		return 1;

	saveFileAs(fileTemp);

	return 1;

}

handler_function main_window::onFile_Clear(pwm)
{
	return clearWindow();
}

handler_function main_window::onFile_Exit(pwm)
{
	

	DestroyWindow(m_hHandle);
	PostQuitMessage(1);
	return 1;
	return 1;
}

handler_function main_window::onHelp_About(pwm)
{
	m_poABoutDialog = new about_dialog;
	m_poABoutDialog->create(this, IDD_ABOUT);
	return 1;
}
