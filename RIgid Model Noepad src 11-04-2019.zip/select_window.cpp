#include "select_window.h"



select_window::select_window()
{
}


select_window::~select_window()
{
}

bool select_window::onCreated()
{

	DWORD dw = WS_CHILD | BS_CHECKBOX;
	m_checkboxLock.create(this, "Identical for all groups", 0, WS_CHILD | BS_CHECKBOX, 20, 20);
	
	


	m_comboGroup.create(this, "LOD", 20, 70, 100, 200, 0, WS_CHILD | CBS_DROPDOWNLIST);
	m_comboLod.create(this, "Group", 20+120, 70, 100, 200, 0, WS_CHILD | CBS_DROPDOWNLIST);
	
	m_checkboxLock.EnableOnCheck = false;
	m_checkboxLock.addWinToEnableList(&m_comboLod);
	m_checkboxLock.addWinToEnableList(&m_comboGroup);	
	m_checkboxLock.State = BST_UNCHECKED;

	


	return true;


}
