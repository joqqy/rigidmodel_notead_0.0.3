#pragma once
#include "app_window.h"
#include "texture_field.h"
#include "texture_field_group.h"
#include <new_edit_box.h>
#include <menu.h>
#include <static_text.h>
#include <rmv2_file.h>
#include "select_window.h"
#include <rmv2_file.h>
#include "about_dialog.h"

#define wm window_message* _wm
#define lr LRESULT

#define handle_wm(wm)


class main_window :
	public app_window
{
public:
	main_window();
	virtual ~main_window();

	
	virtual bool setupHandlers() override;
	virtual bool onCreated() override;

	virtual LRESULT message_handler(WM_ERASEBKGND, HDC hdc);


	bool updateFileInfo();

	bool clearWindow();
	bool openFile(const string strFileName);
	bool saveFileAs(const string strFileName);

	
	bool saveFile();

	// fills the window with data from the file in memory
	bool setAllWindowData();
	bool setAllFileData();

	bool setfileInfo();

	// set all window data each time one of these are changed
	bool setLod(uint lod);
//	bool setLod(uint group);

	bool setTextureDirecotory(string strTextDir);
	bool setTextureField(string strDir, string strFilenam, uint texture_type);
	bool setAllTextureFields(string strDir, string strFilenam, uint texture_type);

	pair<string, string> splitTextureDirAndFileName(string strDirAndFileName);		

	

	

	#include "menu_items.h"
	
protected:
	bool m_bModified = false;;
	string m_strFileName = "";
	// rmv_file m_oRmv2Fle;
	HDC m_hDC;
	HBITMAP m_hBitmap;
	BITMAP m_Bitmap;

public:
	rmv2_file m_oRMV2_File;
public:
	//rmv2_file* m_RM = new rmv2_file;

	button m_butTest;
	about_dialog* m_poABoutDialog = NULL;
	texture_field_group m_TextureFieldgroup;
	select_window m_selectWindow;
	//texture_field m_texture_field;
	static_text m_stattextFileInfo;
	HWND hwnd;
	//control_group m_oFileInfo;
	//texture_field olistTexutureFields[7];
public:
	handler_function onFile_Open(pwm);
	handler_function onFile_Save(pwm);
	handler_function onFile_SaveAs(pwm);
	handler_function onFile_Clear(pwm);		
	handler_function onFile_Exit(pwm);

	handler_function onEdit_Copy(pwm);
	handler_function onEdit_Paste(pwm);
	handler_function onEdit_Undo(pwm);

	handler_function onHelp_Help(pwm);
	handler_function onHelp_About(pwm);
};


