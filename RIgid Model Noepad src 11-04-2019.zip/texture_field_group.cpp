#include "texture_field_group.h"
#include <str_info.h>



texture_field_group::texture_field_group()
{
}


texture_field_group::~texture_field_group()
{
}

bool texture_field_group::onCreated()
{
	int d = 35;


	

	//m_checkBox.create(this, "Test", 0, WS_CHILD | BS_CHECKBOX, 100, 100, 100, 100);
	// create the check box GROUP that c�ntrol the other cheboxes
	


	


	m_cbgroupLockDir.EnableOnCheck = true;
	m_cbgroupLockDir.create(this, "Unlock directory editing...", 0, WS_CHILD | BS_3STATE, 20, 20, 200, 25);
	m_cbgroupLockDir.State = BST_UNCHECKED;
	
	m_cbgroupLocTextureType.EnableOnCheck = true;
	//m_cbgroupLocTextureType.create(this, "Unlock TextId", 0, WS_CHILD | BS_CHECKBOX, 650, 10, 50, 26);	
	m_cbgroupLocTextureType.State = BST_UNCHECKED;
														
	for (int i = 0; i < 8; i++)
	{
		m_texture_fields[i].create(this, WC_BUTTON, "",0, BS_GROUPBOX, 10, 50 + (d * i), m_width - 20, 30);

		m_cbgroupLockDir.addChild(&m_texture_fields[i].checboxFolderLock);
		m_cbgroupLocTextureType.addWinToEnableList(&m_texture_fields[i].comboTextureType);

		m_texture_fields[i].checboxFolderLock.addWinToEnableList(&m_texture_fields[i].ebFolder);
	
		m_texture_fields[i].checboxFolderLock.EnableOnCheck = true;
		m_texture_fields[i].checboxFolderLock.State = BST_UNCHECKED;
	}

	
	


	return true;
}

void texture_field_group::updateComboboxes(const rmv2_file* PRMV2)
{
	for (int i = 0; i < PRMV2->m_File.LodData[0][0]->Header.uiTextureCount; i++)
		m_texture_fields[i].updateComboBox(i, PRMV2);
}

void texture_field_group::fillFromLoadedFile(const rmv2_file * _poRMV2_File, uint lod, uint group)
{
	int num = _poRMV2_File->m_File.LodData[lod][group]->Header.uiTextureCount;

	setNumberOfTextures(num);
		
	for (int i = 0; i < num; i++)
	{
		m_texture_fields[i].ebFolder.Caption = str_info::getDirFromString(_poRMV2_File->m_File.LodData[lod][group]->PTextureData[i]->TextureDirAndFileName.m_szOriginal);
		m_texture_fields[i].ebFile.Caption = str_info::getFileFromString(_poRMV2_File->m_File.LodData[lod][group]->PTextureData[i]->TextureDirAndFileName.m_szOriginal);
	}
}

void texture_field_group::setNumberOfTextures(uint _number_of_textures)
{
	if (_number_of_textures > 7)
		return;

	m_number_of_textures = _number_of_textures;
		
	// Using a signed int here because I need "num-1" to be able to express "-1"
	int num = m_number_of_textures;

	for (int i = 8; i > num-1; i--)
		m_texture_fields[7-i].disable(true, true);

}
