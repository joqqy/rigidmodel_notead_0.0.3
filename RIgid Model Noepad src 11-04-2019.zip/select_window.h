#pragma once
#include <control_group.h>
#include <combo_box.h>
#include <check_box.h>

class select_window :
	public control_group
{
public:
	select_window();
	virtual ~select_window();

	virtual bool onCreated() override;
		


	combo_box m_comboLod, m_comboGroup;
	check_box m_checkboxLock;

};

