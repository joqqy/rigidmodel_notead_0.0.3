#pragma once
#include "app_window.h"
#include "texture_field.h"
#include "texture_field_group.h"
#include <new_edit_box.h>
#include <menu.h>
#include <static_text.h>
#include <rmv2_file.h>
#include "select_window.h"
#include <rmv2_file.h>
#include "about_dialog.h"
#include <event_handler.h>
#include <event.h>
//#include "variadic.h"
#include "var.h"
#include <structs.h>

#define wm window_message* _wm
#define lr LRESULT

#define handle_wm(wm)


//class event_t
//{
//public:
//	__event int test_event(int);
//};
//
////variadic_function<int, int> vf;
//
//struct PP
//{
//	void f() {}
//	int i;
//};
//
//struct test1
//{
//	lr test_handler(int* me)
//	{
//		return 1;
//	}
//};

class main_window :
	public app_window
{
	
	string & getTitle(const string & strTitle);
		
	string & getVersion(const string & strVersion);

public:
	//variadic_function<int, int> vf;

	//pin::MessageHandler mh;
	



	//event_t m_event;


	int _test_handler(window_event_info::base *poBase)
	{
		return 1;
	}
	 int __thiscall test_double(double *d);

	
	

	//LRESULT handler(PP** pp, double d, int i)
	//{
	//	int i3 = 0;
	//	return 1;
	//}

	static DWORD CALLBACK ForegroundIdleProc(
		int   code,
		DWORD wParam,
		LONG  lParam
	);

	main_window();
	virtual ~main_window();

	LRESULT test_handler_create(CREATESTRUCT* pcs)
	{
		return 545;
	}

	LRESULT test_handler(int i1, int i2)
	{
		return 123;
	}
	
	void test_handler2(int i1, int i2, int i3)
	{

	}
	
	void test_handler_d3(double d1, double d2, double d3)
	{
		return;
	}


	virtual bool setupMenu() override;
	virtual bool setupHandlers() override;
	virtual bool onCreated() override;
	//virtual bool onActivate(uint state, uint min_state, HWND) override;

	

	virtual LRESULT onNotify(NMHDR * pmnh) override;

	virtual LRESULT window_message_handler(WM_ERASEBKGND, HDC hdc);


	bool updateFileInfo();

	bool updateLod();


	bool clearWindow();
	bool openFile(const string strFileName);
	bool saveFileAs(const string strFileName);

	
	bool saveFile();

	// fills the window with data from the file in memory
	bool setAllWindowData();
	bool setAllFileData();

	bool setfileInfo();

	// set all window data each time one of these are changed
	bool setLod(uint lod);
//	bool setLod(uint group);

	bool setTextureDirecotory(string strTextDir);
	bool setTextureField(string strDir, string strFilenam, uint texture_type);
	bool setAllTextureFields(string strDir, string strFilenam, uint texture_type);

	pair<string, string> splitTextureDirAndFileName(string strDirAndFileName);		

	

	

	#include "menu_items.h"
	
protected:
	bool m_bModified = false;;
	string m_strFileName = "";
	// rmv_file m_oRmv2Fle;
	HDC m_hDC;
	HBITMAP m_hBitmap;
	BITMAP m_Bitmap;

public:




	rmv2_file m_oRMV2_File;
public:
	//rmv2_file* m_RM = new rmv2_file;

	
	
	

	button m_butTest;
	about_dialog* m_poABoutDialog = NULL;
	texture_field_group m_TextureFieldgroup; static window* sm_pMainWindow;
	select_window m_selectWindow;
	//texture_field m_texture_field;
	static_text m_stattextFileInfo;
	HWND hwnd;
	//control_group m_oFileInfo;
	//texture_field olistTexutureFields[7];
public:
	handler_function onFile_Open(pwm);
	handler_function onFile_Save(pwm);
	handler_function onFile_SaveAs(pwm);
	handler_function onFile_Clear(pwm);		
	handler_function onFile_Exit(pwm);

	handler_function onEdit_Copy(pwm);
	handler_function onEdit_Paste(pwm);
	handler_function onEdit_Undo(pwm);

	handler_function onHelp_Help(pwm);
	handler_function onHelp_About(pwm);
	
	
	
	
	
	

	static constexpr char m_sztitle[] = "Rigid Model NotePad - by phazer ";
	static constexpr char m_szVersion[] = "v0.0.4a (BETA";

	bool m_bCanChangeStatus = false;
	bool m_bHasChanged = false;

	bool m_bHasAddedChangeLabel = false;
	

//#define onClose(name) class spc() ##name : public _simple_event_handler_base<csz, char>
//
//	class handler1 : public _simple_event_handler_base<csz, char, event_type::wm_event, WM_CLOSE>
//	{
//		int code(csz _csz, char _ch)
//		{
//			return 1;
//		}
//	};

};


