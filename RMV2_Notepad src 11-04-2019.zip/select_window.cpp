#include "select_window.h"
#include <stdafx.h>


select_window::select_window()
{
}


select_window::~select_window()
{
}

bool select_window::onCreated()
{

	DWORD dw = WS_CHILD | BS_CHECKBOX;
	checkboxLock.create(this, "Identical for all groups", 0, WS_CHILD | BS_CHECKBOX, 20, 20);
	
	txtModelVersion.oFont.create(14, 6, "Tahoma");
	txtModelVersion.setFont(txtModelVersion.oFont);
	txtModelVersion.create(this, "  ", "Model type: ", 400, 20);
	//txtLodCount.create(this, "[Not Loaded", "Model type", 250, 20);
	//txtTotalGroupCount.create(this, "[Not Loaded", "Model type", 300, 20);

	comboGroup.create(this, "LOD", 20, 70, 100, 200, 0, WS_CHILD | CBS_DROPDOWNLIST);
	comboLod.create(this, "Group", 20+120, 70, 100, 200, 0, WS_CHILD | CBS_DROPDOWNLIST);
	
	checkboxLock.EnableOnCheck = false;
	checkboxLock.addWinToDisableList(&comboLod);
	checkboxLock.addWinToDisableList(&comboGroup);	
	checkboxLock.State = BST_CHECKED;

	


	return true;


}
