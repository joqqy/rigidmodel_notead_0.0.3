#pragma once

#include <stdint.h>
#include "half.h"
#include <map>

#include "definitions.h"

using namespace std; 

//#define SIGNATURE 0x32564D52
//
//struct _RMV2_File_Header
//{
//	dword		dwSignature; // Should always be "RMV2"
//	uint16		ModelVersion; // always 6
//	uint32		LodsCount; // always 4
//	char		Skeleton[128];
//};
//
////offset 140
//
//
//struct _RMV2_Lod_Header {
//	uint32	GroupsCount;
//	uint32	VerticesDataLength;
//	uint32	IndicesDataLength;
//	uint32	Start_offset;
//	float	LODZoomFactor; // For 4 LoDs this is normally 100.0, 200.0, 400.0, 500.0.	
//};
//// offset
//
//
//struct _RMV2_SupplementaryBone_Data
//{
//	
//	// 4 Bytes[UInt32] - SupplementarBoneID
//	uint32 uiSupplementaryID;// 4 Bytes[UInt32] - SupplementarBoneID
//
//	//32 Bytes[0 - Padded String] - SupplementarBoneName
//	char pchSupplementaryBoneName[32];
//
//	// 48 Bytes - ? // Probably position, rotation and other things.
//	char unkown[48];
//
//	
//};
//
//
//
//struct _RMV2_Texture_Data
//{
//	//*4 Bytes[UInt32] - TextureType // 0 Diffuse, 1 Normal, 11 Specular, 12 Gloss, Mask 3 or 10
//	uint32 uiTextureType;
//
//	char pchTextureDirAndFileNam[256];
//	//256 Bytes[0 - Padded String] - TexturePath(TexturesDirectory + FileName)
//};
//
//
//
//
//struct _RMV2_Indice_Data
//{
//	//	2 Bytes[UInt16] - Index1
//		char uiIndex1[2];
//
//		// 2 Bytes[UInt16] - Index2 // CA loves to invert indices 2 and 3... this could be the case!
//		char uiIndex2[2];
//
//
//		// 2 Bytes[UInt16] - Index3 // CA loves to invert indices 2 and 3... this could be the case!
//		char uiIndex3[2];
//
//};
//
//struct _RMV2_Vertex_Default_Data
//{
//	half pos_x;
//	half pos_z;
//	half pos_y;
//
//	char unknown1_2[2];
//
//	half textcord_u;
//	half textcord_v;
//	half textcord_u2;
//	half textcord_v2;
//
//	//char unknown3_1;
//
//	byte normal_x;
//	byte normal_y;
//	byte normal_z;
//
//	char unknown4_1;
//
//	byte bitangent_x;
//	byte bitangent_y;
//	byte bitangent_z;
//
//	char unknown5_1;
//
//	byte tangent_x;
//	byte tangent_y;
//	byte tangent_z;
//
//	char unknown6_5[5];
//};
//
//
//
//struct VertexFormat {
//	static constexpr word default_format = 0;
//	static constexpr word weighted_format = 3;
//	static constexpr word cinematicformat = 4;
//};
//
//struct MaterialId
//{
//	
//
//	static constexpr uint32_t bow_wave = 22;
//		static constexpr uint32_t non_renderable = 26;
//		static constexpr uint32_t texture_combo_vertex_wind = 29;
//		static constexpr uint32_t texture_combo = 30;
//		static constexpr uint32_t decal_waterfall = 31;
//		static constexpr uint32_t standard_simple = 32;
//		static constexpr uint32_t campaign_trees = 34;
//		static constexpr uint32_t point_light = 38;
//		static constexpr uint32_t static_point_light = 45;
//		static constexpr uint32_t debug_geometry = 46;
//		static constexpr uint32_t custom_terrain = 49;
//		static constexpr uint32_t weighted_cloth = 58;
//		static constexpr uint32_t cloth = 60;
//		static constexpr uint32_t collision = 61;
//		static constexpr uint32_t collision_shape = 62;
//	static constexpr uint32_t tiled_dirtmap = 63;
//	static constexpr uint32_t ship_ambientmap = 64;
//	static constexpr uint32_t weighted = 65;
//	static constexpr uint32_t projected_decal = 67;
//	static constexpr uint32_t default_material = 68;
//	static constexpr uint32_t grass = 69;
//	static constexpr uint32_t weighted_skin = 70;
//		 static constexpr uint32_t decal = 71;
//		 static constexpr uint32_t decal_dirtmap = 72;
//	static constexpr uint32_t dirtmap = 73;
//	static constexpr uint32_t tree = 74;
//	static constexpr uint32_t tree_leaf = 75;
//	static constexpr uint32_t weighted_decal = 77;
//	static constexpr uint32_t weighted_decal_dirtmap = 78;
//	static constexpr uint32_t weighted_dirtmap = 79;
//	static constexpr uint32_t weighted_skin_decal = 80;
//	static constexpr uint32_t weighted_skin_decal_dirtmap = 81;
//	static constexpr uint32_t weighted_skin_dirtmap = 82;
//	static constexpr uint32_t water = 83;
//	static constexpr uint32_t unlit = 84;
//	static constexpr uint32_t weighted_unlit = 85;
//	static constexpr uint32_t terrain_blend = 86;
//	static constexpr uint32_t projected_decal_v2 = 87;
//	static constexpr uint32_t ignore = 88;
//	static constexpr uint32_t tree_billboard_material = 89;
//	static constexpr uint32_t water_displace_volume = 91;
//	static constexpr uint32_t rope = 93;
//	static constexpr uint32_t campaign_vegetation = 94;
//	static constexpr uint32_t projected_decal_v3 = 95;
//	static constexpr uint32_t weighted_texture_blend = 96;
//	static constexpr uint32_t projected_decal_v4 = 97;
//	static constexpr uint32_t global_terrain = 98;
//	static constexpr uint32_t decal_overlay = 99;
//	static constexpr uint32_t alpha_blend = 100;
//
//	uint32_t uiValue;
//};
//
//
//
//
//
//
//
//
//
//
//
//#define USE_ASSIGN_CONSTR(derived, var) derived (uint32_t var) : _value<uint32_t>(var) 
//
//class texture_type
//{
//public:
//	static struct values {	
//		static constexpr uint32_t	uiDiffuse = 0;
//		static constexpr uint32_t	uiNormal = 1;
//		static constexpr uint32_t	uiMask = 3;
//		static constexpr uint32_t	uiAmbientOcclusion = 5;
//		static constexpr uint32_t	uiTilingDirtUV2 = 7;
//		static constexpr uint32_t	uiDirtAlphaMask = 8;
//		static constexpr uint32_t	uiSkinMask = 10;
//		static constexpr uint32_t	uiSpecular = 11;
//		static constexpr uint32_t	uiGlossMap = 12;
//		static constexpr uint32_t	uiDecalDirtmap = 13;
//		static constexpr uint32_t	uiDecalDirtmask = 14;
//		static constexpr uint32_t	uiDecalMask = 15;
//		static constexpr uint32_t	uiDiffuseDamage = 17;	
//
//
//};
//
//
//	texture_type()
//	{
//
//	}
//	
//	
//	
//
////	using _value::operator=;
//		
//	
//
//	
//	
//
//protected:
//	virtual const char* getString(uint32_t uiValue);
//
//	
//};
//
//
//
//struct _RMV2_Lod_Data_Header
//{
//	uint32 uiMaterialId;		// 4 Bytes[UInt32] - ? // Looks like and ID or a flag, it's always 65 for the moment.
//
//	uint32 uiUnkown;			// No idea. It's a very big number normally.
//	uint32 uiUnkown1_1;			// No idea. It's a very big number normally.
//	uint32 uiVerticesCount;		// 4 Bytes[UInt32] - VerticesCount
//	uint32 uiUnkown2_1;			// No idea. It's a very big number normally.
//	uint32 uiIndicesCount;		// 	4 Bytes[UInt32] - IndicesCount
//
//	// offset 24
//
//	float GroupMinimumX;
//	float fGroupMinimumY;
//	float fGroupMinimumZ;
//	float fGroupMaximumX;
//	float fGroupMaximumY;
//	float fGroupMaximumZ;
//
//	// offset 48
//
//	char  pchShaderName[12];
//	//offset 60
//
//	//char * pchShaderName = NULL;
//	char pBlocknown4_20[20];  //offset of the item MAY be determined of the length of the previous string
//
//	//offset 80
//	word wVertexFormat;
//
//	char pchGroupName[32];				// 32 Bytes [0-Padded String] - GroupName
//	char pchTexturesDirectory[256];		// 256 Bytes[0 - Padded String] - TexturesDirectory
//	// jump 56 and read this and then jump back                                                                                                                                                                                                                                               
//	
//
//	char Unknown3_422[422];//422 Bytes - ? // 422 bytes of perplexity... shader settings? 4 bytes in the middle of this block change if
//
//	//I scale the whole model so it's probably not a single block!
//	uint32 uiSupplementarBonesCount; //4 Bytes[UInt32] - SupplementarBonesCount
//
//	int32 uiTextureCount; //4 Bytes[UInt32] - TexturesCount
//	char Unknown140[140];	//140 Bytes - ? // No idea.
//	//uint32_t uiUnknow_1_1;
//};
//
//struct _RMV2_Lod_Data
//{
//	_RMV2_Lod_Data_Header Header;
//
//	_RMV2_SupplementaryBone_Data* PSupplementaryBone_Data[255];
//	_RMV2_Texture_Data* PTextureData[255];
//
//
//	//4 Bytes - ? // It's always 00.00.00.00, probably a separator or a null mask.
//
//   //4 Bytes - ? // Normally 00.00.00.00, FF.FF.FF.FF if the group has a mask texture.
//	uint32 uiUnknown4;
//	uint32 uiMarkTextureFlag;
//
//	_RMV2_Vertex_Default_Data** PPVerticeData;
//	
//	_RMV2_Indice_Data**  PPIndice_Data;
//
//
//
//
//};
//
//
//
//struct _RMV2_LodGounpBlock
//{
//	_RMV2_Lod_Data ** PLodGroups;
//};
//
//
//
//
//
//struct _RMV2_File
//{
//	_RMV2_File_Header	FileHeader;
//	_RMV2_Lod_Header	PPLodHeaders[255];
//	_RMV2_Lod_Data*		LodData[255][255];
//};
