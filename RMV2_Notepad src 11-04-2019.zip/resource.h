﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by a_Rigid_Model_NotePad1.rc
//
#define ID_ABOUT_UPDATE                 2
#define IDB_BITMAP1                     103
#define IDD_ABOUT                       104
#define IDD_DIALOG1                     106
#define IDI_FOLDER1                     109
#define IDB_GEAR1                       126
#define IDB_BITMAP2                     127
#define IDI_ICON1                       130
#define IDI_ICON2                       131
#define IDI_ICON3                       132
#define IDI_ICON4                       133
#define IDI_ICON5                       134
#define IDI_ICON6                       135
#define GLOBALACCEL                     136
#define IDC_ABOUT_CLOSE                 1019
#define IDC_ABOUT_CLOSE2                1020
#define IDC_EDIT_CREDITS                1021
#define IDC_EDIT_CONCEPT                1022
#define IDC_EDIT_VERSION                1023
#define IDC_EDIT_GFX                    1024
#define IDC_HEADLINE                    1025
#define IDA_COPY                        10001
#define IDA_PASTE                       10002
#define IDA_EXIT                        10003
#define IDA_OPEN_FILE                   10004
#define IDA_SAVE_FILE                   10005
#define IDA_CLEAR                       10006

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1026
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
