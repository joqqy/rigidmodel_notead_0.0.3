#pragma once
#include <dialog_box.h>
#include <button.h>
#include <edit_box.h>
class about_dialog :
	public dialog_box
{
public:
	about_dialog();
	virtual ~about_dialog();

	virtual bool onDialogInit() override;

	
	
	virtual LRESULT case_WM_PAINT() override;
	
	
	window m_winGFX;
	button m_buttonUpdate, m_ButtonClose;
	edit_box m_editHeadLine, m_editConcept, m_editGFX,	m_editCredits, m_editVersion;



	handler_function update_clicked(pwm);
	handler_function close_clicked(pwm);
};

