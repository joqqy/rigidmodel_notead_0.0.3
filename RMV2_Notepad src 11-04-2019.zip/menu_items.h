#pragma once
#include "resource.h"

menu m_menuBar;

menu m_menuFile;
menu_item m_mitemFileOpen, m_mitemFileSave, m_mitemFileSaveAs, m_mitemFileClear, m_mitemFileExit;

menu m_menuEdit;
menu_item m_mitemEDIT_COPY, m_mitemEDIT_PASTE;

menu m_menuHelp;
menu_item m_mitemHELP_ABOUT;







