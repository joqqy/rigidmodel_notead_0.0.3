

#include "main_window.h"
#include "resource.h"
#include <gdi_object.h>
#include <file.h>
#include <Richedit.h>
#include <stdafx.h>
#include <unordered_map>
#include "var.h"
//#include "half.h"
using half_float::half;





DWORD main_window::ForegroundIdleProc(int code, DWORD wParam, LONG lParam)
{
	thread* p = thread::getPtrFromCurrentId();
	if (code == HC_ACTION)
	{
		
		p->m_mainWindow->Caption = "Active";
		return 1;
	}
	else if (code < 0)
	{
		p->m_mainWindow->Caption = "Idle";
		return CallNextHookEx(NULL, code, wParam, lParam);
	}
}

main_window::main_window()
{
	

	

}


main_window::~main_window()
{
	
}	

int Flag(const char* _csz)
{
	csz sz1 = _csz + strlen(_csz) + 1 ;

	return 0;
}


typename typedef		LRESULT(*type1)(int);
typename typedef		LRESULT(*type2)(int, int);

LRESULT f1(int i)
{
	return 0;
}

LRESULT f2(int i1, int i2)
{
	return 0;
}


template <class F> void BindTest2(F f)
{

}

bool main_window::setupMenu()
{
	MENU_POPUP_BEGIN(m_menuFile)
		m_mitemFileOpen("&Open \t\t Ctrl+O", this, &main_window::onFile_Open, IDA_OPEN_FILE),
		m_mitemFileSaveAs("&Save As...", this, &main_window::onFile_SaveAs),
		m_mitemFileSave("&Save \t\t Ctrl+S", this, &main_window::onFile_Save, IDA_SAVE_FILE),
		m_mitemFileClear("Clear \t\t Ctrl+L", this, &main_window::onFile_Clear, IDA_CLEAR),
		m_mitemFileExit("E&xit \t\t Alt+F4", this, &main_window::onFile_Exit)
		MENU_POPUP_END

		MENU_POPUP_BEGIN(m_menuEdit)
		m_mitemEDIT_COPY("&Copy \t\t Ctrl+C", this, &main_window::onEdit_Copy),
		m_mitemEDIT_PASTE("&Paste \t\t Ctrl+V", this, &main_window::onEdit_Paste)
		MENU_POPUP_END

		MENU_POPUP_BEGIN(m_menuHelp)
		m_mitemHELP_ABOUT("&About", this, &main_window::onHelp_About)
		MENU_POPUP_END




		MENU_BAR_BEGIN(m_menuBar)
		m_menuFile("&File"),
		m_menuEdit("&Edit"),
		m_menuHelp("&Help"),
		MENU_BAR_END


		/*	setMenu(&m_menuBar);
			drawMenu();
	*/
		return true;
}

bool main_window::setupHandlers()
{
	//BindTest2(f2);



	/*string str = );

	string str2 = &str[strlen(str.c_str())];*/

	//function<handler_function(main_window&, window_message*)> f = &main_window::onFile_Exit;


	Event_Close.bindTo(action(this, &main_window::onFile_Exit));

	//test1 *pt = new test1;
	
	//dword size1 = sizeof(&test1::test_handler);
	//dword size2 = sizeof(pt);
	//typedef LRESULT(main_window::*__pmf)(int);
	
	//dword size3 = sizeof(__pmf);

	//int s = sizeof(double);
	//__asm
	//{	
	//	push NULL		
	//	
	//	mov edx, [pt] //first 4 bytes are the pointer to the vtable

	//	//mov ebx,[test1::test_handler]

	//	//call edx	
	//}
	
	//Event_System.bindTo(action(this, &main_window::onFile_Open));
		
	return true;
}



string & main_window::getTitle(const string & strTitle)
{
	string strTemp = strTitle;
	return strTemp;

}

string & main_window::getVersion(const string & strVersion)
{
	string strTemp = strVersion;
	return strTemp;
}

int main_window::test_double(double* d)
{
	double *_d = d;

	return (LRESULT)*d;
}


bool main_window::onCreated()
{
	/*variadic_function<int, int> fv;
	fv.bind(&main_window::test_handler, this);
	LRESULT l = fv.exec(1, 4);*/

	message_handler mh;
	mh.bind(WM_COMMAND, &main_window::test_handler, this);
	mh.bind(*this, WM_COMMAND, &main_window::test_handler, this);

	uint64_t t = mh.exec<WM_COMMAND>(5, 6);

	//this->bindWMHandler<WM_CREATE>(&main_window::test_handler_create, this);
	
	//this->m_window_message_handler.exec<WM_CREATE>(NULL);

	this->m_window_message_handler.bindControl<NULL, BN_CLICKED>(&main_window::test_handler_create, this);
	/*window_message_handler mh;
	mh.bind(&main_window::test_handler, this);
	mh.exec(1, 2);*/

	int i = 0;
	/*window_message_handler mh;
	mh.bind(&main_window::test_handler, this);
	mh(1, 2);*/
	 

//	variadic_function<int, int> vf;
//	vf.bind(&main_window::test_handler, this);
//	vf.exec(1, 2);
//	
//
//
//	/*mh[0].bind_func(&main_window::test_handler, this);
//	mh[1].bind_func(&main_window::test_handler2, this);
//	mh[2].bind_func(&main_window::test_handler_d3, this);
//	mh[3].bind_func(&main_window::test_handler_d3, this);
//
//	mh[0].exec_func(();
//*/
//
//
//
//
//	variadic_function<double,double, double> f2;
//	f2.bind(&main_window::test_handler_d3, this);
//	f2.exec(1.0, 2.0, 3.0);
	//f2.returnBaseDeriver()->bind()

//	variadic_function_base * p = f2.getBase;
	//static_cast<variadic_function<int, int >*>(p)->returnBaseDeriver()->exec()


	//f2.bind(&main_window::test_handler, this);
	
	/*window_message_handler mh;

	mh.bind<int,int>(&main_window::test_handler, this);
	mh.exec<int, int>(1, 2);*/
	
	


	//vf.bind(&main_window::test_handler, this);
	//vf.exec(1, 4);
	//variadic_function<int, int> vf;
	//vf.bind(&main_window::test_handler, this);
//	int i = vf.exec(123, -246);

	//int b = 0;
	//window_event_manager a;

	//window_event_info::base b;
	//
	//window_message_handler mh;

	//mh.bind(&main_window::_test_handler, this);
	//mh.raise(-123, 56);
	//*/

	//a.assign(this, &main_window::_test_handler);
	//a.invoke(NULL, 1234, 6, 7);


	//a.bindMessageEvent(this, &main_window::test_handler);
	

	//ControlEventInfo a;

	//uint ui = a.compare();

	//__hook(event_t::test_event, &a, &main_window::test_handler);
	

	//mh.listenToMessage("DO", &main_window::test_handler, this);
	//mh.broadcastMessage("DO", 1, 2);



	//_pmf<main_window, int, double> *p  = new _pmf<main_window, int, double>;
	
//	p->assign(this, &main_window::handler);
	//a.invoke(1, 2, 3, 4);
	
	//_pmf_base *pBase = p;

	//pBase->_invoke('a', 3.14,-123 );
	
	/*_pmf<main_window, int, int, char> pointer_to_mf;

	pointer_to_mf.assign(this, &main_window::handler);
	pointer_to_mf.invoke(1, 2, 'char');*/


	m_hBitmap = LoadBitmap(H_INST, MAKEINTRESOURCE(IDB_BITMAP1));
	GetObject(m_hBitmap, sizeof(BITMAP), (PVOID)&m_Bitmap);
		
	m_hDC = CreateCompatibleDC(hDC);
	SelectObject(m_hDC, m_hBitmap);
	
	


	poMainWindow = this;

	


	/*INT I[] = { COLOR_ACTIVECAPTION, COLOR_ACTIVEBORDER};
	COLORREF cr[] = {RGB(60, 0, 60), RGB(0, 160, 60) };
	bool b1 = SetSysColors(2, I, cr);
*/
	//BOOL BB = TRUE;
	//SystemParametersInfo(SPI_SETFLATMENU,
	//	0,                 // Not used
	//	&BB,        // Mouse information
	//	SPIF_UPDATEINIFILE);  // Update Win.ini

	//Caption = m_sztitle;
	
	//	bool b  =m_RM->readFile("RMV2Files\att_spatha_heavy_02.rigid_model_v2");
	
	//txt = txt + "Test 2" + "Test 3";

	oFont.create();


	m_TextureFieldgroup.create(this, WC_BUTTON, "Textures", 0, WS_CHILD | BS_GROUPBOX, 10, 80, Width - 40, 300);
	
	m_stattextFileInfo(oFont);
	m_stattextFileInfo.create(this, "[no file loaded]", "Open File: ", 10, 30, true, 0);

	
	
	
	//m_selectWindow.create(this, WC_BUTTON, "Selecet LOD / Group", 0, WS_CHILD | BS_GROUPBOX, 10, 70, Width - 40, 120);	
	//m_selectWindow.checkboxLock.Enabled = false;
	//m_selectWindow.checkboxLock.Enabled = true;

	clearWindow();

	//getHotKeyEvent(m_mitemFileOpen) >> action(this, &main_window::onFile_Open);

	/*for (int i = 0; i < 8; i++)
		m_TextureFieldgroup.m_texture_fields[i].disable(true, true);
*/
	
	//for (int i = 0; i < 8 - m_oRMV2_File.m_File.LodData[0][0]->Header.uiTextureCount; i++)
	//	m_TextureFieldgroup.m_texture_fields[7 - i].disable(true, true);

	//m_oRMV2_File.readFile("E:\\modding\\Extra_v1\\models_extravaganza_v1_part1_0.pack\\VariantMeshes\\_VariantModels\\man\\shield\\_1_scutum_typeA_1.rigid_model_v2");
	
	//m_oRMV2_File.readFile("E:\\s4h_spatha_pb_149_scabbard_01.rigid_model_v2");


	//m_stattextFileInfo.setFont(CreateFont(-10, -4, 0, 9, FW_DEMIBOLD, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_TT_PRECIS,
	//	CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, FIXED_PITCH, TEXT("Tahoma")));
	//m_stattextFileInfo.Caption = m_oRMV2_File.m_strFileName;



	//string strTest = m_stattextFileInfo.Caption;

	//m_TextureFieldgroup.m_texture_fields[3].ebFolder.setFocus();

	


	//uint text_count = m_oRMV2_File.m_File.LodData[0][0]->Header.uiTextureCount;

	//for (int i = 0; i < 8 - m_oRMV2_File.m_File.LodData[0][0]->Header.uiTextureCount; i++)
	//	m_TextureFieldgroup.m_texture_fields[7 - i].disable(true, true);


	//for (int i = 0; i < m_oRMV2_File.m_File.LodData[0][0]->Header.uiTextureCount; i++)
	//{
	//	m_TextureFieldgroup.m_texture_fields[i].ebFolder.Caption = str_info::getDirFromString(m_oRMV2_File.m_File.LodData[0][0]->PTextureData[i]->TextureDirAndFileName.m_szOriginal);
	//	m_TextureFieldgroup.m_texture_fields[i].ebFile.Caption = str_info::getFileFromString(m_oRMV2_File.m_File.LodData[0][0]->PTextureData[i]->TextureDirAndFileName.m_szOriginal);
	//}

	////
	////string strDir = str_info::getDirFromString(m_oRMV2_File.m_File.LodData[0][0]->PTextureData[0]->TextureDirAndFileName.m_szOriginal);
	
	if (process::strCommandLine != "")
		return openFile(process::strCommandLine);

	return 1;
}

LRESULT main_window::onNotify(NMHDR * pmnh)
{

	string strCaption = Caption;

	if (!m_bHasAddedChangeLabel)
	{
		strCaption = m_sztitle + string(" - ");
		strCaption += m_oRMV2_File.m_strFileName2;
		strCaption += " - [*edited]";
		Caption = strCaption;
		m_bHasAddedChangeLabel = true;

		return 1;
	}


	return 0;
}

LRESULT main_window::window_message_handler(WM_ERASEBKGND, HDC hdc)
{

	BitBlt(hdc, 0, 0, m_Bitmap.bmWidth, m_Bitmap.bmHeight, m_hDC, 0, 0, SRCCOPY);


	return 1;
}

bool main_window::updateFileInfo()
{
	m_stattextFileInfo.Caption = m_oRMV2_File.m_strFileName2;

	//	addNotifyHandler<main_window>(this, &main_window::notify);


	return true;
}


bool main_window::updateLod()
{
	if (!m_oRMV2_File.bFIleLoaded)
		return false;

	//for (group)

}

bool main_window::clearWindow()
{
	Caption = m_sztitle;
	m_bCanChangeStatus = false;



	for (int i = 0; i < 8; i++)
	{
		m_TextureFieldgroup.m_texture_fields[i].disable(true, true);
		m_TextureFieldgroup.m_texture_fields[i].ebFile.Caption = "...";
		m_TextureFieldgroup.m_texture_fields[i].ebFolder.Caption = "...";
	}

	m_TextureFieldgroup.m_cbgroupLockDir.State = BST_UNCHECKED;
	m_TextureFieldgroup.m_cbgroupLocTextureType.State = BST_UNCHECKED;

	m_TextureFieldgroup.m_cbgroupLockDir.enable(false);
	m_TextureFieldgroup.m_cbgroupLocTextureType.enable(false);

	m_stattextFileInfo.Caption = "[no file loaded]";
	m_selectWindow.txtModelVersion.Caption = "  ";

	
		

	m_oRMV2_File.bFIleLoaded = false;
		


	return true;
}

bool main_window::openFile(const string strFileName)

{	
	
	string strTemp2;
	//for (int x = 0; x < strFileName.size(); x++)
	//{
	//	if (strFileName.c_str()[x] == '"')

	//		strTemp2 = strFileName.c_str()[x + 1];

	//	//strFileName.data()()[ strFileName.size()-1 ] = '\0';
	//	break;
	//}
	m_stattextFileInfo.Caption = strFileName;

	

	if (!m_oRMV2_File.readFile(strFileName))	
	return false;


	


	clearWindow();
	m_TextureFieldgroup.m_cbgroupLockDir.enable(true);
	m_TextureFieldgroup.m_cbgroupLocTextureType.enable(true);

	uint ui = m_TextureFieldgroup.m_texture_fields[0].comboTextureType.findByLPARAM(22);


	m_stattextFileInfo.setFont(CreateFont(-10, -4, 0, 9, FW_DEMIBOLD, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_TT_PRECIS,
		CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, FIXED_PITCH, TEXT("Tahoma")));
	
	m_stattextFileInfo.Caption = m_oRMV2_File.m_strFileName2;
	m_selectWindow.txtModelVersion.Caption = m_oRMV2_File.m_File.FileHeader.ModelVersion;

	string strTemp = m_sztitle;
	strTemp += " - ";
	strTemp += m_oRMV2_File.m_strFileName2;

	//this->Caption = strTemp;
	
	string strTest = m_stattextFileInfo.Caption;

	uint text_count = m_oRMV2_File.m_File.LodData[0][0]->Header.uiTextureCount;


	for (int i = 0; i < m_oRMV2_File.m_File.LodData[0][0]->Header.uiTextureCount; i++)
	{
		m_TextureFieldgroup.m_texture_fields[i].disable(false, false);
		

		m_TextureFieldgroup.m_texture_fields[i].ebFile.enable(true);		
		m_TextureFieldgroup.m_texture_fields[i].ebFolder.Caption = str_info::getDirFromString(m_oRMV2_File.m_File.LodData[0][0]->PTextureData[i]->TextureDirAndFileName.m_szOriginal);
		m_TextureFieldgroup.m_texture_fields[i].ebFile.Caption = str_info::getFileFromString(m_oRMV2_File.m_File.LodData[0][0]->PTextureData[i]->TextureDirAndFileName.m_szOriginal);
	}

	m_TextureFieldgroup.updateComboboxes(&m_oRMV2_File);


	m_TextureFieldgroup.m_cbgroupLockDir.State = BST_UNCHECKED;
	m_TextureFieldgroup.m_cbgroupLocTextureType.State = BST_UNCHECKED;

	m_TextureFieldgroup.m_cbgroupLockDir.setAllChildren();
	m_TextureFieldgroup.m_cbgroupLocTextureType.setAllChildren();



	m_bCanChangeStatus = true;

	InvalidateRect(*this, NULL, true);


	strTemp = m_sztitle;
	strTemp += " - ";
	strTemp += m_oRMV2_File.m_strFileName2;	
	this->Caption = strTemp;

	m_bHasAddedChangeLabel = false;


	return true;

}
bool main_window::saveFileAs(const string strFileName)
{
	for (int lod = 0; lod < m_oRMV2_File.m_File.FileHeader.LodsCount; lod++)
	{
		for (int group = 0; group < m_oRMV2_File.m_File.PPLodHeaders[lod].GroupsCount; group++)
		{
			for (int i = 0; i < m_oRMV2_File.m_File.LodData[lod][group]->Header.uiTextureCount; i++)
			{
				m_oRMV2_File.m_File.LodData[lod][group]->PTextureData[i]->TextureDirAndFileName =
					str_info::getPathFromDirAndFile(
						m_TextureFieldgroup.m_texture_fields[i].ebFolder.Caption,
						m_TextureFieldgroup.m_texture_fields[i].ebFile
					);


				//m_oRMV2_File.setallTexturesByNumber(i, m_oRMV2_File.m_File.LodData[0][0]->PTextureData[i]->TextureDirAndFileName.getStrContent());
				m_oRMV2_File.saveToBuffer(&m_oRMV2_File.m_File.LodData[lod][group]->PTextureData[i]->TextureDirAndFileName);
			}
		}
	}
	bool b = m_oRMV2_File.writeFileAs(strFileName);

	m_stattextFileInfo.Caption = m_oRMV2_File.m_strFileName2;
	
	string strTemp = m_sztitle;
	strTemp += " - ";
	strTemp += m_oRMV2_File.m_strFileName2;
	strTemp += " - [saved]";
	this->Caption = strTemp;

	m_bHasAddedChangeLabel = false;
	return b;
}
handler_function main_window::onFile_Open(pwm)
{
	
	file fileTemp;	

	if (!fileTemp.openFileDialog(this))
		return 1;

	openFile(fileTemp);

	return 1;
}

handler_function main_window::onFile_Save(pwm)
{
	if (!m_oRMV2_File.bFIleLoaded)
		return 0;
		
	saveFileAs(m_oRMV2_File.m_strFileName2);

	return 1;

}

handler_function main_window::onFile_SaveAs(pwm)
{
	if (!m_oRMV2_File.bFIleLoaded)
		return 0;



	file fileTemp;


	if (!fileTemp.saveFileDialog(this))
		return 1;

	saveFileAs(fileTemp);

	return 1;

}

handler_function main_window::onFile_Clear(pwm)
{
	if (!m_oRMV2_File.bFIleLoaded)
		return 0;

	if (getYesNoBox("Clear", "Are you sure you want to clear all fields?"))
		return clearWindow();
	else
		return 0;
}

handler_function main_window::onFile_Exit(window_message* p)
{
	

	//DestroyWindow(m_hHandle);
	PostQuitMessage(1);
	return 1;

}

handler_function main_window::onEdit_Copy(pwm)
{
	PostQuitMessage(1);
	if (!OpenClipboard(*this))
		return 0;
	
 	m_szText = m_TextureFieldgroup.m_texture_fields[0].ebFile.getSelection();

	HANDLE hp = GlobalAlloc(GMEM_FIXED, strlen(m_szText)+1);
	
	sz szTemp =(sz) GlobalLock(hp);

	memcpy(szTemp, m_szText, strlen(m_szText));
	GlobalUnlock(hp);

	
	HANDLE H = SetClipboardData(CF_TEXT, hp);

	CloseClipboard();
	
	return 1;
}

handler_function main_window::onEdit_Paste(pwm)
{
	return handler_function();
}

handler_function main_window::onHelp_About(pwm)
{
	m_poABoutDialog = new about_dialog;
	m_poABoutDialog->create(this, IDD_ABOUT);
	return 1;
}
