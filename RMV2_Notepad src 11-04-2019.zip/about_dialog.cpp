#include "about_dialog.h"
#include "resource.h"


about_dialog::about_dialog()
{
}


about_dialog::~about_dialog()
{
}

bool about_dialog::onDialogInit()
{

	m_buttonUpdate.getDialogItem(this, ID_ABOUT_UPDATE);
	m_ButtonClose.getDialogItem(this, IDC_ABOUT_CLOSE);
	m_editConcept.getDialogItem(this, IDC_EDIT_CONCEPT);
	m_editGFX.getDialogItem(this, IDC_EDIT_GFX);
	m_editHeadLine.getDialogItem(this, IDC_HEADLINE);
	
	m_editCredits.getDialogItem(this, IDC_EDIT_CREDITS);
	
	
	m_editVersion.getDialogItem(this, IDC_EDIT_VERSION);
	

	//m_buttonUpdate.ctrlEvent( action(this, &about_dialog::update_clicked);
	
	m_buttonUpdate.ctrlEvent(BN_CLICKED) >> action(this, &about_dialog::update_clicked);
	m_ButtonClose.ctrlEvent(BN_CLICKED) >> action(this, &about_dialog::close_clicked);
	

	
	sys_menu_event(this, SC_CLOSE) >> action(this, &about_dialog::close_clicked);
	

	return true;
}

LRESULT about_dialog::case_WM_PAINT()
{
	
	PAINTSTRUCT ps;
	BeginPaint(*this, &ps);
	
	string strTemp;

	m_editHeadLine.oFont.create(12,5, "Arial Black", 600);
	m_editHeadLine.setFont(m_editHeadLine.oFont);
	m_editHeadLine.Caption = "Credits and info:";

	m_editConcept.oFont.create(11, 0, "Times New Roman", 650);
	m_editConcept.setFont(m_editConcept.oFont);
	strTemp = "Phazer:  Concept, Design, Coding";
	strTemp += ENDL;
	strTemp += "Phazer:  Minor research into the RMV2 file format";
	m_editConcept.Caption = strTemp;

	m_editCredits.oFont.create(8,6, "Courier New", 600);
	m_editCredits.setFont(m_editCredits.oFont);
	
	strTemp = "Mr.Jox:  Major original reserach into the RMV2 file format";
	strTemp += ENDL;
	strTemp += "Frodo45127: Addtional research into the RMV2 file format";

	m_editCredits.Caption = strTemp;


	m_editGFX.oFont.create(10, 0, "Console", 300);
	m_editGFX.setFont(m_editGFX.oFont);
	strTemp = "Icons:  https://www.iconfinder.com/korawan_m";
	strTemp += ENDL;
	strTemp += "Background Picture:  https://pixabay.com/";

	m_editGFX.Caption = strTemp;
	
	
	
	
	m_editVersion.Caption =		"version 0.0.3a [beta]";

	EndPaint(*this, &ps);
	

	return 1;


}

handler_function about_dialog::update_clicked(pwm)
{
	return 1;
}

handler_function about_dialog::close_clicked(pwm)
{

	exitDialog(1);

	delete this;
	return 1;

}
