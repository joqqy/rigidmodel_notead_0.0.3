// #include "stdafx.h"
#include "texture_field.h"
#include "resource.h"


texture_field::texture_field()
{

}


texture_field::~texture_field()
{
}

bool texture_field::onCreated()


{

	checboxFolderLock.create(this, "", 0, WS_CHILD | BS_CHECKBOX, 5, 10, 15, 15);	
	
	comboTextureType.create(this, "Texture Type", 0, WS_CHILD | CBS_DROPDOWNLIST, NULL, 700-10, 10, 120, 350);
	

	
	ebFolder.create(this, "....", 0, WS_BORDER | WS_CHILD | ES_AUTOHSCROLL | ES_RIGHT | ES_AUTOHSCROLL, NULL, 17+5, 10, 400, 20);
	ebFile.create(this, "...", 0, WS_BORDER | WS_CHILD | ES_AUTOHSCROLL, NULL, 350+30+50, 10, 300-50, 20);

	ebFolder.oFont.create(8, 0, "Tahoma", FW_NORMAL);
	ebFile.oFont.create(8, 0, "Tahoma", FW_NORMAL);
			

	ebFile.setFont(ebFile.oFont);
	ebFolder.setFont(ebFolder.oFont);


	ebFolder.Caption = "Test";

	/*HDC hdc = hDC;

	m_oFont = CreateFont(-MulDiv(8, GetDeviceCaps(hdc, LOGPIXELSY), 72), 0,  0, 9, 300, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_TT_PRECIS,
		CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, FIXED_PITCH, TEXT("Tahoma"));*/
	
	

	// TODO: finish th8is class
	



	//m_oFont.setWidth(-20);

	bool b = m_image_list.create(16, 16, 1, 10);

	m_image_list.addIcon(LoadIcon(H_INST, MAKEINTRESOURCE(IDI_FOLDER1)));
	m_image_list.addIcon(LoadIcon(H_INST, MAKEINTRESOURCE(IDI_ICON1)));
	m_image_list.addIcon(LoadIcon(H_INST, MAKEINTRESOURCE(IDI_ICON2)));
	m_image_list.addIcon(LoadIcon(H_INST, MAKEINTRESOURCE(IDI_ICON3)));
	m_image_list.addIcon(LoadIcon(H_INST, MAKEINTRESOURCE(IDI_ICON4)));
	m_image_list.addIcon(LoadIcon(H_INST, MAKEINTRESOURCE(IDI_ICON5)));
	m_image_list.addIcon(LoadIcon(H_INST, MAKEINTRESOURCE(IDI_ICON6)));
	m_image_list.addIcon(LoadIcon(H_INST, MAKEINTRESOURCE(IDI_FOLDER1)));


	comboTextureType.setImageList(m_image_list);

	ebFolder.Caption = "...";
	ebFile.Caption = "...";



	//f.setWidth(-60);

	comboTextureType.setFont(oFont);
	
	comboTextureType.addElement("diffuse", texture_type::values::uiDiffuse, 0);
	comboTextureType.addElement("specular", texture_type::values::uiSpecular, 1);
	comboTextureType.addElement("normal", texture_type::values::uiNormal, 2);
	comboTextureType.addElement("gloss", texture_type::values::uiGlossMap, 3);
	comboTextureType.addElement("test_mask", texture_type::values::uiMask, 4);
	comboTextureType.addElement("decal_dirt_map", texture_type::values::uiDecalDirtmap, 4);
	comboTextureType.addElement("decal_dirt_mask", texture_type::values::uiDecalDirtmask, 4);
	comboTextureType.addElement("decal_mask", texture_type::values::uiDecalMask, 4);
	comboTextureType.addElement("diffuse_damage", texture_type::values::uiDiffuseDamage, 4);
	comboTextureType.addElement("ambient_occlusion", texture_type::values::uiAmbientOcclusion, 4);
	
	
	
	comboTextureType.addElement("unknown", 2000, 4);

	return true;
}

bool texture_field::enable(bool bState, bool bStateChildren)
{
	control_group::enable(bState, bStateChildren);

	





	return false;
}

bool texture_field::setReadOnly(bool bState)
{
	ebFolder.setReadOnly(bState);
	//ebFile.setReadOnly(bState);

	if (bState == false)
	{
		ebFolder.oFont.create(8, 0, "Tahoma", FW_NORMAL, DEFAULT_QUALITY);
		ebFolder.setFont(ebFolder.oFont);
	}
	else
	{
		ebFolder.oFont.create(8, 0, "Tahoma", FW_EXTRALIGHT, ANTIALIASED_QUALITY);
		
		ebFolder.setFont(ebFolder.oFont);

	}

	return true;
};

void texture_field::updateComboBox(int texture_index, const rmv2_file * pRMV2File)
{
	// Select the texture type
	comboTextureType.selectByParam(pRMV2File->m_File.LodData[0][0]->PTextureData[texture_index]->uiTextureType);
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//								Static member definitions
//
/////////////////////////////////////////////////////////////////////////////////////////////////////////


font texture_field::sm_oUsedFont;
font texture_field::sm_oUsedFontBold;
