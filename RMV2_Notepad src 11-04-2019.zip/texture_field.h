#pragma once
#include <control_group.h>
#include "check_box.h"
#include "combo_box.h"
#include "edit_box.h""
#include "resource.h"
#include <structs.h>
#include <rmv2_file.h>


class texture_field : public control_group
{
public:
	texture_field();
	~texture_field();
	texture_field(window* _poParent, int style_ex, int style, int x, int y, int width, int height)
		: control_group(_poParent, style_ex, style, x, y, width, height)
	{
	}

	virtual bool onCreated() override; 

	virtual bool enable(bool bState, bool bStateChildren = true) override;
	virtual bool setReadOnly(bool bState = true) override;


	void updateComboBox(int texture_index, const rmv2_file*);	 

	check_box checboxFolderLock;// = check_box(this, "", 0, WS_CHILD | BS_CHECKBOX, 0, 10, 15, 15);

	edit_box ebFolder;// = edit_box(this, "....", WS_EX_CLIENTEDGE, WS_CHILD | ES_RIGHT, NULL, 15, 10, 300, 22);
	edit_box ebFile;;// = edit_box(this, "...", WS_EX_CLIENTEDGE, WS_CHILD, NULL, 325, 10, 300, 22);

	combo_box comboTextureType;; // = combo_box(this, "Texture Type", 0, WS_CHILD | CBS_DROPDOWNLIST, 0, 650, 10, 100, 200);
	image_list m_image_list;

	static font sm_oUsedFont;
	static font sm_oUsedFontBold;
};


