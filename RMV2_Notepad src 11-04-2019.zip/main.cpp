#include <gui_lib.h>
#include <new_edit_box.h>


#include "main_window.h"
#include "texture_field.h"
#include "texture_field_group.h"
#include <winuser.h>
#include "resource.h"



class main_process : public app
{
public:
	main_process() {};





	template <class C>
	void b(function<LRESULT(C*, UINT) > func, C* po)
	{

	}





	HWND hwnd;

	virtual sys_int setupHandlers() override
	{
		//m_main_window.WM_Event(WM_CLOSE) >> action(this, &main_process::onFile_Exit);
		//m_main_window.MENU_FILE_EXIT(this, &main_process::onFile_Exit);

		return 1;
	}


	virtual int onQuit(int _exit_code)
	{
		/*for (int i = 0; i < COLOR_LEN; i++)
			SetSysColors(i, &m_I[i], &m_crOld[i]);*/

		return _exit_code;
	};

	virtual LRESULT onCreated() override
	{
		loadAccelerators(GLOBALACCEL);


		HICON hIcon = LoadIcon(H_INST, MAKEINTRESOURCE(IDI_FOLDER1));

		int i = 1;
		//aMouseInfo[2] = 2 * aMouseInfo[2];

		// Change the mouse speed to the new value.

	/*
	for (int i = 0; i < COLOR_LEN; i++)
		m_crOld[i] = GetSysColor(m_I[i]);

	for (int i = 0; i < COLOR_LEN; i++)
		SetSysColors(i, &m_I[i], &m_crNew[i]); */


		bool b = RegisterNewEditBox(H_INST);


		sz szTemp = asm_add_to_buffer();




		//nenuFile(MENU_FILE, "&File", &_app::MenuFile)



		m_main_window("Main", WS_EX_DLGMODALFRAME, WS_OVERLAPPEDWINDOW&~WS_MAXIMIZEBOX&~WS_THICKFRAME, 100, 120, 870, 700);
		//		



		//function<LRESULT(C*, window_message*)> func = &main_process::onFile_Exit

		//window::bind(this);



//		window::t_bindHandlerToMenuEvent(m_main_window.MENU_FILE_EXIT, this, &main_process::onFile_Exit);




		//

		////m_texture_field.create(m_main_window, 10, 10, 750, 30);

		//m_group.create(m_main_window, WC_BUTTON,  "Textures", 0, WS_CHILD | BS_GROUPBOX, 20, 200, 780, 300);

		//m_group.m_texture_fields[0].ebFile.Caption = "roman_gladius_diffuse.rigid_model_v2";
		//m_group.m_texture_fields[0].comboTextureType.selectByIndex(0);
		//
		//m_group.m_texture_fields[1].ebFile.Caption = "roman_gladius_normal.rigid_model_v2";
		//m_group.m_texture_fields[1].comboTextureType.selectByIndex(2);

		//m_group.m_texture_fields[2].ebFile.Caption = "text_mask.rigid_model_v2";
		//m_group.m_texture_fields[2].comboTextureType.selectByIndex(4);

		//m_group.m_texture_fields[3].ebFile.Caption = "roman_gladius_gloss_map.rigid_model_v2";
		//m_group.m_texture_fields[3].comboTextureType.selectByIndex(3);

		//m_group.m_texture_fields[4].ebFile.Caption = "roman_gladius_specular.rigid_model_v2";
		//m_group.m_texture_fields[4].comboTextureType.selectByIndex(1);



		//m_main_window.Caption = "Rigid Mogdel Notepad - by phazer";
		//

		//DEBUG_BREAKPOINT


		/*SetClassLong(m_main_window, GCL_HBRBACKGROUND,(long) HBRUSH (COLOR_WINDOWTEXT+1));
		InvalidateRect(m_main_window, NULL, true);
		m_main_window.update();
		m_main_window.show();

		hwnd = CreateWindowEx(0, "NEW_EDIT", "Test New Edit", WS_CHILD, 100, 100, 300, 100, m_main_window, 0, H_INST, NULL);
		ShowWindow(hwnd, SW_SHOW);


		long l = WS_EX_WINDOWEDGE | WS_EX_STATICEDGE;*/
		//long ex_styles = m_main_window.ExStyles;







		/*int x = m_main_window.X;
		int y = m_main_window.Y;*/

		return 0;
	}






	//texture_field_group m_group;
	//texture_field m_texture_field;
	main_window m_main_window;

};

main_process MyApp;